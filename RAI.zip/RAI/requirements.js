'use strict';
// ═══════════════════════════════════════════════════════════════════════
// REQUIREMENTS.JS  —  Complete, production-ready module
// Fixes verified against all positive + negative test cases:
//
//  BUG 1 FIXED  – Score breakdown (_breakdown) was never attached in
//                 AI.findMatches → showed 0% in every field.
//                 Fixed: patch findMatches to always attach _breakdown.
//
//  BUG 2 FIXED  – No-skill requirement (skills column empty) returned
//                 skillScore=0 because bestSkillMatch.matched===false.
//                 Fixed: when reqSkills is empty, treat all employees as
//                 skill-matched with a neutral score of 80.
//
//  BUG 3 FIXED  – Experience filter was computed but never enforced as
//                 a hard gate — wrong employees were shown.
//                 Fixed: exp is now a soft penalty (not a hard cut) so
//                 partial-exp employees appear lower, not missing.
//
//  BUG 4 FIXED  – DB.addRequirement used Date.now() as ID in a tight
//                 forEach loop → millisecond collisions → last row
//                 overwrote earlier ones in localStorage.
//                 Fixed: monotonic counter guarantees unique IDs.
//
//  BUG 5 FIXED  – Buttons used inline onclick="findForReq('${r.id}')".
//                 After any renderReqs() call the DOM is replaced and
//                 the result panel div is destroyed, so clicking Find
//                 again does nothing visible.
//                 Fixed: event delegation on #req-container + result
//                 panel is appended once and never wiped by re-render.
//
//  BUG 6 FIXED  – ColMapper REQ schema was too narrow; real-world
//                 Excel headers like "Required Skills", "Job Title",
//                 "Minimum Experience" did not map.
//                 Fixed: extended alias list covers 40+ header variants.
//
// Depends on (must load before this file):
//   security.js → database.js → colmapper.js → excel.js → ai.js → app.js
// ═══════════════════════════════════════════════════════════════════════


// ───────────────────────────────────────────────────────────────────────
// 0.  EXTEND ColMapper.REQ with real-world header variants
// ───────────────────────────────────────────────────────────────────────
ColMapper.REQ = {
  role: ['role', 'jobtitle', 'title', 'position', 'opening', 'requirement',
    'requirementtitle', 'rolename', 'jobprofile', 'profile', 'jobrole',
    'hiringrole', 'vacancytitle', 'requisition', 'requisitiontitle',
    'jobopening', 'jobrequisition', 'positiontitle'],
  skills: ['skills', 'requiredskills', 'mandatoryskills', 'techstack', 'technologies',
    'skillsrequired', 'keyskills', 'primaryskills', 'mustskills',
    'technicalskills', 'competencies', 'skill', 'musthavedskills',
    'skillset', 'technologiesrequired', 'toolsandtechnologies'],
  experienceYears: ['experience', 'minexperience', 'minyears', 'requiredexperience',
    'experiencerequired', 'yearsofexperience', 'expneeded', 'minexp',
    'minimumexperience', 'yoe', 'years', 'totalexperience',
    'experienceinears', 'minexpyears'],
  designation: ['band', 'level', 'grade', 'designation', 'seniority', 'requiredband',
    'bandlevel', 'requiredlevel', 'requiredgrade', 'tier', 'gradelevel',
    'banddesignation', 'targetband', 'requireddesignation'],
  location: ['location', 'preferredlocation', 'city', 'baselocation', 'worklocation',
    'site', 'office', 'preferredcity', 'joblocation', 'positionlocation'],
  headcount: ['headcount', 'count', 'openings', 'positions', 'vacancies', 'seats',
    'numberofpositions', 'noofpositions', 'nos', 'qty', 'quantity',
    'requiredheadcount', 'totalvacancies', 'openpositions'],
  priority: ['priority', 'urgency', 'criticality', 'importancelevel',
    'hiringpriority', 'reqpriority', 'prioritylevel'],
  description: ['description', 'details', 'notes', 'jd', 'jobdescription', 'remarks',
    'additionalinfo', 'context', 'comments', 'requirementdetails',
    'rolescription', 'jobdetails'],
  department: ['department', 'dept', 'division', 'bu', 'team', 'unit', 'businessunit',
    'hiringdept', 'hiringdepartment', 'requestingdept'],
  status: ['status', 'reqstatus', 'requirementstatus', 'state', 'openingstatus'],
};


// ───────────────────────────────────────────────────────────────────────
// 1.  FIX DB.addRequirement — monotonic IDs, no millisecond collision
// ───────────────────────────────────────────────────────────────────────
let _reqSeq = 0;

DB.addRequirement = function (r) {
  const list = this._g('requirements');
  _reqSeq++;
  const newReq = {
    ...r,
    id: 'req-' + Date.now() + '-' + _reqSeq,
    createdAt: new Date().toISOString(),
    status: r.status || 'Open',
    priority: r.priority || 'Medium',
  };
  list.push(newReq);
  this._s('requirements', list);
  return newReq;
};


// ───────────────────────────────────────────────────────────────────────
// 2.  FIX AI.findMatches — attach _breakdown + fix zero-skill scoring
// ───────────────────────────────────────────────────────────────────────
AI.findMatches = function (req, dept = null) {
  const employees = DB.getEmployees(dept);
  if (!employees.length) return { free: [], partial: [], ending: [], internal: [], noMatch: [] };

  // ── Parse requirement fields ──────────────────────────────────────
  const reqBand = BAND.normalize(req.designation || req.band || req.level || '');
  const reqSkills = String(req.skills || '').split(/[,;|]/).map(s => s.trim()).filter(Boolean);
  const forFreshers = !!req.forFreshers
    || String(req.role || '').toLowerCase().includes('fresher')
    || String(req.role || '').toLowerCase().includes('new joiner')
    || String(req.role || '').toLowerCase().includes('newjoiner');

  const validBands = BAND.getValidBands(reqBand, forFreshers);
  const reqExp = parseFloat(req.experienceYears || req.minExperience || '0') || 0;
  const reqLoc = String(req.location || '').toLowerCase().trim();

  const free = [], partial = [], ending = [], internal = [], noMatch = [];

  for (const emp of employees) {

    // ── 1. Band gate (hard filter) ──────────────────────────────────
    const empBand = BAND.normalize(emp.designation || emp.band || emp.level || emp.grade || '');
    let bandOk = true, bandPriority = 0;

    if (reqBand && validBands.length) {
      if (!empBand) {
        // No band recorded on employee → allow but penalise
        bandOk = true;
        bandPriority = validBands.length; // lowest priority in the list
      } else if (!validBands.includes(empBand)) {
        bandOk = false; // above required band → hard reject
      } else {
        bandPriority = validBands.indexOf(empBand); // 0 = exact match (best)
      }
    }
    if (!bandOk) continue;

    // ── 2. Skill matching ───────────────────────────────────────────
    const empSkills = this.getSkillList(emp);
    let skillScore = 80; // default when requirement has no skills specified
    let bestPriority = 999, bestReqIdx = 999;

    if (reqSkills.length > 0) {
      let anyMatched = false;
      let totalScore = 0;
      let matchCount = 0;

      for (let si = 0; si < reqSkills.length; si++) {
        const m = this.skillMatches(empSkills, reqSkills[si]);
        if (m.matched) {
          anyMatched = true;
          matchCount++;
          // Score this individual skill: higher index in emp list = slightly lower score
          const indivScore = Math.max(10, 100 - m.priority * 5);
          totalScore += indivScore;
          if (si < bestReqIdx) { bestReqIdx = si; bestPriority = m.priority; }
        }
      }

      if (!anyMatched) continue; // none of the required skills matched → hard reject

      // skillScore = average across all matched required skills, weighted by coverage
      const coverageRatio = matchCount / reqSkills.length; // 1.0 = all skills matched
      skillScore = Math.round((totalScore / matchCount) * (0.5 + 0.5 * coverageRatio));
      skillScore = Math.min(100, Math.max(0, skillScore));
    }

    // ── 3. Experience scoring (soft — not a hard gate) ──────────────
    const empExp = this.getEffectiveExp(emp);
    const expScore = reqExp === 0
      ? 80 // no exp requirement → neutral
      : empExp >= reqExp ? 100
        : empExp >= reqExp - 0.5 ? 90
          : empExp >= reqExp - 1 ? 75
            : empExp >= reqExp - 2 ? 55
              : 35; // well below requirement → included but scored low

    // ── 4. Location scoring (soft) ──────────────────────────────────
    const empLoc = String(emp.location || '').toLowerCase();
    const locScore = !reqLoc
      ? 80
      : (empLoc.includes(reqLoc) || reqLoc.includes(empLoc)) ? 100
        : 30;

    // ── 5. Band score ────────────────────────────────────────────────
    // bandPriority 0 = exact match → 100, each step down = -8
    const bandScore = reqBand
      ? Math.max(20, 100 - bandPriority * 8)
      : 80;

    // ── 6. Composite score (weights must sum to 1.0) ─────────────────
    // Skill:30, Band:30, Exp:25, Loc:15
    const composite = Math.round(
      skillScore * 0.30 +
      bandScore * 0.30 +
      expScore * 0.25 +
      locScore * 0.15
    );

    // ── 7. Availability triage ───────────────────────────────────────
    const empUtil = DB.empUtil(emp.id);
    const empAvail = 100 - empUtil;
    const empAllocs = DB.empAllocs(emp.id);

    // Availability bonus: free employees score slightly higher
    const availBonus = empAvail >= 100 ? 5 : empAvail >= 50 ? 2 : 0;
    const finalScore = Math.min(100, composite + availBonus);

    const result = {
      ...emp,
      _band: empBand,
      _util: empUtil,
      _avail: empAvail,
      _bandPriority: bandPriority,
      _skillPriority: bestPriority,
      _reqSkillIdx: bestReqIdx,
      _score: finalScore,
      _allocs: empAllocs,
      // ← BUG 1 FIX: always attach breakdown so UI can render it
      _breakdown: {
        skill: skillScore,
        band: bandScore,
        exp: expScore,
        loc: locScore,
        avail: empAvail >= 100 ? 100 : empAvail >= 50 ? 70 : empAvail >= 25 ? 45 : 20,
      },
    };

    // ── Tier assignment ──────────────────────────────────────────────
    if (empAvail >= 100) {
      free.push({ ...result, _tier: 'free', _tierLabel: '100% Available' });

    } else if (empUtil <= 50) {
      partial.push({ ...result, _tier: 'partial', _tierLabel: `${empAvail}% Available` });

    } else {
      const endingIn30 = empAllocs.some(a => this.endingWithinDays(a, 30));
      const endingIn60 = empAllocs.some(a => this.endingWithinDays(a, 60));
      const endingAlloc = empAllocs.find(a => this.endingWithinDays(a, 60));

      if (endingIn30 || endingIn60) {
        ending.push({
          ...result,
          _tier: 'ending',
          _tierLabel: `Allocation ending in ${endingIn30 ? '30' : '60'} days`,
          _endDate: endingAlloc?.endDate,
          _endProject: endingAlloc?.projectName,
        });
      } else {
        const allOnInternal = empAllocs.length > 0
          && empAllocs.every(a => this.isInternal(a.projectName));

        if (allOnInternal) {
          const proj = empAllocs.map(a => a.projectName).join(', ');
          internal.push({
            ...result,
            _tier: 'internal',
            _tierLabel: `On internal project: ${proj}`,
            _internalProj: proj,
          });
        } else {
          noMatch.push({ ...result, _tier: 'busy', _tierLabel: `${empUtil}% Allocated` });
        }
      }
    }
  }

  const sortFn = (a, b) => b._score - a._score || a._bandPriority - b._bandPriority;
  return {
    free: free.sort(sortFn),
    partial: partial.sort(sortFn),
    ending: ending.sort(sortFn),
    internal: internal.sort(sortFn),
    noMatch: noMatch.sort(sortFn),
  };
};


// ───────────────────────────────────────────────────────────────────────
// 3.  REQUIREMENTS PAGE  —  full rewrite
// ───────────────────────────────────────────────────────────────────────

// BUG 5 FIX: we track which req panels are open so renderReqs()
// can restore them without losing state.
const _REQ_OPEN_PANELS = new Map(); // reqId → last result HTML

function pageReqs() {
  return `
<div class="page-hdr">
  <div class="page-hdr-left">
    <h1>Requirements</h1>
    <p>Staffing requirements with band-aware AI matching · one card per row</p>
  </div>
  <div class="page-hdr-actions">
    <button class="btn btn-ghost btn-sm" onclick="dlgReqColumnPicker()">⚙ Columns</button>
    <button class="btn btn-ghost btn-sm" onclick="exportReqs()">⬇ Export</button>
    <button class="btn btn-teal  btn-sm" onclick="dlgAddReq()">+ New Requirement</button>
  </div>
</div>

<div class="filter-row">
  <input  id="f-rs"    type="text" class="fi-text" style="min-width:220px"
          placeholder="🔍 Search role, skills, location…"/>
  <select id="f-rstat" class="fi">
    <option value="">All Status</option>
    <option>Open</option><option>In Progress</option>
    <option>Fulfilled</option><option>Cancelled</option>
  </select>
  <select id="f-rpri" class="fi">
    <option value="">All Priority</option>
    <option>High</option><option>Medium</option><option>Low</option>
  </select>
  <select id="f-rdept" class="fi">
    <option value="">All Departments</option>
    ${DB.getDepts().map(d => `<option>${d}</option>`).join('')}
  </select>
  <span id="req-count" style="font-size:.79rem;color:var(--text3);margin-left:6px"></span>
</div>

<div id="req-container"></div>`;
}


// ── initReqs ────────────────────────────────────────────────────────────
function initReqs() {
  _REQ_OPEN_PANELS.clear();

  // Attach filter listeners
  document.getElementById('f-rs').addEventListener('input', renderReqs);
  document.getElementById('f-rstat').addEventListener('change', renderReqs);
  document.getElementById('f-rpri').addEventListener('change', renderReqs);
  document.getElementById('f-rdept').addEventListener('change', renderReqs);

  // BUG 5 FIX: single delegated listener — survives every DOM re-render
  document.getElementById('req-container').addEventListener('click', _reqContainerClick);

  renderReqs();
}


// ── Delegated click handler ─────────────────────────────────────────────
function _reqContainerClick(e) {
  const btn = e.target.closest('[data-req-action]');
  if (!btn) return;

  const action = btn.dataset.reqAction;
  const id = btn.dataset.id;

  switch (action) {
    case 'find': _findForReq(id); break;
    case 'edit': dlgEditReq(id); break;
    case 'cycle': _cycleStatus(id); break;
    case 'delete': _deleteReq(id); break;
    case 'collapse': _collapsePanel(id); break;
    case 'allocate': dlgAllocate(id); break; // id = employee id here
  }
}


// ── renderReqs ──────────────────────────────────────────────────────────
// BUG 5 FIX: after rebuilding the DOM, re-inject any open result panels
// so "Find Employees" results survive filter changes.
function renderReqs() {
  const search = (document.getElementById('f-rs')?.value || '').toLowerCase().trim();
  const statF = document.getElementById('f-rstat')?.value || '';
  const priF = document.getElementById('f-rpri')?.value || '';
  const deptF = document.getElementById('f-rdept')?.value || '';

  let reqs = DB.getRequirements(sc());
  if (statF) reqs = reqs.filter(r => r.status === statF);
  if (priF) reqs = reqs.filter(r => r.priority === priF);
  if (deptF) reqs = reqs.filter(r => (r.department || '') === deptF);
  if (search) reqs = reqs.filter(r =>
    [r.role, r.skills, r.location, r.description, r.department]
      .map(v => String(v || '').toLowerCase())
      .some(v => v.includes(search))
  );

  const countEl = document.getElementById('req-count');
  if (countEl) countEl.textContent =
    `${reqs.length} requirement${reqs.length !== 1 ? 's' : ''}`;

  const container = document.getElementById('req-container');
  if (!container) return;

  if (!reqs.length) {
    container.innerHTML = `
      <div class="empty">
        <div class="empty-ico">📋</div>
        <div class="empty-msg">No requirements found.<br/>Add one manually or import a requirements Excel file.</div>
      </div>`;
    return;
  }

  // Build HTML for every card
  container.innerHTML = reqs.map(r => _buildReqCard(r)).join('');

  // Restore any open result panels (BUG 5 FIX)
  _REQ_OPEN_PANELS.forEach((html, reqId) => {
    const panel = document.getElementById(`rmp-${reqId}`) || document.getElementById(`rm-${reqId}`);
    if (panel) {
      panel.innerHTML = html;
      if (typeof _injectCandidateExtraFieldsDOM === 'function') {
        _injectCandidateExtraFieldsDOM(reqId);
      }
    }
  });
}


// ── Card builder — NO inline onclick, all data-req-action ───────────────
function _buildReqCard(r) {
  const normB = BAND.normalize(r.designation || r.band || '');

  const priBorder = r.priority === 'High' ? 'var(--red)'
    : r.priority === 'Medium' ? 'var(--amber)'
      : 'var(--blue)';
  const priBadge = r.priority === 'High' ? 'b-red'
    : r.priority === 'Medium' ? 'b-amber'
      : 'b-blue';
  const statBadge = r.status === 'Open' ? 'b-green'
    : r.status === 'In Progress' ? 'b-cyan'
      : r.status === 'Fulfilled' ? 'b-teal'
        : 'b-gray';

  const safeRole = _hesc(r.role || r.title || 'Untitled');
  const safeSkills = _hesc(r.skills || '');
  const safeLoc = _hesc(r.location || '');
  const safeDesc = _hesc(r.description || '');
  const safeHC = _hesc(String(r.headcount || ''));
  const safeDept = _hesc(r.department || '');
  const safeId = _hesc(r.id);

  // ── Extra columns selected by user ──
  const extraFieldsHtml = _buildReqExtraFields(r);

  return `
<div class="card req-card" id="rcard-${safeId}"
     style="margin-bottom:14px;border-left:3px solid ${priBorder}">

  <!-- Header -->
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">

    <!-- Left info -->
    <div style="flex:1;min-width:240px">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
        <span style="font-weight:800;font-size:1.02rem">${safeRole}</span>
        <span class="badge ${priBadge}">${r.priority || 'Normal'}</span>
        <span class="badge ${statBadge}">${r.status}</span>
        ${normB ? BAND.renderBand(normB) : ''}
        ${r.forFreshers ? '<span class="badge b-purple">🎓 Freshers A1/A2</span>' : ''}
      </div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:.8rem;color:var(--text2);margin-bottom:${safeDesc ? '7px' : '0'}">
        ${safeSkills ? `<span>🔧 ${safeSkills}</span>` : ''}
        ${r.experienceYears ? `<span>📅 ${r.experienceYears}+ yrs</span>` : ''}
        ${safeLoc ? `<span>📍 ${safeLoc}</span>` : ''}
        ${safeHC ? `<span>👥 ${safeHC} headcount</span>` : ''}
        ${safeDept ? `<span>🏢 ${safeDept}</span>` : ''}
      </div>
      ${safeDesc ? `<p style="font-size:.79rem;color:var(--text3);line-height:1.55;margin-top:4px">${safeDesc}</p>` : ''}
      ${extraFieldsHtml}
    </div>

    <!-- Action buttons (data-req-action only, no inline onclick) -->
    <div style="display:flex;gap:6px;flex-wrap:wrap;flex-shrink:0;align-items:flex-start">
      <button class="btn btn-teal btn-sm"
              data-req-action="find" data-id="${safeId}"
              title="Run AI matching for this requirement">
        🧠 Find Employees
      </button>
      <button class="btn btn-outline btn-sm"
              data-req-action="edit" data-id="${safeId}">✏️ Edit</button>
      <button class="btn btn-ghost btn-sm"
              data-req-action="cycle" data-id="${safeId}"
              title="Cycle: Open → In Progress → Fulfilled → Cancelled">
        ↻ ${r.status}
      </button>
      <button class="btn btn-red btn-sm"
              data-req-action="delete" data-id="${safeId}">🗑</button>
    </div>
  </div>

  <!-- Result panel — starts empty, filled by _findForReq -->
  <div id="rmp-${safeId}" class="req-match-panel" style="margin-top:0"></div>
</div>`;
}


// ───────────────────────────────────────────────────────────────────────
// 4.  FIND EMPLOYEES  (the core fix)
// ───────────────────────────────────────────────────────────────────────
function _findForReq(reqId) {
  const req = DB.getRequirements().find(r => r.id === reqId);
  if (!req) { toast('Requirement not found', 'err'); return; }

  // Always fetch panel fresh from live DOM (BUG 5 FIX)
  const panel = document.getElementById(`rmp-${reqId}`) || document.getElementById(`rm-${reqId}`);
  if (!panel) { toast('UI panel missing — please reload', 'err'); return; }

  // Spinner
  const spinnerHtml = `
    <div style="border-top:1px solid var(--border);margin-top:14px;padding-top:14px;
                display:flex;align-items:center;gap:10px;color:var(--text2);font-size:.84rem">
      <div class="spin"></div>
      Scoring all employees by band hierarchy, skill coverage, experience, location…
    </div>`;
  panel.innerHTML = spinnerHtml;
  _REQ_OPEN_PANELS.set(reqId, spinnerHtml);

  setTimeout(() => {
    try {
      const html = _computeMatchHtml(req);
      panel.innerHTML = html;
      if (typeof _injectCandidateExtraFieldsDOM === 'function') {
        _injectCandidateExtraFieldsDOM(reqId);
      }
      _REQ_OPEN_PANELS.set(reqId, panel.innerHTML); // persist for re-renders
    } catch (err) {
      const errHtml = `<div class="alert a-err" style="margin-top:14px">
        Match error: ${_hesc(err.message)}. Check console for details.</div>`;
      panel.innerHTML = errHtml;
      _REQ_OPEN_PANELS.set(reqId, errHtml);
      console.error('[Requirements] findForReq error:', err);
    }
  }, 350);
}

// Kept as alias so any old onclick in app.js still works
function findForReq(id) { _findForReq(id); }


// ───────────────────────────────────────────────────────────────────────
// 5.  COMPUTE MATCH HTML  — builds the tiered result section
// ───────────────────────────────────────────────────────────────────────
function _computeMatchHtml(req) {
  const deptScope = sc();                        // null → admin sees all
  const result = AI.findMatches(req, deptScope);

  const totalMatched = result.free.length + result.partial.length
    + result.ending.length + result.internal.length;

  const normB = BAND.normalize(req.designation || req.band || '');
  const validBands = normB
    ? BAND.getValidBands(normB, req.forFreshers)
    : BAND.ORDER;

  // ── Summary header ─────────────────────────────────────────────────
  let html = `
<div style="border-top:1px solid var(--border);margin-top:14px;padding-top:14px">

  <!-- Summary pills -->
  <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:13px">
    <span style="font-weight:700;font-size:.88rem">AI Match Results</span>
    <span class="badge b-green" title="100% free">🟢 Free: ${result.free.length}</span>
    <span class="badge b-amber" title="≤50% allocated">🟡 Partial: ${result.partial.length}</span>
    <span class="badge b-cyan"  title="Ending in 30–60d">📅 Ending: ${result.ending.length}</span>
    <span class="badge b-purple" title="On internal project">🏢 Internal: ${result.internal.length}</span>
    ${result.noMatch.length
      ? `<span class="badge b-gray" title="Skill-matched but fully busy">
             🔴 Busy: ${result.noMatch.length}</span>`
      : ''}
    <button class="btn btn-xs btn-ghost" style="margin-left:auto"
            data-req-action="collapse" data-id="${_hesc(req.id)}">✕ Close</button>
  </div>

  <!-- Context bar -->
  <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:.74rem;color:var(--text3);
              background:var(--bg3);padding:8px 12px;border-radius:var(--r-sm);margin-bottom:14px">
    <span>🎯 <strong style="color:var(--text2)">${_hesc(req.role || '')}</strong></span>
    <span>Band: ${normB ? BAND.renderBand(normB) : '<em style="color:var(--text3)">Any</em>'}</span>
    <span>Eligible:
      ${validBands.slice(0, 8).map(b =>
        `<span class="band-pill ${BAND.getBandClass(b)}">${b}</span>`).join(' ')}
    </span>
    ${req.skills
      ? `<span>🔧 ${_hesc(req.skills)}</span>`
      : '<span style="color:var(--amber2)">⚠ No skill filter — showing band + exp matches</span>'}
    ${req.experienceYears
      ? `<span>📅 Min ${req.experienceYears} yrs</span>`
      : ''}
    ${req.forFreshers
      ? '<span class="badge b-purple" style="font-size:.65rem">🎓 Freshers only</span>'
      : ''}
  </div>`;

  // ── No results case ────────────────────────────────────────────────
  if (totalMatched === 0 && result.noMatch.length === 0) {
    const total = DB.getEmployees(deptScope).length;
    html += `
  <div class="alert a-warn">
    <strong>No employees matched</strong> this requirement out of ${total} employees.<br/>
    <span style="font-size:.82rem">
      ${normB ? `Band filter: only A1–${normB} (and below) are considered. ` : ''}
      ${req.skills ? `Skills required: ${_hesc(req.skills)}. ` : ''}
      Try relaxing the band, removing the skills filter, or importing more employee data.
    </span>
  </div>`;
  } else {

    // Tier 1 — 100% Free
    if (result.free.length) {
      html += `<div class="avail-tier at-free">
        🟢 Tier 1 — 100% Available (${result.free.length})
      </div>`;
      html += result.free.map((e, i) => _buildMatchCard(e, i)).join('');
    }

    // Tier 2 — Partially free (≤50% utilised)
    if (result.partial.length) {
      html += `<div class="avail-tier at-partial" style="margin-top:12px">
        🟡 Tier 2 — Partially Available ≤50% utilised (${result.partial.length})
      </div>`;
      html += result.partial.map((e, i) => _buildMatchCard(e, i)).join('');
    }

    // Tier 3 — Allocation ending soon
    if (result.ending.length) {
      html += `<div class="avail-tier at-ending" style="margin-top:12px">
        📅 Tier 3 — Allocation Ending in 30–60 Days (${result.ending.length})
      </div>`;
      html += result.ending.map((e, i) => _buildMatchCard(e, i)).join('');
    }

    // Tier 4 — On internal / bench project
    if (result.internal.length) {
      html += `<div class="avail-tier at-internal" style="margin-top:12px">
        🏢 Tier 4 — On Internal / Bench Project (${result.internal.length})
      </div>`;
      html += result.internal.map((e, i) => _buildMatchCard(e, i)).join('');
    }

    // Tier 5 — Skill-matched but fully committed
    if (result.noMatch.length) {
      html += `<div class="avail-tier at-none" style="margin-top:12px">
        🔴 Skill-Matched but Fully Committed (${result.noMatch.length})
        <span style="font-size:.72rem;font-weight:400;margin-left:6px;color:var(--text3)">
          shown for pipeline planning
        </span>
      </div>`;
      html += result.noMatch.slice(0, 8).map((e, i) => _buildMatchCard(e, i)).join('');
    }
  }

  html += '</div>';
  return html;
}


// ───────────────────────────────────────────────────────────────────────
// 6.  MATCH CARD  — fully self-contained, no inline onclick
// ───────────────────────────────────────────────────────────────────────
function _buildMatchCard(emp, idx) {
  const empB = emp._band || BAND.normalize(emp.designation || emp.band || emp.level || '');
  const scoreCls = emp._score >= 75 ? 'sr-high'
    : emp._score >= 45 ? 'sr-mid'
      : 'sr-low';

  // Tier badge
  const tierBadge =
    emp._tier === 'free' ? '<span class="badge b-green">🟢 100% free</span>'
      : emp._tier === 'partial' ? `<span class="badge b-amber">🟡 ${emp._avail}% free</span>`
        : emp._tier === 'ending' ? `<span class="badge b-cyan">⏰ Ends ${_hesc(emp._endDate || 'soon')}</span>`
          : emp._tier === 'internal' ? `<span class="badge b-purple">🏢 ${_hesc(emp._internalProj || 'Internal')}</span>`
            : `<span class="badge b-red">🔴 ${emp._util}% utilised</span>`;

  // Skills with proficiency
  const allSkills = AI.getSkillObjects(emp).filter(s => !s.isAspiring);
  const aspiringSkills = AI.getAspiringSkills(emp);
  const effectiveExp = AI.getEffectiveExp(emp);

  const skillsHtml = allSkills.length > 0
    ? allSkills.slice(0, 8).map(s => {
      const col = s.level === 'expert' ? 'var(--teal)'
        : s.level === 'advanced' ? 'var(--amber2)'
          : s.level === 'beginner' ? 'var(--text3)'
            : 'var(--text2)';
      const bg = s.level === 'expert' ? 'rgba(0,200,180,.12)'
        : s.level === 'advanced' ? 'rgba(240,165,0,.12)'
          : 'var(--surface3)';
      const stars = s.level === 'expert' ? '★★★'
        : s.level === 'advanced' ? '★★' : '';
      return `<span class="chip" title="Level: ${s.level}"
                      style="background:${bg};color:${col}">
                  ${_hesc(s.skill)}${stars ? `<sup style="font-size:.55em;margin-left:1px">${stars}</sup>` : ''}
                </span>`;
    }).join('')
    + (allSkills.length > 8
      ? `<span class="chip">+${allSkills.length - 8} more</span>` : '')
    : skillChips(emp.skills || '', 8);

  // Score breakdown (BUG 1 FIX: _breakdown is now always present)
  const bd = emp._breakdown || { skill: 0, band: 0, exp: 0, loc: 0, avail: 0 };

  // Utilisation bar colour
  const utilCol = emp._util >= 90 ? 'var(--red)'
    : emp._util >= 70 ? 'var(--amber)'
      : 'var(--teal)';

  // ── Extra columns selected by user (employee + allocation) ──
  const candidateExtras = _buildCandidateExtraFields(emp);

  return `
<div class="ai-card" style="margin-top:9px">
  <div style="display:flex;align-items:flex-start;gap:13px;flex-wrap:wrap">

    <!-- Rank -->
    <div style="font-weight:900;font-size:.75rem;color:var(--text3);
                width:20px;padding-top:5px;flex-shrink:0">#${idx + 1}</div>

    <!-- Score ring -->
    <div class="score-ring ${scoreCls}" title="Overall match score">
      ${emp._score}%
    </div>

    <!-- Employee details -->
    <div style="flex:1;min-width:200px">

      <!-- Name + badges -->
      <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:5px">
        <strong style="font-size:.97rem">${_hesc(emp.name)}</strong>
        ${empB ? BAND.renderBand(empB) : ''}
        <span class="badge b-blue">${_hesc(emp.department || '—')}</span>
        ${tierBadge}
      </div>

      <!-- Sub-line -->
      <div style="font-size:.76rem;color:var(--text2);margin-bottom:6px">
        <span title="Experience">${effectiveExp || '?'} yrs exp</span>
        &nbsp;·&nbsp; 📍 ${_hesc(emp.location || '—')}
        ${emp.email ? `&nbsp;·&nbsp; <span style="color:var(--text3)">${_hesc(emp.email)}</span>` : ''}
      </div>

      <!-- Skills row -->
      <div style="margin-bottom:6px">${skillsHtml}</div>

      <!-- Aspiring skills -->
      ${aspiringSkills.length ? `
        <div style="margin-bottom:5px">
          <span style="font-size:.65rem;color:var(--text3);font-style:italic">📚 Wants to learn: </span>
          ${aspiringSkills.slice(0, 4).map(s =>
    `<span class="chip" style="color:var(--purple);font-style:italic;font-size:.67rem">
                ${_hesc(s)}</span>`
  ).join('')}
        </div>` : ''}

      <!-- Utilisation mini-bar -->
      <div style="display:flex;align-items:center;gap:7px;margin-bottom:6px">
        <div style="flex:1;height:4px;background:var(--surface3);border-radius:2px;overflow:hidden;max-width:160px">
          <div style="width:${emp._util}%;height:100%;background:${utilCol};border-radius:2px"></div>
        </div>
        <span style="font-size:.7rem;color:var(--text3)">${emp._util}% utilised · ${emp._avail}% free</span>
      </div>

      <!-- Score breakdown (BUG 1 FIX: always shows real numbers now) -->
      <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:.69rem;
                  background:var(--bg3);padding:5px 9px;border-radius:5px">
        <span title="Skill coverage score">
          🔧 Skills <strong style="color:var(--teal)">${bd.skill}%</strong>
        </span>
        <span title="Band proximity score">
          🎯 Band <strong style="color:var(--teal)">${bd.band}%</strong>
        </span>
        <span title="Experience score">
          📅 Exp <strong style="color:var(--teal)">${bd.exp}%</strong>
        </span>
        <span title="Location score">
          📍 Loc <strong style="color:var(--teal)">${bd.loc}%</strong>
        </span>
        <span title="Availability score">
          ⚡ Avail <strong style="color:var(--teal)">${bd.avail}%</strong>
        </span>
      </div>
      ${candidateExtras}
    </div>

    <!-- Right actions -->
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;flex-shrink:0">
      ${availBadge(emp._avail)}
      <!-- data-req-action="allocate" passes employee ID, handled by delegation -->
      <button class="btn btn-teal btn-sm"
              data-req-action="allocate" data-id="${_hesc(emp.id)}">
        Allocate →
      </button>
    </div>

  </div>
</div>`;
}


// ───────────────────────────────────────────────────────────────────────
// 7.  STATUS CYCLE / DELETE / COLLAPSE
// ───────────────────────────────────────────────────────────────────────
function _cycleStatus(id) {
  const order = ['Open', 'In Progress', 'Fulfilled', 'Cancelled'];
  const r = DB.getRequirements().find(x => x.id === id);
  if (!r) return;
  const next = order[(order.indexOf(r.status) + 1) % order.length];
  DB.updateRequirement(id, { status: next });
  _REQ_OPEN_PANELS.delete(id); // close panel on status change
  renderReqs();
  toast(`Status → ${next}`, 'info');
}

function _deleteReq(id) {
  const r = DB.getRequirements().find(x => x.id === id);
  if (!confirm(`Delete requirement: "${r?.role || id}"?`)) return;
  DB.deleteRequirement(id);
  _REQ_OPEN_PANELS.delete(id);
  renderReqs();
  toast('Requirement deleted', 'info');
}

function _collapsePanel(id) {
  _REQ_OPEN_PANELS.delete(id);
  const panel = document.getElementById(`rmp-${id}`) || document.getElementById(`rm-${id}`);
  if (panel) panel.innerHTML = '';
}

// Public aliases so old code in app.js still compiles
function cycleReqStatus(id) { _cycleStatus(id); }
function delReq(id) { _deleteReq(id); }


// ───────────────────────────────────────────────────────────────────────
// 8.  ADD REQUIREMENT DIALOG
// ───────────────────────────────────────────────────────────────────────
function dlgAddReq() {
  openDlg(`
<div class="dlg-title">New Requirement</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Role / Title *</label>
    <input id="nr-r" class="form-input" placeholder="Senior React Developer"/>
  </div>
  <div class="form-group">
    <label class="form-label">Priority</label>
    <select id="nr-p" class="form-select">
      <option>High</option><option selected>Medium</option><option>Low</option>
    </select>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Required Skills <span style="color:var(--text3);font-weight:400">(comma-separated)</span></label>
    <input id="nr-sk" class="form-input" placeholder="React, Node.js, AWS…"/>
  </div>
  <div class="form-group">
    <label class="form-label">Min Experience (years)</label>
    <input id="nr-exp" type="number" class="form-input" placeholder="3" min="0" step="0.5"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Required Band</label>
    <select id="nr-b" class="form-select">
      <option value="">Any Band</option>
      ${BAND.ORDER.map(b => `<option value="${b}">${b}</option>`).join('')}
    </select>
    <div class="band-explain" style="margin-top:6px">
      ${BAND.ORDER.map(b =>
    `<span class="band-pill ${BAND.getBandClass(b)}">${b}</span>`).join('')}
    </div>
  </div>
  <div class="form-group">
    <label class="form-label">Location</label>
    <input id="nr-loc" class="form-input" placeholder="Hyderabad, Remote…"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Headcount</label>
    <input id="nr-hc" type="number" class="form-input" value="1" min="1"/>
  </div>
  <div class="form-group">
    <label class="form-label">Department</label>
    <select id="nr-d" class="form-select">
      ${DB.getDepts().map(d =>
      `<option ${d === uDept() ? 'selected' : ''}>${d}</option>`).join('')}
    </select>
  </div>
</div>

<div class="form-group" style="display:flex;align-items:center;gap:10px">
  <input type="checkbox" id="nr-fresh" style="width:16px;height:16px;cursor:pointer"/>
  <label for="nr-fresh" style="font-size:.85rem;cursor:pointer;color:var(--text2)">
    🎓 Freshers / New Joiners only — restricts matching to A1 / A2
  </label>
</div>

<div class="form-group">
  <label class="form-label">Description / JD Notes</label>
  <textarea id="nr-desc" class="form-textarea"
            placeholder="Mandatory certifications, travel requirements, project context…"></textarea>
</div>

<div>
  <label class="form-label">Custom Fields</label>
  <div id="nr-ex"></div>
  <button class="btn btn-xs btn-ghost" style="margin-top:6px"
          onclick="addDynField('nr-ex')">+ Add Field</button>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal"  onclick="saveAddReq()">Save Requirement</button>
</div>`);
}

function saveAddReq() {
  const role = document.getElementById('nr-r')?.value.trim();
  if (!role) return toast('Role / Title is required', 'err');

  DB.addRequirement({
    role,
    priority: document.getElementById('nr-p').value,
    skills: document.getElementById('nr-sk').value.trim(),
    experienceYears: document.getElementById('nr-exp').value.trim(),
    designation: document.getElementById('nr-b').value.trim(),
    location: document.getElementById('nr-loc').value.trim(),
    headcount: document.getElementById('nr-hc').value.trim(),
    department: document.getElementById('nr-d').value,
    forFreshers: document.getElementById('nr-fresh').checked,
    description: document.getElementById('nr-desc').value.trim(),
    ...getDynFields('nr-ex'),
  });

  closeDlg();
  renderReqs();
  toast('Requirement saved ✓', 'ok');
}


// ───────────────────────────────────────────────────────────────────────
// 9.  EDIT REQUIREMENT DIALOG
// ───────────────────────────────────────────────────────────────────────
function dlgEditReq(id) {
  const r = DB.getRequirements().find(x => x.id === id);
  if (!r) return toast('Requirement not found', 'err');

  openDlg(`
<div class="dlg-title">Edit Requirement</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Role / Title</label>
    <input id="er-r" class="form-input" value="${_hesc(r.role || '')}"/>
  </div>
  <div class="form-group">
    <label class="form-label">Priority</label>
    <select id="er-p" class="form-select">
      <option ${r.priority === 'High' ? 'selected' : ''}>High</option>
      <option ${r.priority === 'Medium' ? 'selected' : ''}>Medium</option>
      <option ${r.priority === 'Low' ? 'selected' : ''}>Low</option>
    </select>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Required Skills</label>
    <input id="er-sk" class="form-input" value="${_hesc(r.skills || '')}"/>
  </div>
  <div class="form-group">
    <label class="form-label">Min Experience (yrs)</label>
    <input id="er-exp" type="number" class="form-input"
           value="${r.experienceYears || ''}" min="0" step="0.5"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Required Band</label>
    <select id="er-b" class="form-select">
      <option value="">Any Band</option>
      ${BAND.ORDER.map(b => {
    const norm = BAND.normalize(r.designation || '');
    return `<option value="${b}" ${norm === b ? 'selected' : ''}>${b}</option>`;
  }).join('')}
    </select>
  </div>
  <div class="form-group">
    <label class="form-label">Location</label>
    <input id="er-loc" class="form-input" value="${_hesc(r.location || '')}"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Status</label>
    <select id="er-s" class="form-select">
      ${['Open', 'In Progress', 'Fulfilled', 'Cancelled'].map(s =>
    `<option ${r.status === s ? 'selected' : ''}>${s}</option>`).join('')}
    </select>
  </div>
  <div class="form-group">
    <label class="form-label">Headcount</label>
    <input id="er-hc" type="number" class="form-input"
           value="${r.headcount || 1}" min="1"/>
  </div>
</div>

<div class="form-group" style="display:flex;align-items:center;gap:10px">
  <input type="checkbox" id="er-fresh" ${r.forFreshers ? 'checked' : ''} style="width:16px;height:16px;cursor:pointer"/>
  <label for="er-fresh" style="font-size:.85rem;cursor:pointer;color:var(--text2)">
    🎓 Freshers only (A1/A2)
  </label>
</div>

<div class="form-group">
  <label class="form-label">Description</label>
  <textarea id="er-desc" class="form-textarea">${_hesc(r.description || '')}</textarea>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal"  onclick="saveEditReq('${_hesc(id)}')">Update</button>
</div>`);
}

function saveEditReq(id) {
  const r = DB.getRequirements().find(x => x.id === id);
  if (!r) return toast('Not found', 'err');

  DB.updateRequirement(id, {
    role: document.getElementById('er-r').value.trim(),
    priority: document.getElementById('er-p').value,
    skills: document.getElementById('er-sk').value.trim(),
    experienceYears: document.getElementById('er-exp').value.trim(),
    designation: document.getElementById('er-b').value,
    location: document.getElementById('er-loc').value.trim(),
    status: document.getElementById('er-s').value,
    headcount: document.getElementById('er-hc').value.trim(),
    forFreshers: document.getElementById('er-fresh').checked,
    description: document.getElementById('er-desc').value.trim(),
  });

  // Invalidate cached panel so next "Find" recomputes fresh
  _REQ_OPEN_PANELS.delete(id);
  closeDlg();
  renderReqs();
  toast('Requirement updated ✓', 'ok');
}


// ───────────────────────────────────────────────────────────────────────
// 10.  EXPORT
// ───────────────────────────────────────────────────────────────────────
function exportReqs() {
  if (!window.XLSX) return toast('XLSX library not loaded', 'err');
  const reqs = DB.getRequirements(sc());
  if (!reqs.length) return toast('No requirements to export', 'warn');

  const rows = reqs.map(r => ({
    Role: r.role || '',
    Priority: r.priority || '',
    Status: r.status || '',
    Skills: r.skills || '',
    Band: BAND.normalize(r.designation || '') || r.designation || '',
    MinExp: r.experienceYears || '',
    Location: r.location || '',
    Headcount: r.headcount || '',
    Department: r.department || '',
    Freshers: r.forFreshers ? 'Yes' : 'No',
    Description: r.description || '',
    CreatedAt: r.createdAt || '',
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Requirements');
  XLSX.writeFile(wb, 'ResourceAI_Requirements.xlsx');
  toast('Exported ✓', 'ok');
}


// ───────────────────────────────────────────────────────────────────────
// 11.  IMPORT PATCH  — replaces the req block inside runImport()
//      BUG 4 FIX: each row saved independently with unique ID
// ───────────────────────────────────────────────────────────────────────
function _importRequirements(buf, existingMapping, myDept) {
  if (!buf || !buf.rows || !buf.rows.length) return 0;
  const { rows } = buf;

  // Always recompute mapping against the extended REQ schema
  const mapping = existingMapping
    || ColMapper.mapHeaders(Object.keys(rows[0] || {}), ColMapper.REQ);

  let count = 0;

  rows.forEach(row => {
    // Transform this ONE row into canonical field names
    const m = ColMapper.transform(row, mapping);

    // Skip completely blank rows
    const hasContent = Object.values(m).some(v => v && String(v).trim());
    if (!hasContent) return;

    // Need at least a role or skills to be meaningful
    if (!m.role && !m.skills) return;

    // Normalise priority value from free-text
    const rawPri = String(m.priority || '').toLowerCase().trim();
    const priority = rawPri.includes('high') ? 'High'
      : rawPri.includes('medium') ? 'Medium'
        : rawPri.includes('low') ? 'Low'
          : 'Medium';

    // Normalise status value from free-text
    const rawStat = String(m.status || '').toLowerCase().trim();
    const status = rawStat.includes('fulfilled') ? 'Fulfilled'
      : rawStat.includes('progress') ? 'In Progress'
        : rawStat.includes('cancel') ? 'Cancelled'
          : 'Open';

    // Save this row — DB.addRequirement now uses _reqSeq for uniqueness
    DB.addRequirement({
      role: m.role || (m.skills ? m.skills.split(',')[0].trim() : 'Requirement'),
      skills: m.skills || '',
      experienceYears: m.experienceYears || '',
      designation: m.designation || '',
      location: m.location || '',
      headcount: m.headcount || '1',
      priority,
      status,
      department: m.department || myDept,
      description: m.description || '',
      forFreshers: false,
      // Preserve any unmapped extra columns
      ...Object.fromEntries(
        Object.entries(m).filter(([k]) => k.startsWith('_extra_'))
      ),
    });

    count++;
  });

  return count;
}


// ───────────────────────────────────────────────────────────────────────
// 12.  REQUIREMENTS COLUMN PICKER — unified column selector
//      Shows extra columns from Requirements, Employees & Allocations
//      Req columns render on requirement cards (dashed separator)
//      Emp/Alloc columns render on candidate match cards (dashed separator)
// ───────────────────────────────────────────────────────────────────────

const _REQ_COL_PREF_KEY = 'ra3_req_col_prefs';

function _getReqColPrefs() {
  try { return JSON.parse(localStorage.getItem(_REQ_COL_PREF_KEY) || '{}'); }
  catch { return {}; }
}
function _saveReqColPrefs(prefs) {
  localStorage.setItem(_REQ_COL_PREF_KEY, JSON.stringify(prefs));
}

/** Get all unique _extra_* field names across all requirements */
function _getExtraReqColsLocal() {
  const cols = new Set();
  DB.getRequirements(null).forEach(req => {
    Object.keys(req).forEach(k => { if (k.startsWith('_extra_')) cols.add(k); });
  });
  return [...cols].map(k => ({ key: k, label: k.replace('_extra_', ''), source: 'req' }));
}

/** Get all unique _extra_* field names across all employees */
function _getExtraEmpColsLocal() {
  const cols = new Set();
  DB.getEmployees(null).forEach(emp => {
    Object.keys(emp).forEach(k => { if (k.startsWith('_extra_')) cols.add(k); });
  });
  return [...cols].map(k => ({ key: k, label: k.replace('_extra_', ''), source: 'emp' }));
}

/** Get all unique _extra_* field names across all allocations */
function _getExtraAllocColsLocal() {
  const cols = new Set();
  DB.getAllocations(null).forEach(alloc => {
    Object.keys(alloc).forEach(k => { if (k.startsWith('_extra_')) cols.add(k); });
  });
  return [...cols].map(k => ({ key: k, label: k.replace('_extra_', ''), source: 'alloc' }));
}

/** Show unified column picker dialog for Requirements tab */
function dlgReqColumnPicker() {
  const prefs    = _getReqColPrefs();
  const selReq   = new Set(prefs.reqCols   || []);
  const selEmp   = new Set(prefs.empCols   || []);
  const selAlloc = new Set(prefs.allocCols || []);

  const reqCols   = _getExtraReqColsLocal();
  const empCols   = _getExtraEmpColsLocal();
  const allocCols = _getExtraAllocColsLocal();

  if (!reqCols.length && !empCols.length && !allocCols.length) {
    toast('No extra columns found. Import data with additional columns first.', 'info');
    return;
  }

  const renderSection = (title, icon, color, cols, selected, group) => {
    if (!cols.length) return '';
    return `
      <div style="font-weight:700;font-size:.78rem;color:${color};margin-bottom:6px;
                  border-bottom:1px solid var(--border);padding-bottom:2px">
        ${icon} ${title}
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
        ${cols.map(col => `
          <button type="button"
            id="rcp_${group}_${col.key.replace(/[^a-z0-9]/gi,'_')}"
            class="btn btn-sm ${selected.has(col.key) ? 'btn-teal' : 'btn-ghost'}"
            onclick="_toggleReqCol('${col.key.replace(/'/g,"\\'")}','${group}')"
            data-col="${col.key}" data-group="${group}">
            ${selected.has(col.key) ? '\u2611' : '\u2610'} ${col.label}
          </button>`
        ).join('')}
      </div>`;
  };

  openDlg(`
<div class="dlg-title">\u2699 Choose Extra Columns \u2014 Requirements</div>
<div style="font-size:.82rem;color:var(--text2);margin-bottom:14px">
  Select extra columns to display. <strong>Requirement columns</strong> appear on
  requirement cards. <strong>Employee/Allocation columns</strong> appear on candidate
  match cards when you click "\ud83e\udde0 Find Employees".
</div>
<div style="max-height:320px;overflow-y:auto;padding-right:5px;text-align:left">
  ${renderSection('Requirement Columns (on Requirement Cards)', '\ud83d\udccb', 'var(--purple)', reqCols, selReq, 'req')}
  ${renderSection('Employee Columns (on Candidate Cards)', '\ud83d\udc65', 'var(--teal)', empCols, selEmp, 'emp')}
  ${renderSection('Allocation Columns (on Candidate Cards)', '\ud83c\udfaf', 'var(--amber2)', allocCols, selAlloc, 'alloc')}
</div>
<div style="display:flex;gap:9px;justify-content:space-between;align-items:center;margin-top:15px">
  <div style="display:flex;gap:7px">
    <button class="btn btn-xs btn-ghost" onclick="_selectAllReqCols()">Select All</button>
    <button class="btn btn-xs btn-ghost" onclick="_clearAllReqCols()">Clear All</button>
  </div>
  <div style="display:flex;gap:9px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="_applyReqColPrefs()">Apply \u2192</button>
  </div>
</div>`);
}

function _toggleReqCol(colKey, group) {
  const prefs = _getReqColPrefs();
  const key   = group === 'req' ? 'reqCols' : group === 'emp' ? 'empCols' : 'allocCols';
  const sel   = new Set(prefs[key] || []);
  sel.has(colKey) ? sel.delete(colKey) : sel.add(colKey);
  prefs[key] = [...sel];
  _saveReqColPrefs(prefs);

  const btnId = `rcp_${group}_${colKey.replace(/[^a-z0-9]/gi,'_')}`;
  const btn   = document.getElementById(btnId);
  if (btn) {
    const label = colKey.replace('_extra_', '');
    btn.className = `btn btn-sm ${sel.has(colKey) ? 'btn-teal' : 'btn-ghost'}`;
    btn.textContent = (sel.has(colKey) ? '\u2611 ' : '\u2610 ') + label;
  }
}

function _selectAllReqCols() {
  const prefs = _getReqColPrefs();
  const reqCols   = _getExtraReqColsLocal();
  const empCols   = _getExtraEmpColsLocal();
  const allocCols = _getExtraAllocColsLocal();
  prefs.reqCols   = reqCols.map(c => c.key);
  prefs.empCols   = empCols.map(c => c.key);
  prefs.allocCols = allocCols.map(c => c.key);
  _saveReqColPrefs(prefs);

  [...reqCols, ...empCols, ...allocCols].forEach(col => {
    const group = col.source;
    const btn = document.getElementById(`rcp_${group}_${col.key.replace(/[^a-z0-9]/gi,'_')}`);
    if (btn) { btn.className = 'btn btn-sm btn-teal'; btn.textContent = '\u2611 ' + col.label; }
  });
}

function _clearAllReqCols() {
  const prefs = _getReqColPrefs();
  prefs.reqCols = []; prefs.empCols = []; prefs.allocCols = [];
  _saveReqColPrefs(prefs);

  const allCols = [..._getExtraReqColsLocal(), ..._getExtraEmpColsLocal(), ..._getExtraAllocColsLocal()];
  allCols.forEach(col => {
    const group = col.source;
    const btn = document.getElementById(`rcp_${group}_${col.key.replace(/[^a-z0-9]/gi,'_')}`);
    if (btn) { btn.className = 'btn btn-sm btn-ghost'; btn.textContent = '\u2610 ' + col.label; }
  });
}

function _applyReqColPrefs() {
  closeDlg();
  // Get all currently open match panel IDs
  const openIds = Array.from(_REQ_OPEN_PANELS.keys());
  _REQ_OPEN_PANELS.clear();

  // Re-render requirements list
  renderReqs();

  // Re-run matching for previously open panels so they update immediately with new columns
  openIds.forEach(id => {
    if (typeof findForReq === 'function') {
      findForReq(id);
    } else if (typeof _findForReq === 'function') {
      _findForReq(id);
    }
  });

  const prefs = _getReqColPrefs();
  const count = (prefs.reqCols||[]).length + (prefs.empCols||[]).length + (prefs.allocCols||[]).length;
  toast(`${count} extra column${count !== 1 ? 's' : ''} applied to Requirements tab`, 'ok');
}


// ── Build extra fields HTML for a requirement card ──────────────────────
function _buildReqExtraFields(req) {
  const prefs   = _getReqColPrefs();
  const reqCols = prefs.reqCols || [];
  if (!reqCols.length) return '';

  const fields = reqCols.map(k => {
    const v = req[k];
    if (v === undefined || v === null || String(v).trim() === '') return '';
    const label = k.replace('_extra_', '');
    return `<div style="font-size:.78rem;color:var(--text2)">
      <strong style="color:var(--purple)">${_hesc(label)}:</strong> ${_hesc(v)}
    </div>`;
  }).filter(Boolean);

  if (!fields.length) return '';
  return `<div style="margin-top:8px;display:flex;gap:16px;flex-wrap:wrap;
                      border-top:1px dashed var(--border);padding-top:6px">
    ${fields.join('')}
  </div>`;
}


// ── Build extra fields HTML for a candidate match card (emp + alloc) ────
function _buildCandidateExtraFields(emp) {
  const prefs      = _getReqColPrefs();
  const empCols    = prefs.empCols   || [];
  const allocCols  = prefs.allocCols || [];
  if (!empCols.length && !allocCols.length) return '';

  const chips = [];

  // Employee extra fields
  empCols.forEach(k => {
    const v = emp[k];
    if (v !== undefined && v !== null && String(v).trim() !== '' && String(v).trim() !== '\u2014') {
      const label = k.replace('_extra_', '');
      chips.push(`<span class="chip" style="font-size:.68rem;background:rgba(0,200,180,.08);
                   color:var(--teal);border:1px solid rgba(0,200,180,.2)"
                   title="Employee: ${_hesc(label)}">
        \ud83d\udc64 ${_hesc(label)}: ${_hesc(v)}
      </span>`);
    }
  });

  // Allocation extra fields
  if (allocCols.length) {
    const empAllocs = DB.empAllocs(emp.id);
    empAllocs.forEach(al => {
      allocCols.forEach(k => {
        const v = al[k];
        if (v !== undefined && v !== null && String(v).trim() !== '' && String(v).trim() !== '\u2014') {
          const label = k.replace('_extra_', '');
          chips.push(`<span class="chip" style="font-size:.68rem;background:rgba(240,165,0,.08);
                       color:var(--amber2);border:1px solid rgba(240,165,0,.2)"
                       title="Allocation (${_hesc(al.projectName || '')}): ${_hesc(label)}">
            \ud83c\udfaf ${_hesc(al.projectName || '?')} \u00b7 ${_hesc(label)}: ${_hesc(v)}
          </span>`);
        }
      });
    });
  }

  if (!chips.length) return '';
  return `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;
                      padding-top:4px;border-top:1px dashed var(--border)">
    ${chips.join('')}
  </div>`;
}


// ───────────────────────────────────────────────────────────────────────
// 13.  UTILITY  — safe HTML escaping
// ───────────────────────────────────────────────────────────────────────
function _hesc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

window._buildCandidateExtraFields = _buildCandidateExtraFields;
window._getReqColPrefs = _getReqColPrefs;
window._saveReqColPrefs = _saveReqColPrefs;


// 'use strict';
// // ═══════════════════════════════════════════════════════════════════════
// // ENHANCEMENTS.JS — v4 final
// // app.js now directly has Emp ID + Certified columns baked in.
// // This file handles:
// //   1. Certified column detection during import
// //   2. Aspiring skill detection during import (any aspiring-header col)
// //   3. Certified boost in AI matching (+8 score)
// //   4. Aspiring employee search — correct implementation
// //   5. Column selector in Excel Viewer
// //   6. Empty row filtering
// //   7. "View Full Data" works correctly on Import page
// // ═══════════════════════════════════════════════════════════════════════


// // ═══════════════════════════════════════════════════════════════════════
// // 1. CERTIFIED COLUMN DETECTION
// // ═══════════════════════════════════════════════════════════════════════
// const CERT_KEYWORDS = ['certified','certification','iscertified','certifiedyn',
//   'hascertification','certifiedornot','certfied','certificationstatus',
//   'workdaycertified','wdcertified','profcertified','certifiedpro'];

// function _isCertified(emp) {
//   // Check explicit field
//   const explicit = String(emp.isCertified || emp._certified || '').toLowerCase().trim();
//   if (explicit === 'yes' || explicit === 'y' || explicit === '1' || explicit === 'true' || explicit === 'certified') return true;
//   // Scan _extra_ fields for any cert-like column
//   for (const [k, v] of Object.entries(emp)) {
//     const nk = k.replace('_extra_','').toLowerCase().replace(/[^a-z]/g,'');
//     if (CERT_KEYWORDS.some(kw => nk.includes(kw))) {
//       const val = String(v||'').toLowerCase().trim();
//       if (val === 'yes' || val === 'y' || val === '1' || val === 'true' || val === 'certified') return true;
//     }
//   }
//   return false;
// }

// // Patch DB.addEmployee to auto-detect cert from any cert-like column
// const _origAddEmp = DB.addEmployee.bind(DB);
// DB.addEmployee = function(emp) {
//   if (!emp.isCertified) {
//     for (const [k, v] of Object.entries(emp)) {
//       const nk = k.replace('_extra_','').toLowerCase().replace(/[^a-z]/g,'');
//       if (CERT_KEYWORDS.some(kw => nk.includes(kw))) {
//         const val = String(v||'').toLowerCase().trim();
//         emp.isCertified = (val==='yes'||val==='y'||val==='1'||val==='true'||val==='certified') ? 'Yes' : 'No';
//         break;
//       }
//     }
//   }
//   return _origAddEmp(emp);
// };

// // Boost certified employees in AI matching
// const _origFindMatches = AI.findMatches.bind(AI);
// AI.findMatches = function(req, dept=null) {
//   const result = _origFindMatches(req, dept);
//   const boost = arr => arr.map(e => ({
//     ...e,
//     _certified: _isCertified(e),
//     _score: _isCertified(e) ? Math.min(100, e._score+8) : e._score,
//   })).sort((a,b) => b._score - a._score);
//   return { free:boost(result.free), partial:boost(result.partial),
//            ending:boost(result.ending), internal:boost(result.internal), noMatch:boost(result.noMatch) };
// };

// const _origAISearch = AI.search.bind(AI);
// AI.search = function(query, dept=null) {
//   return _origAISearch(query, dept)
//     .map(e => ({ ...e, _certified:_isCertified(e),
//       _score: _isCertified(e) ? Math.min(100, e._score+8) : e._score }))
//     .sort((a,b) => b._score-a._score);
// };


// // ═══════════════════════════════════════════════════════════════════════
// // 2. ASPIRING SKILL COLUMN DETECTION IN IMPORT
// // ═══════════════════════════════════════════════════════════════════════
// const ASPIRING_KWS = ['aspiring','interestedtolearn','wantstolearn','keenon',
//   'learninginterest','wishtolearn','futureinterest','plantolearn',
//   'interested','aspireskill','developingskill','learninggoal'];

// function _isAspiringHeader(h) {
//   const n = String(h).toLowerCase().replace(/[^a-z]/g,'');
//   return ASPIRING_KWS.some(kw => n.includes(kw));
// }

// // Extend ColMapper.mergeAllSkillColumns to pick up aspiring columns
// const _origMerge = ColMapper.mergeAllSkillColumns.bind(ColMapper);
// ColMapper.mergeAllSkillColumns = function(row, mapping) {
//   const base = _origMerge(row, mapping);
//   const already = new Set(base.split(',').map(s=>s.trim().toLowerCase()).filter(Boolean));
//   const extra = [];
//   for (const [header, value] of Object.entries(row)) {
//     if (!value || !String(value).trim()) continue;
//     if (_isAspiringHeader(header)) {
//       String(value).split(/[,;|]/).map(s=>s.trim()).filter(Boolean).forEach(skill => {
//         const key = skill.toLowerCase().replace(' (aspiring)','');
//         if (!already.has(key) && !already.has(key+' (aspiring)')) {
//           extra.push(`${skill} (aspiring)`);
//           already.add(key);
//         }
//       });
//     }
//   }
//   return extra.length ? [base,...extra].filter(Boolean).join(', ') : base;
// };


// // ═══════════════════════════════════════════════════════════════════════
// // 3. EMPTY ROW FILTERING — patch XL.parse
// // ═══════════════════════════════════════════════════════════════════════
// const _origParse = XL.parse.bind(XL);
// XL.parse = async function(file) {
//   const rows = await _origParse(file);
//   const filtered = rows.filter(row =>
//     Object.values(row).some(v => {
//       if (v === null || v === undefined) return false;
//       const s = String(v).trim();
//       return s !== '' && s !== '0' && !/^(na|n\/a|none|-+)$/i.test(s);
//     })
//   );
//   if (rows.length !== filtered.length)
//     console.log(`[XL] Skipped ${rows.length-filtered.length} empty rows in ${file.name}`);
//   return filtered;
// };


// // ═══════════════════════════════════════════════════════════════════════
// // 4. CERTIFIED BADGE IN AI SEARCH MATCH CARDS
// // ═══════════════════════════════════════════════════════════════════════
// // Patch doAISearch to add cert badge and aspiring section
// const _origDoAI = doAISearch;
// window.doAISearch = function() {
//   _origDoAI();
//   setTimeout(() => {
//     const resEl = document.getElementById('ai-results');
//     if (!resEl) return;

//     // Add 🏅 badge to certified employees in existing cards
//     resEl.querySelectorAll('.ai-card').forEach(card => {
//       if (card.querySelector('.cert-badge-ai')) return;
//       const nameEl = card.querySelector('strong');
//       if (!nameEl) return;
//       const name = nameEl.textContent.trim();
//       const emp  = DB.getEmployees().find(e => e.name === name);
//       if (emp && _isCertified(emp)) {
//         const badge = document.createElement('span');
//         badge.className = 'badge b-green cert-badge-ai';
//         badge.style.marginLeft = '5px';
//         badge.title = 'Certified';
//         badge.textContent = '🏅 Certified';
//         nameEl.parentNode.insertBefore(badge, nameEl.nextSibling);
//       }
//     });

//     // Add aspiring section
//     const query = document.getElementById('ai-q')?.value.trim();
//     if (!query || document.getElementById('aspiring-section-ai')) return;

//     const deptF     = document.getElementById('ai-dept')?.value || '';
//     const deptScope = (CU?.role === 'admin') ? (deptF||null) : CU?.department;

//     const stopWords = new Set(['and','the','with','for','who','can','have','need',
//       'want','find','in','at','from','year','years','experience',
//       'senior','junior','lead','manager','developer','engineer']);
//     const terms = query.toLowerCase().split(/\s+/)
//       .filter(w => w.length > 2 && !stopWords.has(w) && !/^\d/.test(w));

//     const aspiringEmps = [];
//     terms.forEach(term => {
//       _findAspiringForSkill(term, deptScope).forEach(e => {
//         if (!aspiringEmps.find(x => x.id === e.id)) aspiringEmps.push(e);
//       });
//     });

//     if (!aspiringEmps.length) return;

//     const sec = document.createElement('div');
//     sec.id = 'aspiring-section-ai';
//     sec.innerHTML = `
// <div style="margin-top:20px;padding-top:14px;border-top:2px dashed rgba(165,94,234,.35)">
//   <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
//     <span style="font-size:.85rem;font-weight:800;color:var(--purple)">
//       📚 Interested to Learn — ${aspiringEmps.length} employee${aspiringEmps.length>1?'s':''}
//     </span>
//     <span class="badge b-gray">Not currently skilled · for training only</span>
//   </div>
//   ${aspiringEmps.map((e,i) => _buildAspiringCard(e, i)).join('')}
// </div>`;
//     resEl.appendChild(sec);
//   }, 750);
// };
// const doAISearch = window.doAISearch;


// // ═══════════════════════════════════════════════════════════════════════
// // 5. ASPIRING SEARCH HELPERS
// // ═══════════════════════════════════════════════════════════════════════

// /** Find employees who have a skill as ASPIRING only (not in main skills) */
// function _findAspiringForSkill(skillQuery, dept=null) {
//   if (!skillQuery) return [];
//   const q = skillQuery.toLowerCase().trim();
//   return DB.getEmployees(dept).filter(emp => {
//     // Must NOT be in main (non-aspiring) skills
//     const mainSkills = AI.getSkillList(emp).map(s => s.toLowerCase());
//     if (mainSkills.some(s => s.includes(q) || q.includes(s))) return false;
//     // Must be in aspiring skills
//     const aspiringList = AI.getAspiringSkills(emp).map(s => s.toLowerCase());
//     return aspiringList.some(s => s.includes(q) || q.includes(s));
//   }).map(emp => {
//     const aspiringList = AI.getAspiringSkills(emp);
//     return {
//       ...emp,
//       _util:  DB.empUtil(emp.id),
//       _avail: 100 - DB.empUtil(emp.id),
//       _aspiringMatch: aspiringList.filter(s => s.toLowerCase().includes(q) || q.includes(s.toLowerCase())),
//     };
//   });
// }

// /** Aspiring card HTML */
// function _buildAspiringCard(emp, idx) {
//   const empB      = BAND.normalize(emp.designation||emp.band||'');
//   const certified = _isCertified(emp);
//   const empIdHtml = emp.employeeId
//     ? `<span style="font-family:var(--mono);font-size:.72rem;color:var(--text3)">${emp.employeeId}</span>` : '';
//   return `
// <div style="border:1px solid rgba(165,94,234,.35);border-left:4px solid var(--purple);
//             border-radius:var(--r);padding:13px 16px;margin-top:9px;
//             background:rgba(165,94,234,.04)">
//   <div style="display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap">
//     <div style="font-weight:900;font-size:.75rem;color:var(--text3);width:20px;padding-top:4px">#${idx+1}</div>
//     <div style="width:48px;height:48px;border-radius:50%;border:2px dashed var(--purple);
//                 display:flex;align-items:center;justify-content:center;flex-direction:column;
//                 font-size:.62rem;font-weight:700;color:var(--purple);
//                 background:rgba(165,94,234,.1);text-align:center;flex-shrink:0;line-height:1.3">
//       📚<span>Learn</span>
//     </div>
//     <div style="flex:1;min-width:180px">
//       <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:4px">
//         <strong style="font-size:.95rem">${emp.name}</strong>
//         ${empB ? BAND.renderBand(empB) : ''}
//         <span class="badge b-blue">${emp.department||'—'}</span>
//         ${empIdHtml}
//         ${certified ? '<span class="badge b-green">🏅 Certified</span>' : ''}
//       </div>
//       <div style="font-size:.76rem;color:var(--text2);margin-bottom:5px">
//         ${AI.getEffectiveExp(emp)||'?'} yrs · 📍 ${emp.location||'—'}
//       </div>
//       <div style="margin-bottom:6px">${skillChips(emp.skills||'', 5)}</div>
//       <div style="background:rgba(165,94,234,.1);border:1px solid rgba(165,94,234,.25);
//                   border-radius:var(--r-sm);padding:8px 12px;font-size:.78rem;line-height:1.55">
//         <strong style="color:var(--purple)">📚 Interested to learn:</strong>
//         ${(emp._aspiringMatch||[]).map(s =>
//           `<span class="chip" style="background:rgba(165,94,234,.15);color:var(--purple);
//            border:1px solid rgba(165,94,234,.3)">${s}</span>`
//         ).join('')}
//         <div style="color:var(--text3);font-size:.73rem;margin-top:4px;font-style:italic">
//           This employee does not currently have this skill. Suitable for training pipelines or shadow programmes only.
//         </div>
//       </div>
//     </div>
//     <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0">
//       ${availBadge(emp._avail)}
//       <div style="font-size:.69rem;color:var(--text3)">${emp._util}% utilised</div>
//       <button class="btn btn-xs btn-outline" onclick="dlgAllocate('${emp.id}')">View</button>
//     </div>
//   </div>
// </div>`;
// }

// // Make these globally accessible (for requirements.js to call)
// window._findAspiringForSkill = _findAspiringForSkill;
// window._buildAspiringCard    = _buildAspiringCard;
// window._isCertified          = _isCertified;


// // ═══════════════════════════════════════════════════════════════════════
// // 6. ASPIRING SECTION IN REQUIREMENTS MATCHING
// //    Called after _computeMatchHtml renders results in requirements.js
// // ═══════════════════════════════════════════════════════════════════════
// // Patch _findForReq (from requirements.js) to add aspiring section
// // We delay until requirements.js has loaded so _findForReq is defined
// setTimeout(() => {
//   if (typeof _findForReq !== 'function') return;
//   const _origFindForReq = _findForReq;
//   window._findForReq = function(reqId) {
//     _origFindForReq(reqId);
//     // After the match results render, append aspiring section
//     setTimeout(() => {
//       const req   = DB.getRequirements().find(r => r.id === reqId);
//       if (!req) return;
//       const panel = document.getElementById(`rmp-${reqId}`);
//       if (!panel) return;

//       const deptScope = (CU?.role === 'admin') ? null : CU?.department;
//       const reqSkills = String(req.skills||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
//       if (!reqSkills.length) return;

//       const aspiringEmps = [];
//       reqSkills.forEach(skill => {
//         _findAspiringForSkill(skill, deptScope).forEach(e => {
//           if (!aspiringEmps.find(x => x.id === e.id)) aspiringEmps.push(e);
//         });
//       });

//       if (!aspiringEmps.length) return;
//       if (panel.querySelector('.aspiring-req-section')) return;

//       const sec = document.createElement('div');
//       sec.className = 'aspiring-req-section';
//       sec.innerHTML = `
// <div style="margin-top:14px;padding:12px 14px;
//             border:1px dashed rgba(165,94,234,.35);border-radius:var(--r);
//             background:rgba(165,94,234,.03)">
//   <div style="font-weight:700;font-size:.84rem;color:var(--purple);margin-bottom:10px">
//     📚 Interested to Learn (${aspiringEmps.length})
//     <span style="font-weight:400;color:var(--text3);font-size:.76rem;margin-left:6px">
//       — No current skill · training pipeline candidates only
//     </span>
//   </div>
//   ${aspiringEmps.map((e,i) => _buildAspiringCard(e, i)).join('')}
// </div>`;
//       panel.appendChild(sec);
//     }, 900);
//   };
//   // Re-wire the delegated listener to use the new function
//   const container = document.getElementById('req-container');
//   if (container) {
//     // Remove old listener by replacing the container's clone
//     // (The listener is anonymous so we patch via the delegated action)
//     console.log('[Enhancements] _findForReq patched for aspiring section');
//   }
// }, 100);


// // ═══════════════════════════════════════════════════════════════════════
// // 7. COLUMN SELECTOR FOR EXCEL VIEWER
// // ═══════════════════════════════════════════════════════════════════════
// const _hiddenViewerCols = { skills: new Set(), alloc: new Set(), req: new Set() };

// // Wrap renderFullViewer
// setTimeout(() => {
//   if (typeof renderFullViewer !== 'function') return;
//   const _origViewer = renderFullViewer;
//   window.renderFullViewer = function(activeType) {
//     _origViewer(activeType);
//     setTimeout(() => _injectColSelector(activeType), 60);
//   };
//   // Also make filterViewerTable available globally (it's defined in importer.js)
// }, 50);

// function _injectColSelector(type) {
//   const buf = BUFS[type]; if (!buf || !buf.rows.length) return;
//   const mapping  = MAPS[type] || {};
//   const headers  = Object.keys(buf.rows[0] || {});
//   const unmapped = ColMapper.unmapped(headers, mapping);
//   if (!unmapped.length) return;

//   const wrap = document.getElementById('viewer-table-wrap');
//   if (!wrap) return;
//   if (document.getElementById('col-sel-panel')) document.getElementById('col-sel-panel').remove();

//   const panel = document.createElement('div');
//   panel.id = 'col-sel-panel';
//   panel.style.cssText = 'padding:10px 18px;border-bottom:1px solid var(--border);' +
//     'background:rgba(165,94,234,.04);display:flex;flex-wrap:wrap;gap:7px;align-items:center';
//   panel.innerHTML = `
//     <span style="font-size:.71rem;font-weight:700;text-transform:uppercase;
//                  letter-spacing:.07em;color:var(--text3);flex-shrink:0">
//       👁 Extra columns:
//     </span>
//     ${unmapped.map(h => {
//       const sid = 'csbtn_' + h.replace(/[^a-z0-9]/gi,'_');
//       const hidden = _hiddenViewerCols[type]?.has(h);
//       return `<button id="${sid}"
//         class="btn btn-xs ${hidden?'btn-ghost':'btn-outline'}"
//         style="${hidden?'opacity:.4;':''}"
//         onclick="_toggleViewCol(${JSON.stringify(h)},'${type}')">
//         ${hidden?'☐':'☑'} ${h}
//       </button>`;
//     }).join('')}
//     <button class="btn btn-xs btn-teal" style="margin-left:auto"
//       onclick="_showAllViewCols('${type}')">Show All</button>
//     <button class="btn btn-xs btn-ghost"
//       onclick="_hideExtraViewCols('${type}')">Hide Extras</button>`;
//   wrap.parentNode.insertBefore(panel, wrap);
// }

// function _toggleViewCol(header, type) {
//   if (!_hiddenViewerCols[type]) _hiddenViewerCols[type] = new Set();
//   _hiddenViewerCols[type].has(header) ? _hiddenViewerCols[type].delete(header) : _hiddenViewerCols[type].add(header);
//   _applyViewColVisibility(type); _refreshViewColBtns(type);
// }
// function _showAllViewCols(type) {
//   _hiddenViewerCols[type] = new Set(); _applyViewColVisibility(type); _refreshViewColBtns(type);
// }
// function _hideExtraViewCols(type) {
//   const buf = BUFS[type]; if (!buf) return;
//   _hiddenViewerCols[type] = new Set(ColMapper.unmapped(Object.keys(buf.rows[0]||{}), MAPS[type]||{}));
//   _applyViewColVisibility(type); _refreshViewColBtns(type);
// }
// function _applyViewColVisibility(type) {
//   const buf = BUFS[type]; if (!buf) return;
//   const headers = Object.keys(buf.rows[0]||{});
//   const table   = document.querySelector('#viewer-table-wrap table');
//   if (!table) return;
//   headers.forEach((h, i) => {
//     const hidden = _hiddenViewerCols[type]?.has(h);
//     const nth    = i + 2; // +1 for row# col, +1 for 1-based
//     table.querySelectorAll(`thead tr th:nth-child(${nth}), tbody tr td:nth-child(${nth})`)
//       .forEach(el => el.style.display = hidden ? 'none' : '');
//   });
// }
// function _refreshViewColBtns(type) {
//   const buf = BUFS[type]; if (!buf) return;
//   const headers  = Object.keys(buf.rows[0]||{});
//   ColMapper.unmapped(headers, MAPS[type]||{}).forEach(h => {
//     const el = document.getElementById('csbtn_'+h.replace(/[^a-z0-9]/gi,'_'));
//     if (!el) return;
//     const hidden = _hiddenViewerCols[type]?.has(h);
//     el.className = `btn btn-xs ${hidden?'btn-ghost':'btn-outline'}`;
//     el.style.opacity = hidden ? '.4' : '1';
//     el.innerHTML = `${hidden?'☐':'☑'} ${h}`;
//   });
// }


'use strict';
// ═══════════════════════════════════════════════════════════════════════
// ENHANCEMENTS.JS — v5 final
//
// Fixes in this version:
//   1. Certified: dynamic scan of ALL _extra_* keys — no hardcoded names
//   2. Aspiring double-display: removed from main search, only purple chips
//   3. Aspiring in AI Search: shows employees with aspiring-only skills
//   4. Column Selector: persistent user config to add extra columns to
//      Employees / Allocations / Requirements tabs
//   5. Column Selector in Excel Viewer (show/hide extra cols in viewer)
//   6. Empty row filtering in import
// ═══════════════════════════════════════════════════════════════════════

// ── Cert keyword list (shared) ─────────────────────────────────────────
const CERT_KWS = ['certified','certification','iscertified','certifiedyn',
  'hascertification','certifiedornot','certfied','certificationstatus',
  'workdaycertified','wdcertified'];

/** Robust certified check — scans all _extra_* keys dynamically */
/** Robust certified check — scans all _extra_* keys dynamically */
function _isCertified(emp) {
  if (!emp) return false;
  
  const isNegative = val => {
    const s = String(val || '').toLowerCase().trim();
    return !s || s === 'no' || s === 'n' || s === '0' || s === 'false' || s === 'none' || s === 'n/a' || s === '-';
  };

  const ex = String(emp.isCertified || emp._certified || '').toLowerCase().trim();
  if (ex && !isNegative(ex)) return true;

  for (const [k, v] of Object.entries(emp)) {
    if (!k.startsWith('_extra_')) continue;
    const nk = k.replace('_extra_','').toLowerCase().replace(/[^a-z]/g,'');
    if (CERT_KWS.some(kw => nk.includes(kw))) {
      if (v && !isNegative(v)) return true;
    }
  }
  return false;
}

// Patch DB.addEmployee to auto-store isCertified from cert-like columns
const _origAddEmp = DB.addEmployee.bind(DB);
DB.addEmployee = function(emp) {
  let certVal = '';

  // 1. Check if there's an explicit isCertified field
  if (emp.isCertified !== undefined && emp.isCertified !== null && String(emp.isCertified).trim() !== '') {
    certVal = String(emp.isCertified).trim();
  }

  // 2. Scan all properties (especially extra fields) for cert keywords if explicit is empty
  const isNegative = val => {
    const s = String(val || '').toLowerCase().trim();
    return !s || s === 'no' || s === 'n' || s === '0' || s === 'false' || s === 'none' || s === 'n/a' || s === '-';
  };

  if (!certVal || isNegative(certVal)) {
    for (const [k, v] of Object.entries(emp)) {
      if (k === 'isCertified') continue;
      const nk = k.replace('_extra_','').toLowerCase().replace(/[^a-z]/g,'');
      if (CERT_KWS.some(kw => nk.includes(kw))) {
        const val = String(v||'').trim();
        if (val && !isNegative(val)) {
          certVal = val;
          break;
        }
      }
    }
  }

  // 3. Set the normalized value
  if (certVal && !isNegative(certVal)) {
    emp.isCertified = 'Yes';
  } else {
    emp.isCertified = 'No';
  }

  return _origAddEmp(emp);
};

// Boost certified employees +8 in AI matching
const _origFindMatches = AI.findMatches.bind(AI);
AI.findMatches = function(req, dept=null) {
  const result = _origFindMatches(req, dept);
  const boost = arr => arr.map(e => ({
    ...e, _certified:_isCertified(e),
    _score: _isCertified(e) ? Math.min(100, e._score+8) : e._score,
  })).sort((a,b)=>b._score-a._score);
  return { free:boost(result.free), partial:boost(result.partial),
           ending:boost(result.ending), internal:boost(result.internal), noMatch:boost(result.noMatch) };
};

// Complete rewrite of AI.search to avoid band substring matching issue (e.g. "security" matching "c1")
AI.search = function(query, dept=null) {
  console.log("=== AI.search query ===", query);
  if (!query.trim()) return [];
  const q = query.toLowerCase();

  // Extract band using word boundaries to avoid matching inside other words (like "c1" in "security")
  let reqBand = null;
  for (const b of BAND.ORDER) {
    const rx = new RegExp('\\b' + b + '\\b', 'i');
    if (rx.test(q)) { reqBand = b; break; }
  }
  if (!reqBand) {
    const aliases = ['junior','fresher','senior','lead','manager','principal'];
    for (const a of aliases) {
      const rx = new RegExp('\\b' + a + '\\b', 'i');
      if (rx.test(q)) { reqBand = BAND.normalize(a); break; }
    }
  }

  // Extract experience, location, skills
  const yM = q.match(/(\d+)\+?\s*(?:years?|yrs?|yr)/i);
  const reqExp = yM ? parseInt(yM[1]) : 0;
  const locM = q.match(/(?:in|at|from|based in)\s+([a-z][a-z ]{1,18}?)(?:\s|,|$)/i);
  const reqLoc = locM ? locM[1].trim() : '';
  
  const stopWords = new Set(['and','the','with','for','who','can','have','need','want','find','search','in','at','from','based','located','year','years','experience','senior','junior','lead','manager','developer','engineer']);
  const skillTerms = q.split(/\s+/).filter(w => w.length > 2 && !stopWords.has(w) && !/^\d/.test(w));
  console.log("skillTerms:", skillTerms);

  const employees = DB.getEmployees(dept);
  const validBands = reqBand ? BAND.getValidBands(reqBand) : [...BAND.ORDER];
  console.log("reqBand:", reqBand, "validBands:", validBands);

  // 1. Find main matches (those who have the skill as a primary/secondary skill)
  const mainMatches = [];
  for (const emp of employees) {
    const empBand = BAND.normalize(emp.designation || emp.band || emp.level || '');
    if (reqBand && empBand && !validBands.includes(empBand)) continue;
    
    const empSkills = AI.getSkillList(emp);
    const empSkillStr = empSkills.join(' ').toLowerCase();
    const empUtil = DB.empUtil(emp.id);
    const empAvail = 100 - empUtil;
    const empExp = AI.getEffectiveExp(emp);
    const empLoc = String(emp.location || '').toLowerCase();

    let skillHits = 0;
    for (const t of skillTerms) {
      if (empSkillStr.includes(t) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(t) && empSkillStr.includes(ex))) {
        skillHits++;
      }
    }
    const skillScore = skillTerms.length ? Math.round(skillHits / skillTerms.length * 100) : 70;
    if (skillScore === 0 && skillTerms.length > 0) continue;

    const expScore = reqExp ? (empExp >= reqExp ? 100 : empExp >= (reqExp - 1) ? 75 : 40) : 80;
    const bandScore = empBand && reqBand ? Math.max(0, 100 - BAND.indexOf(reqBand) - BAND.indexOf(empBand) * 5) : 70;
    const availScore = empAvail >= 100 ? 100 : empAvail >= 50 ? 80 : empAvail >= 30 ? 55 : 30;
    const locScore = reqLoc ? (empLoc.includes(reqLoc) || reqLoc.includes(empLoc) ? 100 : 35) : 80;
    
    // Add certified boost (+8)
    const certified = _isCertified(emp);
    let score = Math.round(skillScore * 0.40 + expScore * 0.25 + bandScore * 0.15 + availScore * 0.12 + locScore * 0.08);
    if (certified) score = Math.min(100, score + 8);
    
    if (score < 15) continue;

    const empAllocs = DB.empAllocs(emp.id);
    mainMatches.push({
      ...emp,
      _score: score,
      _util: empUtil,
      _avail: empAvail,
      _band: empBand,
      _certified: certified,
      _endingSoon: empAllocs.some(a => AI.endingWithinDays(a, 60)),
      _allInternal: empAllocs.length > 0 && empAllocs.every(a => AI.isInternal(a.projectName)),
      _breakdown: { skill: skillScore, exp: expScore, band: bandScore, avail: availScore, loc: locScore }
    });
  }
  console.log("mainMatches count:", mainMatches.length);

  // 2. Find aspiring matches (those who only have the skill as an aspiring skill)
  const aspiringMatches = [];
  if (skillTerms.length > 0) {
    for (const emp of employees) {
      // Skip if already in mainMatches
      if (mainMatches.some(m => m.id === emp.id)) continue;

      // Band filter
      const empBand = BAND.normalize(emp.designation || emp.band || emp.level || '');
      if (reqBand && empBand && !validBands.includes(empBand)) continue;

      // Aspiring check
      const aspiringList = AI.getAspiringSkills(emp).map(s => s.toLowerCase());
      let aspiringHits = 0;
      const matchedAspiring = [];
      for (const t of skillTerms) {
        const match = aspiringList.find(s => s.includes(t) || t.includes(s) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(t) && s.includes(ex)));
        if (match) {
          aspiringHits++;
          const origMatch = AI.getAspiringSkills(emp).find(s => s.toLowerCase() === match);
          if (origMatch && !matchedAspiring.includes(origMatch)) {
            matchedAspiring.push(origMatch);
          }
        }
      }
      if (aspiringHits === 0) continue;

      // Score calculation
      const skillScore = Math.round(aspiringHits / skillTerms.length * 35); // Capped lower for aspiring
      const empUtil = DB.empUtil(emp.id);
      const empAvail = 100 - empUtil;
      const empExp = AI.getEffectiveExp(emp);
      const empLoc = String(emp.location || '').toLowerCase();

      const expScore = reqExp ? (empExp >= reqExp ? 100 : empExp >= (reqExp - 1) ? 75 : 40) : 80;
      const bandScore = empBand && reqBand ? Math.max(0, 100 - BAND.indexOf(reqBand) - BAND.indexOf(empBand) * 5) : 70;
      const availScore = empAvail >= 100 ? 100 : empAvail >= 50 ? 80 : empAvail >= 30 ? 55 : 30;
      const locScore = reqLoc ? (empLoc.includes(reqLoc) || reqLoc.includes(empLoc) ? 100 : 35) : 80;

      const certified = _isCertified(emp);
      let score = Math.round(skillScore * 0.40 + expScore * 0.25 + bandScore * 0.15 + availScore * 0.12 + locScore * 0.08);
      if (certified) score = Math.min(100, score + 8);

      const empAllocs = DB.empAllocs(emp.id);
      aspiringMatches.push({
        ...emp,
        _score: score,
        _util: empUtil,
        _avail: empAvail,
        _band: empBand,
        _certified: certified,
        _isAspiringSearchMatch: true,
        _matchedAspiringSkills: matchedAspiring,
        _endingSoon: empAllocs.some(a => AI.endingWithinDays(a, 60)),
        _allInternal: empAllocs.length > 0 && empAllocs.every(a => AI.isInternal(a.projectName)),
        _breakdown: { skill: skillScore, exp: expScore, band: bandScore, avail: availScore, loc: locScore }
      });
    }
  }

  const combined = [...mainMatches, ...aspiringMatches];
  console.log("combined matches count:", combined.length);
  return combined.sort((a, b) => b._score - a._score);
};

// ─────────────────────────────────────────────────────────────────────
// ASPIRING SKILL IMPORT — detect aspiring-header columns
// ─────────────────────────────────────────────────────────────────────
const ASPIRING_KWS = ['aspiring','interestedtolearn','wantstolearn','keenon',
  'learninginterest','wishtolearn','futureinterest','plantolearn',
  'interested','aspireskill','developingskill','learninggoal'];

function _isAspiringHeader(h) {
  const n = String(h).toLowerCase().replace(/[^a-z]/g,'');
  return ASPIRING_KWS.some(kw => n.includes(kw));
}

const _origMerge = ColMapper.mergeAllSkillColumns.bind(ColMapper);
ColMapper.mergeAllSkillColumns = function(row, mapping) {
  const base = _origMerge(row, mapping);
  const already = new Set(base.split(',').map(s=>s.trim().toLowerCase().replace(' (aspiring)','')).filter(Boolean));
  const extra = [];
  for (const [header, value] of Object.entries(row)) {
    if (!value || !String(value).trim()) continue;
    if (_isAspiringHeader(header)) {
      String(value).split(/[,;|]/).map(s=>s.trim()).filter(Boolean).forEach(skill => {
        const key = skill.toLowerCase().replace(' (aspiring)','');
        if (!already.has(key)) { extra.push(`${skill} (aspiring)`); already.add(key); }
      });
    }
  }
  return extra.length ? [base,...extra].filter(Boolean).join(', ') : base;
};

// Empty row filter
const _origParse = XL.parse.bind(XL);
XL.parse = async function(file) {
  const rows = await _origParse(file);
  return rows.filter(row => Object.values(row).some(v => {
    if (v===null||v===undefined) return false;
    const s=String(v).trim();
    return s!==''&&s!=='0'&&!/^(na|n\/a|none|-+)$/i.test(s);
  }));
};

// ─────────────────────────────────────────────────────────────────────
// ASPIRING EMPLOYEE LOOKUP
// ─────────────────────────────────────────────────────────────────────
function _findAspiringForSkill(skillQuery, dept=null) {
  if (!skillQuery) return [];
  const q = skillQuery.toLowerCase().trim();
  return DB.getEmployees(dept).filter(emp => {
    const mainSkills = AI.getSkillList(emp).map(s=>s.toLowerCase());
    const mainMatch = mainSkills.some(s => s.includes(q) || q.includes(s) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(q) && s.includes(ex)));
    if (mainMatch) return false;
    const aspiringList = AI.getAspiringSkills(emp).map(s=>s.toLowerCase());
    return aspiringList.some(s => s.includes(q) || q.includes(s) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(q) && s.includes(ex)));
  }).map(emp => {
    const aspiringList = AI.getAspiringSkills(emp);
    const matched = aspiringList.filter(s => {
      const ls = s.toLowerCase();
      return ls.includes(q) || q.includes(ls) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(q) && ls.includes(ex));
    });
    return {
      ...emp,
      _util:  DB.empUtil(emp.id),
      _avail: 100-DB.empUtil(emp.id),
      _aspiringMatch: matched,
    };
  });
}

function _buildAspiringCard(emp, idx) {
  const empB      = BAND.normalize(emp.designation||emp.band||'');
  const certified = _isCertified(emp);
  const empIdHtml = emp.employeeId ? `<span style="font-family:var(--mono);font-size:.72rem;color:var(--text3)">${emp.employeeId}</span>` : '';
  return `
<div style="border:1px solid rgba(165,94,234,.35);border-left:4px solid var(--purple);
            border-radius:var(--r);padding:13px 16px;margin-top:9px;background:rgba(165,94,234,.04)">
  <div style="display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap">
    <div style="font-weight:900;font-size:.75rem;color:var(--text3);width:20px;padding-top:4px">#${idx+1}</div>
    <div style="width:48px;height:48px;border-radius:50%;border:2px dashed var(--purple);
                display:flex;align-items:center;justify-content:center;flex-direction:column;
                font-size:.62rem;font-weight:700;color:var(--purple);
                background:rgba(165,94,234,.1);text-align:center;flex-shrink:0;line-height:1.3">
      📚<span>Learn</span>
    </div>
    <div style="flex:1;min-width:180px">
      <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:4px">
        <strong style="font-size:.95rem">${emp.name}</strong>
        ${empB?BAND.renderBand(empB):''}
        <span class="badge b-blue">${emp.department||'—'}</span>
        ${empIdHtml}
        ${certified?'<span class="badge b-green">🏅 Certified</span>':''}
      </div>
      <div style="font-size:.76rem;color:var(--text2);margin-bottom:5px">
        ${AI.getEffectiveExp(emp)||'?'} yrs · 📍 ${emp.location||'—'}
      </div>
      <div style="margin-bottom:6px">${skillChips(emp.skills||'',5)}</div>
      <div style="background:rgba(165,94,234,.1);border:1px solid rgba(165,94,234,.25);
                  border-radius:var(--r-sm);padding:8px 12px;font-size:.78rem;line-height:1.55">
        <strong style="color:var(--purple)">📚 Interested to learn:</strong>
        ${(emp._aspiringMatch||[]).map(s=>`<span class="chip" style="background:rgba(165,94,234,.15);color:var(--purple);border:1px solid rgba(165,94,234,.3)">${s}</span>`).join('')}
        <div style="color:var(--text3);font-size:.73rem;margin-top:4px;font-style:italic">
          Does not currently have this skill. Suitable for training pipelines or shadow programmes only.
        </div>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0">
      ${availBadge(emp._avail)}
      <div style="font-size:.69rem;color:var(--text3)">${emp._util}% utilised</div>
      <button class="btn btn-xs btn-outline" onclick="dlgAllocate('${emp.id}')">View</button>
    </div>
  </div>
</div>`;
}

window._findAspiringForSkill = _findAspiringForSkill;
window._buildAspiringCard    = _buildAspiringCard;
window._isCertified          = _isCertified;

// ─────────────────────────────────────────────────────────────────────
// PATCH doAISearch — add certified badges + aspiring section
// ─────────────────────────────────────────────────────────────────────
const _origDoAI = doAISearch;
window.doAISearch = function() {
  _origDoAI();
  setTimeout(() => {
    const resEl = document.getElementById('ai-results');
    if (!resEl) return;

    const query = document.getElementById('ai-q')?.value.trim();
    if (!query) return;

    const stopWords = new Set(['and','the','with','for','who','can','have','need',
      'want','find','in','at','from','year','years','experience',
      'senior','junior','lead','manager','developer','engineer']);
    const terms = query.toLowerCase().split(/\s+/)
      .filter(w => w.length > 2 && !stopWords.has(w) && !/^\d/.test(w));

    // Update main cards with certified and aspiring disclaimers/badges
    resEl.querySelectorAll('.ai-card').forEach(card => {
      const nameEl = card.querySelector('strong');
      if (!nameEl) return;
      const name = nameEl.textContent.trim();
      const emp = DB.getEmployees().find(e => e.name === name);
      if (!emp) return;

      // 1. Add certified badge
      if (_isCertified(emp) && !card.querySelector('.cert-badge-ai')) {
        const b = document.createElement('span');
        b.className = 'badge b-green cert-badge-ai';
        b.style.marginLeft = '5px';
        b.textContent = '🏅 Certified';
        nameEl.insertAdjacentElement('afterend', b);
      }

      // 2. Add aspiring badge and disclaimer if this card is an aspiring match
      const mainSkills = AI.getSkillList(emp).map(s => s.toLowerCase());
      const aspiringList = AI.getAspiringSkills(emp).map(s => s.toLowerCase());
      const matchedAspiring = [];
      
      for (const t of terms) {
        const isMain = mainSkills.some(s => s.includes(t) || t.includes(s) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(t) && s.includes(ex)));
        if (!isMain) {
          const match = aspiringList.find(s => s.includes(t) || t.includes(s) || [...Object.values(AI.CONCEPTS)].flat().some(ex => ex.includes(t) && s.includes(ex)));
          if (match) {
            const origMatch = AI.getAspiringSkills(emp).find(s => s.toLowerCase() === match);
            if (origMatch && !matchedAspiring.includes(origMatch)) {
              matchedAspiring.push(origMatch);
            }
          }
        }
      }

      if (matchedAspiring.length > 0 && !card.querySelector('.aspiring-disclaimer-ai')) {
        // Add "Interested to Learn" badge
        const badge = document.createElement('span');
        badge.className = 'badge b-purple aspiring-badge-ai';
        badge.style.marginLeft = '5px';
        badge.textContent = '📚 Interested to Learn';
        nameEl.insertAdjacentElement('afterend', badge);

        // Add disclaimer under details
        const detailsEl = card.querySelector('div[style*="flex:1"]');
        if (detailsEl) {
          const disc = document.createElement('div');
          disc.className = 'aspiring-disclaimer-ai';
          disc.style.cssText = 'margin-top:8px;background:rgba(165,94,234,.06);border:1px solid rgba(165,94,234,.2);border-left:3px solid var(--purple);padding:6px 10px;border-radius:var(--r-sm);font-size:.76rem;color:var(--purple);line-height:1.4';
          const formattedSkills = matchedAspiring.join(', ');
          disc.innerHTML = `📚 <strong>Training Candidate:</strong> This employee is not currently skilled in <strong>${formattedSkills}</strong>, but has expressed interest in learning it.`;
          detailsEl.appendChild(disc);
        }
      }
    });

    // 3. Render aspiring section at the bottom for any other matching aspiring employees not in main results
    if (document.getElementById('aspiring-section-ai')) return;
    const deptF = document.getElementById('ai-dept')?.value || '';
    const deptScope = (CU?.role === 'admin') ? (deptF || null) : CU?.department;

    const aspiringEmps = [];
    terms.forEach(term => {
      _findAspiringForSkill(term, deptScope).forEach(e => {
        // Filter out if already rendered in main results
        const isAlreadyShown = Array.from(resEl.querySelectorAll('.ai-card strong'))
          .some(strong => strong.textContent.trim() === e.name);
        if (!isAlreadyShown && !aspiringEmps.find(x => x.id === e.id)) {
          aspiringEmps.push(e);
        }
      });
    });
    if (!aspiringEmps.length) return;

    const sec = document.createElement('div');
    sec.id = 'aspiring-section-ai';
    sec.innerHTML = `
<div style="margin-top:20px;padding-top:14px;border-top:2px dashed rgba(165,94,234,.35)">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
    <span style="font-size:.85rem;font-weight:800;color:var(--purple)">
      📚 Interested to Learn — ${aspiringEmps.length} employee${aspiringEmps.length > 1 ? 's' : ''}
    </span>
    <span class="badge b-gray">Not currently skilled · for training / shadow programme only</span>
  </div>
  ${aspiringEmps.map((e, i) => _buildAspiringCard(e, i)).join('')}
</div>`;
    resEl.appendChild(sec);
  }, 750);
};

// ─────────────────────────────────────────────────────────────────────
// ASPIRING IN REQUIREMENTS — patch _findForReq after requirements.js loads
// ─────────────────────────────────────────────────────────────────────
setTimeout(() => {
  if (typeof _findForReq !== 'function') return;
  const _origFFR = _findForReq;
  window._findForReq = function(reqId) {
    _origFFR(reqId);
    setTimeout(() => {
      const req   = DB.getRequirements().find(r=>r.id===reqId); if(!req) return;
      const panel = document.getElementById(`rmp-${reqId}`) || document.getElementById(`rm-${reqId}`);    if(!panel) return;
      if (panel.querySelector('.aspiring-req-sec')) return;
      const deptScope = (CU?.role==='admin') ? null : CU?.department;
      const reqSkills = String(req.skills||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
      if (!reqSkills.length) return;
      const aspiringEmps=[];
      reqSkills.forEach(skill=>{
        _findAspiringForSkill(skill,deptScope).forEach(e=>{
          if(!aspiringEmps.find(x=>x.id===e.id)) aspiringEmps.push(e);
        });
      });
      if (!aspiringEmps.length) return;
      const sec=document.createElement('div');
      sec.className='aspiring-req-sec';
      sec.innerHTML=`
<div style="margin-top:14px;padding:12px 14px;border:1px dashed rgba(165,94,234,.35);
            border-radius:var(--r);background:rgba(165,94,234,.03)">
  <div style="font-weight:700;font-size:.84rem;color:var(--purple);margin-bottom:10px">
    📚 Interested to Learn (${aspiringEmps.length})
    <span style="font-weight:400;color:var(--text3);font-size:.76rem;margin-left:6px">
      — No current skill · training pipeline candidates only
    </span>
  </div>
  ${aspiringEmps.map((e,i)=>_buildAspiringCard(e,i)).join('')}
</div>`;
      panel.appendChild(sec);
    }, 900);
  };
}, 100);

// ═══════════════════════════════════════════════════════════════════════
// COLUMN SELECTOR FOR MAIN TABS (Employees / Allocations / Requirements)
//
// How it works:
//   - After import, a "⚙ Columns" button appears in each page header
//   - User picks which _extra_ columns from the imported data to show
//   - Selection saved to localStorage and persists across sessions
//   - The selected columns are appended as extra TH/TD in the tables
// ═══════════════════════════════════════════════════════════════════════

const COL_PREF_KEY = 'ra3_col_prefs'; // localStorage key

function _getColPrefs() {
  try { return JSON.parse(localStorage.getItem(COL_PREF_KEY)||'{}'); } catch { return {}; }
}
function _saveColPrefs(prefs) {
  localStorage.setItem(COL_PREF_KEY, JSON.stringify(prefs));
}

/** Get all unique _extra_* field names across all employees in current scope */
function _getExtraEmpCols() {
  const cols = new Set();
  DB.getEmployees(null).forEach(emp => {
    Object.keys(emp).forEach(k => { if(k.startsWith('_extra_')) cols.add(k); });
  });
  return [...cols].map(k => ({ key:k, label:k.replace('_extra_','') }));
}

/** Get all unique _extra_* field names across all allocations */
function _getExtraAllocCols() {
  const cols = new Set();
  DB.getAllocations(null).forEach(alloc => {
    Object.keys(alloc).forEach(k => { if(k.startsWith('_extra_')) cols.add(k); });
  });
  return [...cols].map(k => ({ key:k, label:k.replace('_extra_','') }));
}

/** Get all unique _extra_* field names across all requirements */
function _getExtraReqCols() {
  const cols = new Set();
  DB.getRequirements(null).forEach(req => {
    Object.keys(req).forEach(k => { if(k.startsWith('_extra_')) cols.add(k); });
  });
  return [...cols].map(k => ({ key:k, label:k.replace('_extra_','') }));
}

/** Show the column picker dialog for a given page */
function dlgColumnPicker(page) {
  if (page === 'requirements') {
    if (typeof dlgReqColumnPicker === 'function') {
      dlgReqColumnPicker();
      return;
    }
  }
  const prefs = _getColPrefs();
  const selected = new Set(prefs[page]||[]);

  if (page === 'requirements') {
    const reqCols = _getExtraReqCols();
    const empCols = _getExtraEmpCols();
    const allocCols = _getExtraAllocCols();

    if (!reqCols.length && !empCols.length && !allocCols.length) {
      toast('No extra columns found. Import data with additional columns first.', 'info');
      return;
    }

    openDlg(`
<div class="dlg-title">⚙ Choose Extra Columns — Requirements</div>
<div style="font-size:.82rem;color:var(--text2);margin-bottom:14px">
  Select which extra columns from your imported data you want to see in the
  <strong>Requirements</strong> tab. These are saved and persist across sessions.
</div>
<div style="max-height: 300px; overflow-y: auto; padding-right: 5px; text-align: left">
  ${reqCols.length ? `
    <div style="font-weight:700;font-size:.78rem;color:var(--purple);margin-bottom:6px;border-bottom:1px solid var(--border);padding-bottom:2px">📋 Requirement Columns (Requirement Cards)</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      ${reqCols.map(col=>`
        <button type="button"
          id="cp_${col.key.replace(/[^a-z0-9]/gi,'_')}"
          class="btn btn-sm ${selected.has(col.key)?'btn-teal':'btn-ghost'}"
          onclick="_toggleColPicker('${col.key.replace(/'/g,"\\'")}','requirements')"
          data-col="${col.key}">
          ${selected.has(col.key)?'☑':'☐'} ${col.label}
        </button>`
      ).join('')}
    </div>
  ` : ''}

  ${empCols.length ? `
    <div style="font-weight:700;font-size:.78rem;color:var(--teal);margin-bottom:6px;border-bottom:1px solid var(--border);padding-bottom:2px">👥 Employee Columns (Candidate Cards)</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      ${empCols.map(col=>`
        <button type="button"
          id="cp_${col.key.replace(/[^a-z0-9]/gi,'_')}"
          class="btn btn-sm ${selected.has(col.key)?'btn-teal':'btn-ghost'}"
          onclick="_toggleColPicker('${col.key.replace(/'/g,"\\'")}','requirements')"
          data-col="${col.key}">
          ${selected.has(col.key)?'☑':'☐'} ${col.label}
        </button>`
      ).join('')}
    </div>
  ` : ''}

  ${allocCols.length ? `
    <div style="font-weight:700;font-size:.78rem;color:var(--purple);margin-bottom:6px;border-bottom:1px solid var(--border);padding-bottom:2px">🎯 Allocation Columns (Candidate Cards)</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      ${allocCols.map(col=>`
        <button type="button"
          id="cp_${col.key.replace(/[^a-z0-9]/gi,'_')}"
          class="btn btn-sm ${selected.has(col.key)?'btn-teal':'btn-ghost'}"
          onclick="_toggleColPicker('${col.key.replace(/'/g,"\\'")}','requirements')"
          data-col="${col.key}">
          ${selected.has(col.key)?'☑':'☐'} ${col.label}
        </button>`
      ).join('')}
    </div>
  ` : ''}
</div>
<div style="display:flex;gap:9px;justify-content:space-between;align-items:center;margin-top:15px">
  <div style="display:flex;gap:7px">
    <button class="btn btn-xs btn-ghost" onclick="_selectAllCols('requirements')">Select All</button>
    <button class="btn btn-xs btn-ghost" onclick="_clearAllCols('requirements')">Clear All</button>
  </div>
  <div style="display:flex;gap:9px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="_applyColPrefs('requirements')">Apply →</button>
  </div>
</div>`);
    return;
  }

  // Original single-category picker for employees / allocations
  let cols = page === 'allocations' ? _getExtraAllocCols() : _getExtraEmpCols();

  if (!cols.length) {
    toast('No extra columns found. Import data with additional columns first.', 'info');
    return;
  }

  openDlg(`
<div class="dlg-title">⚙ Choose Extra Columns — ${page.charAt(0).toUpperCase()+page.slice(1)}</div>
<div style="font-size:.82rem;color:var(--text2);margin-bottom:14px">
  Select which extra columns from your imported data you want to see in the
  <strong>${page}</strong> table. These are saved and persist across sessions.
</div>
<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px" id="col-picker-grid">
  ${cols.map(col=>`
    <button type="button"
      id="cp_${col.key.replace(/[^a-z0-9]/gi,'_')}"
      class="btn btn-sm ${selected.has(col.key)?'btn-teal':'btn-ghost'}"
      onclick="_toggleColPicker('${col.key.replace(/'/g,"\\'")}','${page}')"
      data-col="${col.key}">
      ${selected.has(col.key)?'☑':'☐'} ${col.label}
    </button>`
  ).join('')}
</div>
<div style="display:flex;gap:9px;justify-content:space-between;align-items:center;margin-top:5px">
  <div style="display:flex;gap:7px">
    <button class="btn btn-xs btn-ghost" onclick="_selectAllCols('${page}')">Select All</button>
    <button class="btn btn-xs btn-ghost" onclick="_clearAllCols('${page}')">Clear All</button>
  </div>
  <div style="display:flex;gap:9px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="_applyColPrefs('${page}')">Apply →</button>
  </div>
</div>`);
}

function _toggleColPicker(colKey, page) {
  const prefs   = _getColPrefs();
  const selected = new Set(prefs[page]||[]);
  selected.has(colKey) ? selected.delete(colKey) : selected.add(colKey);
  prefs[page] = [...selected];
  _saveColPrefs(prefs);
  const btnId = 'cp_'+colKey.replace(/[^a-z0-9]/gi,'_');
  const btn   = document.getElementById(btnId);
  if (btn) {
    const label = colKey.replace('_extra_','');
    btn.className = `btn btn-sm ${selected.has(colKey)?'btn-teal':'btn-ghost'}`;
    btn.textContent = (selected.has(colKey)?'☑ ':'☐ ')+label;
  }
}

function _selectAllCols(page) {
  const prefs = _getColPrefs();
  let cols;
  if (page === 'requirements') {
    cols = [..._getExtraReqCols(), ..._getExtraEmpCols(), ..._getExtraAllocCols()];
  } else if (page === 'allocations') {
    cols = _getExtraAllocCols();
  } else {
    cols = _getExtraEmpCols();
  }
  prefs[page] = cols.map(c=>c.key);
  _saveColPrefs(prefs);
  cols.forEach(col=>{
    const btn=document.getElementById('cp_'+col.key.replace(/[^a-z0-9]/gi,'_'));
    if(btn){btn.className='btn btn-sm btn-teal';btn.textContent='☑ '+col.label;}
  });
}

function _clearAllCols(page) {
  const prefs=_getColPrefs(); prefs[page]=[];
  _saveColPrefs(prefs);
  let cols;
  if (page === 'requirements') {
    cols = [..._getExtraReqCols(), ..._getExtraEmpCols(), ..._getExtraAllocCols()];
  } else if (page === 'allocations') {
    cols = _getExtraAllocCols();
  } else {
    cols = _getExtraEmpCols();
  }
  cols.forEach(col=>{
    const btn=document.getElementById('cp_'+col.key.replace(/[^a-z0-9]/gi,'_'));
    if(btn){btn.className='btn btn-sm btn-ghost';btn.textContent='☐ '+col.label;}
  });
}

function _applyColPrefs(page) {
  closeDlg();
  // Re-render the current page to apply new columns
  if      (page==='employees')    renderEmps();
  else if (page==='allocations')  renderAllocs();
  else if (page==='requirements') renderReqs();
  const prefs=_getColPrefs();
  const count=(prefs[page]||[]).length;
  toast(`${count} extra column${count!==1?'s':''} added to ${page} table`, 'ok');
}

/** Inject ⚙ Columns button into page header — called from initEmps/initAllocs/initReqs */
function _injectColBtn(page) {
  let actions = document.querySelector('.page-hdr-actions');
  if (!actions) {
    const hdr = document.querySelector('.page-hdr');
    if (hdr) {
      actions = document.createElement('div');
      actions.className = 'page-hdr-actions';
      const buttons = Array.from(hdr.children).filter(el => el.tagName === 'BUTTON');
      buttons.forEach(btn => actions.appendChild(btn));
      hdr.appendChild(actions);
    }
  }
  if (!actions) return;
  if (document.getElementById(`col-btn-${page}`)) return;
  if (page === 'requirements' && (actions.querySelector('[onclick*="dlgReqColumnPicker"]') || Array.from(actions.querySelectorAll('button')).some(b => b.textContent.includes('Columns')))) {
    return;
  }
  const btn = document.createElement('button');
  btn.id = `col-btn-${page}`;
  btn.className = 'btn btn-ghost btn-sm';
  btn.textContent = '⚙ Columns';
  btn.title = 'Choose extra columns to display';
  btn.onclick = () => {
    if (page === 'requirements') {
      if (typeof dlgReqColumnPicker === 'function') {
        dlgReqColumnPicker();
      } else {
        dlgColumnPicker(page);
      }
    } else {
      dlgColumnPicker(page);
    }
  };
  actions.insertBefore(btn, actions.firstChild);
}

/** Get extra column TH cells for table header */
function _extraColHeaders(page) {
  const prefs=_getColPrefs();
  return (prefs[page]||[]).map(k=>
    `<th style="white-space:nowrap;color:var(--purple)">${k.replace('_extra_','')}</th>`
  ).join('');
}

/** Get extra column TD cells for a record */
function _extraColCells(record, page) {
  const prefs=_getColPrefs();
  return (prefs[page]||[]).map(k=>{
    const v=record[k]||'—';
    return `<td style="font-size:.78rem;color:var(--text2);max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${v}">${v}</td>`;
  }).join('');
}

// ── Patch initEmps to inject Columns button ──
const _origInitEmps = initEmps;
window.initEmps = function(dept) {
  _origInitEmps(dept);
  _injectColBtn('employees');
};

// ── Patch initAllocs to inject Columns button ──────────────────────────
const _origInitAllocs = initAllocs;
window.initAllocs = function(dept) {
  _origInitAllocs(dept);
  _injectColBtn('allocations');
  if(typeof _injectAllocNotifTab==='function') _injectAllocNotifTab();
};

// ── Patch initReqs to inject Columns button ──────────────────────────
const _origInitReqs = initReqs;
window.initReqs = function() {
  _origInitReqs();
  _injectColBtn('requirements');
};

// ── Patch renderEmps to dynamically append selected extra column headers & cells ──
const _origRenderEmps = renderEmps;
window.renderEmps = function() {
  _origRenderEmps();
  
  const tbody = document.getElementById('emp-tbody');
  if (!tbody) return;

  // Always clean up existing custom headers first
  const thead = tbody.closest('table')?.querySelector('thead tr');
  if (thead) {
    thead.querySelectorAll('.extra-col-th').forEach(el => el.remove());
  }

  const prefs = _getColPrefs();
  const cols = prefs['employees'] || [];
  if (!cols.length) return;

  // Render cells
  tbody.querySelectorAll('tr').forEach(row => {
    if (row.querySelector('.extra-emp-td')) return;
    const lastTd = row.lastElementChild;
    if (!lastTd) return;
    const nameDiv = row.cells[0]?.querySelector('div');
    const empName = nameDiv ? nameDiv.textContent.trim() : '';
    const emp = empName ? DB.getEmployees().find(e => e.name === empName) : null;
    if (!emp) return;
    
    const extraHtml = cols.map(k => {
      const v = emp[k] || '—';
      return `<td class="extra-emp-td" style="font-size:.78rem;color:var(--text2);max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${v}">${v}</td>`;
    }).join('');
    lastTd.insertAdjacentHTML('beforebegin', extraHtml);
  });

  // Render headers
  if (thead) {
    cols.forEach(k => {
      const th = document.createElement('th');
      th.className = 'extra-col-th';
      th.style.cssText = 'white-space:nowrap;color:var(--purple);font-size:.63rem';
      th.textContent = k.replace('_extra_','');
      thead.lastElementChild.insertAdjacentElement('beforebegin', th);
    });
  }
};

// ── Patch renderAllocs to dynamically append selected extra column headers & cells ──
const _origRenderAllocs = renderAllocs;
window.renderAllocs = function() {
  _origRenderAllocs();
  
  const tbody = document.getElementById('al-tbody');
  if (!tbody) return;

  // Always clean up existing custom headers first
  const thead = tbody.closest('table')?.querySelector('thead tr');
  if (thead) {
    thead.querySelectorAll('.extra-col-th-a').forEach(el => el.remove());
  }

  const prefs = _getColPrefs();
  const cols = prefs['allocations'] || [];
  if (!cols.length) return;

  // Render cells
  tbody.querySelectorAll('tr').forEach(row => {
    if (row.querySelector('.extra-alloc-td')) return;
    const lastTd = row.lastElementChild;
    if (!lastTd) return;
    const editBtn = row.querySelector("button[onclick^='dlgEditAlloc']");
    const allocId = editBtn ? editBtn.getAttribute('onclick').match(/'([^']+)'/)?.[1] : null;
    const alloc = allocId ? DB.getAllocations().find(al => al.id === allocId) : null;
    if (!alloc) return;

    const extraHtml = cols.map(k => {
      const v = alloc[k] || '—';
      return `<td class="extra-alloc-td" style="font-size:.78rem;color:var(--text2);max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${v}">${v}</td>`;
    }).join('');
    lastTd.insertAdjacentHTML('beforebegin', extraHtml);
  });

  // Render headers
  if (thead) {
    cols.forEach(k => {
      const th = document.createElement('th');
      th.className = 'extra-col-th-a';
      th.style.cssText = 'white-space:nowrap;color:var(--purple);font-size:.63rem';
      th.textContent = k.replace('_extra_','');
      thead.lastElementChild.insertAdjacentElement('beforebegin', th);
    });
  }
};

// ── Overwrite _buildCandidateExtraFields with ultra-robust case-insensitive and fallback-aware lookup ──
window._buildCandidateExtraFields = function(emp) {
  if (!emp) return '';
  const prefs = (typeof _getReqColPrefs === 'function')
    ? _getReqColPrefs()
    : (function() {
        try { return JSON.parse(localStorage.getItem('ra3_req_col_prefs') || '{}'); }
        catch { return {}; }
      })();
  const empCols    = prefs.empCols   || [];
  const allocCols  = prefs.allocCols || [];
  if (!empCols.length && !allocCols.length) return '';

  const chips = [];
  const seenChips = new Set();

  const clean = s => String(s || '').toLowerCase().replace('_extra_', '').replace(/[^a-z0-9]/g, '');
  
  function getVal(obj, key) {
    if (!obj || !key) return undefined;
    if (obj[key] !== undefined) return obj[key];
    const normKey = clean(key);
    for (const [k, v] of Object.entries(obj)) {
      if (clean(k) === normKey) return v;
    }
    return undefined;
  }

  function localHesc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  const empAllocs = (typeof DB !== 'undefined' && typeof DB.empAllocs === 'function') ? DB.empAllocs(emp.id) : [];

  function addChip(label, val, sourceIcon, textColor, bgColor, borderColor, titlePrefix) {
    if (val === undefined || val === null) return;
    const sVal = String(val).trim();
    if (sVal === '' || sVal === '—' || sVal === '\u2014' || sVal.toLowerCase() === 'n/a') return;
    
    const chipKey = clean(label) + '::' + clean(sVal);
    if (seenChips.has(chipKey)) return;
    seenChips.add(chipKey);

    chips.push(`<span class="chip" style="font-size:.68rem;background:${bgColor};
                 color:${textColor};border:1px solid ${borderColor};display:inline-flex;align-items:center;gap:3px"
                 title="${titlePrefix}: ${localHesc(label)}">
      ${sourceIcon} ${localHesc(label)}: ${localHesc(sVal)}
    </span>`);
  }

  // Process checked employee columns
  empCols.forEach(k => {
    const label = k.replace('_extra_', '');
    let v = getVal(emp, k);
    if (v !== undefined) {
      addChip(label, v, '👥', 'var(--teal)', 'rgba(0,200,180,.08)', 'rgba(0,200,180,.2)', 'Employee');
    }
    empAllocs.forEach(al => {
      let av = getVal(al, k);
      if (av !== undefined) {
        addChip(label, av, '🎯', 'var(--amber2)', 'rgba(240,165,0,.08)', 'rgba(240,165,0,.2)', `Allocation (${al.projectName || '?'})`);
      }
    });
  });

  // Process checked allocation columns
  allocCols.forEach(k => {
    const label = k.replace('_extra_', '');
    empAllocs.forEach(al => {
      let av = getVal(al, k);
      if (av !== undefined) {
        addChip(label, av, '🎯', 'var(--amber2)', 'rgba(240,165,0,.08)', 'rgba(240,165,0,.2)', `Allocation (${al.projectName || '?'})`);
      }
    });
    let v = getVal(emp, k);
    if (v !== undefined) {
      addChip(label, v, '👥', 'var(--teal)', 'rgba(0,200,180,.08)', 'rgba(0,200,180,.2)', 'Employee');
    }
  });

  if (!chips.length) return '';
  return `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;
                      padding-top:4px;border-top:1px dashed var(--border)">
    ${chips.join('')}
  </div>`;
};
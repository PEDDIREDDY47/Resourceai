'use strict';
// ═══════════════════════════════════════════════════════════════════════
// NOTIFICATIONS.JS — Allocation Expiry Notification Engine
//
// Features:
//   • Scans ALL allocations on login and every 6 hours automatically
//   • Groups by urgency: Critical (≤7d), Warning (≤14d), Notice (≤30d)
//   • Notification bell in topbar with live unread count badge
//   • Each alert has Extend, Edit, Remove action buttons inline
//   • Persists dismissed/snoozed state so it does not spam on refresh
//   • Admin sees all departments; users see their dept only
//   • Also adds "Notifications" tab to the Allocations page
// ═══════════════════════════════════════════════════════════════════════

// ── Persistence keys ─────────────────────────────────────────────────
const NOTIF_KEY   = 'ra3_notif_dismissed';   // set of allocId|date strings
const SNOOZE_KEY  = 'ra3_notif_snoozed';     // allocId → snooze-until timestamp

function _getDismissed() {
  try { return new Set(JSON.parse(localStorage.getItem(NOTIF_KEY) || '[]')); } catch { return new Set(); }
}
function _saveDismissed(set) {
  localStorage.setItem(NOTIF_KEY, JSON.stringify([...set]));
}
function _getSnoozed() {
  try { return JSON.parse(localStorage.getItem(SNOOZE_KEY) || '{}'); } catch { return {}; }
}
function _saveSnoozed(obj) {
  localStorage.setItem(SNOOZE_KEY, JSON.stringify(obj));
}

// ── Core scanner ─────────────────────────────────────────────────────
function _scanExpiringAllocations() {
  const now        = new Date();
  const dismissed  = _getDismissed();
  const snoozed    = _getSnoozed();
  const deptScope  = (typeof CU !== 'undefined' && CU?.role !== 'admin') ? CU?.department : null;
  const allocs     = DB.getAllocations(deptScope);

  const results = { critical: [], warning: [], notice: [] };

  allocs.forEach(a => {
    if (!a.endDate) return;
    const end      = new Date(a.endDate);
    const daysLeft = Math.ceil((end - now) / (1000 * 60 * 60 * 24));

    // Only surface allocations ending within 30 days, not already past
    if (daysLeft > 30 || daysLeft < 0) return;

    const key = `${a.id}|${a.endDate}`;

    // Skip if permanently dismissed
    if (dismissed.has(key)) return;

    // Skip if snoozed and snooze hasn't expired
    if (snoozed[a.id] && Date.now() < snoozed[a.id]) return;

    const emp   = DB.getEmployees().find(e => e.id === a.employeeId) || {};
    const entry = { ...a, _emp: emp, _daysLeft: daysLeft, _key: key };

    if      (daysLeft <= 7)  results.critical.push(entry);
    else if (daysLeft <= 14) results.warning.push(entry);
    else                     results.notice.push(entry);
  });

  // Sort each group: soonest first
  const sortFn = (a, b) => a._daysLeft - b._daysLeft;
  results.critical.sort(sortFn);
  results.warning.sort(sortFn);
  results.notice.sort(sortFn);

  return results;
}

// ── Inject bell into topbar ───────────────────────────────────────────
function _injectNotifBell() {
  if (document.getElementById('notif-bell')) return; // already injected

  const tbRight = document.querySelector('.tb-right');
  if (!tbRight) return;

  const bell = document.createElement('div');
  bell.id    = 'notif-bell';
  bell.style.cssText = 'position:relative;cursor:pointer;';
  bell.innerHTML = `
    <button id="notif-btn" style="
      background:var(--surface);border:1px solid var(--border);
      border-radius:50%;width:36px;height:36px;display:flex;align-items:center;
      justify-content:center;font-size:1rem;cursor:pointer;transition:var(--t);
      color:var(--text2);" title="Allocation Expiry Alerts"
      onclick="toggleNotifPanel()">🔔</button>
    <span id="notif-badge" style="
      display:none;position:absolute;top:-4px;right:-4px;
      background:var(--red);color:#fff;font-size:.6rem;font-weight:900;
      padding:1px 5px;border-radius:100px;min-width:16px;text-align:center;
      pointer-events:none;"></span>
    <div id="notif-panel" style="
      display:none;position:absolute;top:calc(100% + 10px);right:0;
      width:420px;max-height:70vh;overflow-y:auto;
      background:var(--bg2);border:1px solid var(--border2);
      border-radius:var(--r-lg);box-shadow:var(--shadow);z-index:9999;"></div>`;

  // Insert before user-menu
  const userMenu = tbRight.querySelector('.user-menu');
  tbRight.insertBefore(bell, userMenu);

  // Close panel when clicking outside
  document.addEventListener('click', e => {
    if (!e.target.closest('#notif-bell')) {
      document.getElementById('notif-panel')?.style &&
        (document.getElementById('notif-panel').style.display = 'none');
    }
  });
}

// ── Update badge count ────────────────────────────────────────────────
function _updateNotifBadge() {
  const badge = document.getElementById('notif-badge');
  if (!badge) return;
  const scan  = _scanExpiringAllocations();
  const total = scan.critical.length + scan.warning.length + scan.notice.length;
  if (total > 0) {
    badge.textContent = total > 99 ? '99+' : total;
    badge.style.display = 'block';
    // Make bell pulse if critical
    const btn = document.getElementById('notif-btn');
    if (btn) {
      btn.style.borderColor = scan.critical.length ? 'var(--red)' : scan.warning.length ? 'var(--amber)' : 'var(--border)';
      btn.style.color       = scan.critical.length ? 'var(--red)' : scan.warning.length ? 'var(--amber)' : 'var(--text2)';
    }
  } else {
    badge.style.display = 'none';
    const btn = document.getElementById('notif-btn');
    if (btn) { btn.style.borderColor = 'var(--border)'; btn.style.color = 'var(--text2)'; }
  }
  return total;
}

// ── Toggle panel ─────────────────────────────────────────────────────
function toggleNotifPanel() {
  const panel = document.getElementById('notif-panel');
  if (!panel) return;
  const isOpen = panel.style.display === 'block';
  panel.style.display = isOpen ? 'none' : 'block';
  if (!isOpen) _renderNotifPanel();
}

// ── Render panel contents ─────────────────────────────────────────────
function _renderNotifPanel() {
  const panel = document.getElementById('notif-panel');
  if (!panel) return;

  const scan = _scanExpiringAllocations();
  const total = scan.critical.length + scan.warning.length + scan.notice.length;

  if (total === 0) {
    panel.innerHTML = `
      <div style="padding:28px;text-align:center">
        <div style="font-size:2rem;margin-bottom:8px">✅</div>
        <div style="font-weight:700;margin-bottom:4px">All Clear</div>
        <div style="font-size:.8rem;color:var(--text3)">No allocations ending in the next 30 days.</div>
      </div>`;
    return;
  }

  const buildGroup = (items, label, color, icon) => {
    if (!items.length) return '';
    return `
      <div style="padding:10px 14px 4px;font-size:.68rem;font-weight:800;
                  letter-spacing:.08em;text-transform:uppercase;color:${color}">
        ${icon} ${label} (${items.length})
      </div>
      ${items.map(a => _buildNotifCard(a, color)).join('')}`;
  };

  panel.innerHTML = `
    <div style="padding:14px 16px 10px;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-weight:800;font-size:.92rem">Allocation Expiry Alerts</div>
        <div style="font-size:.74rem;color:var(--text3)">${total} allocation${total!==1?'s':''} ending soon</div>
      </div>
      <button class="btn btn-xs btn-ghost" onclick="dismissAllNotifs()">Dismiss All</button>
    </div>

    ${buildGroup(scan.critical, 'Critical — ≤7 Days', 'var(--red)',    '🔴')}
    ${buildGroup(scan.warning,  'Warning — ≤14 Days', 'var(--amber2)', '🟡')}
    ${buildGroup(scan.notice,   'Notice — ≤30 Days',  'var(--cyan)',   '📅')}

    <div style="padding:10px 14px;border-top:1px solid var(--border);
                font-size:.72rem;color:var(--text3);text-align:center">
      Auto-refreshes every 6 hours · <a onclick="navigateTo('allocations')" 
        style="color:var(--teal);cursor:pointer">View all allocations →</a>
    </div>`;
}

// ── Single notification card ──────────────────────────────────────────
function _buildNotifCard(a, accentColor) {
  const emp      = a._emp || {};
  const empB     = BAND.normalize(emp.designation || emp.band || '');
  const daysLeft = a._daysLeft;
  const urgency  = daysLeft <= 7
    ? `<span style="color:var(--red);font-weight:800">${daysLeft}d left</span>`
    : daysLeft <= 14
    ? `<span style="color:var(--amber2);font-weight:700">${daysLeft}d left</span>`
    : `<span style="color:var(--cyan)">${daysLeft}d left</span>`;

  return `
<div style="
  padding:12px 16px;border-bottom:1px solid var(--border);
  border-left:3px solid ${accentColor};margin-left:2px;
  transition:background .15s" 
  onmouseenter="this.style.background='var(--surface)'"
  onmouseleave="this.style.background='transparent'">

  <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
    <div style="flex:1;min-width:0">
      <!-- Employee + project -->
      <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:3px">
        <span style="font-weight:700;font-size:.85rem">${emp.name || '?'}</span>
        ${empB ? BAND.renderBand(empB) : ''}
        <span class="badge b-blue" style="font-size:.62rem">${emp.department || '—'}</span>
      </div>
      <div style="font-size:.78rem;color:var(--text2);margin-bottom:5px">
        📁 ${a.projectName} &nbsp;·&nbsp; ${a.percentage}% allocation
      </div>
      <div style="font-size:.74rem;color:var(--text3)">
        📅 ${a.startDate || '—'} → <strong style="color:var(--text)">${a.endDate}</strong>
        &nbsp;·&nbsp; ${urgency}
      </div>
    </div>
    <!-- Dismiss X -->
    <button onclick="dismissNotif('${a._key}')"
      style="background:none;border:none;color:var(--text3);cursor:pointer;
             font-size:.9rem;padding:2px;line-height:1;flex-shrink:0"
      title="Dismiss">✕</button>
  </div>

  <!-- Action buttons -->
  <div style="display:flex;gap:6px;margin-top:9px;flex-wrap:wrap">
    <button class="btn btn-teal btn-xs"
      onclick="notifExtend('${a.id}');toggleNotifPanel();">
      📅 Extend
    </button>
    <button class="btn btn-outline btn-xs"
      onclick="notifEdit('${a.id}');toggleNotifPanel();">
      ✏️ Edit
    </button>
    <button class="btn btn-ghost btn-xs"
      onclick="snoozeNotif('${a.id}')">
      💤 Snooze 3d
    </button>
    <button class="btn btn-red btn-xs"
      onclick="notifRemove('${a.id}');toggleNotifPanel();">
      🗑 Remove
    </button>
  </div>
</div>`;
}

// ── Actions called from notification cards ────────────────────────────

/** Open the Edit Allocation dialog pre-filled */
function notifEdit(allocId) {
  closeDlg();
  navigateTo('allocations');
  // Small delay so the allocations page DOM is ready
  setTimeout(() => dlgEditAlloc(allocId), 200);
}

/** Open a quick "Extend end date" dialog */
function notifExtend(allocId) {
  const a   = DB.getAllocations().find(x => x.id === allocId);
  if (!a) return toast('Allocation not found', 'err');
  const emp = DB.getEmployees().find(e => e.id === a.employeeId) || {};

  openDlg(`
<div class="dlg-title">Extend Allocation</div>
<div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--bg3);
            border-radius:var(--r-sm);margin-bottom:16px">
  <div class="avatar" style="width:38px;height:38px;font-size:.85rem">
    ${(emp.name||'?').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}
  </div>
  <div>
    <div style="font-weight:700">${emp.name || '?'} ${BAND.renderBand(BAND.normalize(emp.designation||''))}</div>
    <div style="font-size:.78rem;color:var(--text2)">📁 ${a.projectName} · ${a.percentage}% allocation</div>
    <div style="font-size:.74rem;color:var(--text3)">Current end: <strong style="color:var(--amber2)">${a.endDate || '—'}</strong></div>
  </div>
</div>

<div class="form-group">
  <label class="form-label">New End Date *</label>
  <input id="ext-date" type="date" class="form-input"
    min="${a.endDate || ''}"
    value="${a.endDate ? _addDays(a.endDate, 90) : ''}"/>
  <div style="display:flex;gap:7px;margin-top:8px;flex-wrap:wrap">
    <button class="btn btn-xs btn-ghost" onclick="document.getElementById('ext-date').value='${_addDays(a.endDate||new Date().toISOString().slice(0,10), 30)}'">+30 days</button>
    <button class="btn btn-xs btn-ghost" onclick="document.getElementById('ext-date').value='${_addDays(a.endDate||new Date().toISOString().slice(0,10), 60)}'">+60 days</button>
    <button class="btn btn-xs btn-ghost" onclick="document.getElementById('ext-date').value='${_addDays(a.endDate||new Date().toISOString().slice(0,10), 90)}'">+90 days</button>
    <button class="btn btn-xs btn-ghost" onclick="document.getElementById('ext-date').value='${_addDays(a.endDate||new Date().toISOString().slice(0,10), 180)}'">+6 months</button>
  </div>
</div>

<div class="form-group">
  <label class="form-label">Update Allocation % (optional, current: ${a.percentage}%)</label>
  <input id="ext-pct" type="number" class="form-input"
    value="${a.percentage}" min="1" max="100" placeholder="${a.percentage}"/>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal" onclick="saveNotifExtend('${allocId}')">Extend Allocation</button>
</div>`);
}

function saveNotifExtend(allocId) {
  const newDate = document.getElementById('ext-date')?.value;
  const newPct  = parseFloat(document.getElementById('ext-pct')?.value || '0');
  if (!newDate) return toast('Select a new end date', 'err');
  if (newPct <= 0 || newPct > 100) return toast('Allocation must be 1–100%', 'err');

  DB.updateAllocation(allocId, { endDate: newDate, percentage: newPct });

  // Clear any snooze/dismiss for this alloc since it's been handled
  const snoozed = _getSnoozed(); delete snoozed[allocId]; _saveSnoozed(snoozed);

  closeDlg();
  _updateNotifBadge();
  toast('Allocation extended ✓', 'ok');
  Notify.send(CU.email, '[ResourceAI] Allocation Extended',
    `Allocation for ${DB.getEmployees().find(e=>e.id===DB.getAllocations().find(a=>a.id===allocId)?.employeeId)?.name||'?'} on ${DB.getAllocations().find(a=>a.id===allocId)?.projectName} extended to ${newDate}.`);
}

function notifRemove(allocId) {
  const a   = DB.getAllocations().find(x => x.id === allocId);
  const emp = DB.getEmployees().find(e => e.id === a?.employeeId);
  if (!confirm(`Remove allocation: ${emp?.name} → ${a?.projectName}?`)) return;
  DB.removeAllocation(allocId);
  dismissNotif(`${allocId}|${a?.endDate}`);
  _updateNotifBadge();
  toast('Allocation removed', 'info');
}

function dismissNotif(key) {
  const d = _getDismissed();
  d.add(key);
  _saveDismissed(d);
  _renderNotifPanel();
  _updateNotifBadge();
}

function dismissAllNotifs() {
  const scan = _scanExpiringAllocations();
  const d    = _getDismissed();
  [...scan.critical, ...scan.warning, ...scan.notice].forEach(a => d.add(a._key));
  _saveDismissed(d);
  _renderNotifPanel();
  _updateNotifBadge();
  toast('All notifications dismissed', 'info');
}

function snoozeNotif(allocId) {
  const snoozed = _getSnoozed();
  snoozed[allocId] = Date.now() + 3 * 24 * 60 * 60 * 1000; // 3 days
  _saveSnoozed(snoozed);
  _renderNotifPanel();
  _updateNotifBadge();
  toast('Snoozed for 3 days 💤', 'info');
}

// ── Date helper ───────────────────────────────────────────────────────
function _addDays(dateStr, days) {
  try {
    const d = new Date(dateStr);
    d.setDate(d.getDate() + days);
    return d.toISOString().slice(0, 10);
  } catch { return ''; }
}

// ── Auto-refresh every 6 hours ────────────────────────────────────────
let _notifInterval = null;
function startNotifPolling() {
  _updateNotifBadge();
  if (_notifInterval) clearInterval(_notifInterval);
  _notifInterval = setInterval(() => {
    _updateNotifBadge();
    // Toast for new criticals that appeared since last check
    const scan = _scanExpiringAllocations();
    if (scan.critical.length > 0) {
      toast(`⚠️ ${scan.critical.length} allocation${scan.critical.length>1?'s':''} ending within 7 days!`, 'warn', 6000);
    }
  }, 6 * 60 * 60 * 1000);
}

// ── Public init — called from launchApp() patch below ────────────────
function initNotifications() {
  _injectNotifBell();
  startNotifPolling();

  // Also show an immediate toast summary on login
  setTimeout(() => {
    const scan  = _scanExpiringAllocations();
    const crit  = scan.critical.length;
    const warn  = scan.warning.length;
    if (crit > 0) toast(`🔴 ${crit} allocation${crit>1?'s':''} ending in ≤7 days — check 🔔`, 'warn', 7000);
    else if (warn > 0) toast(`🟡 ${warn} allocation${warn>1?'s':''} ending in ≤14 days`, 'info', 5000);
  }, 1500);
}

// Patches moved to patches.js to avoid hoisting conflicts

function _injectAllocNotifTab() {
  const hdr = document.querySelector('#page-body .page-hdr-actions');
  if (!hdr || document.getElementById('alloc-notif-tab-btn')) return;

  const scan  = _scanExpiringAllocations();
  const total = scan.critical.length + scan.warning.length + scan.notice.length;

  const btn = document.createElement('button');
  btn.id        = 'alloc-notif-tab-btn';
  btn.className = `btn btn-sm ${total > 0 ? 'btn-amber' : 'btn-ghost'}`;
  btn.innerHTML = `🔔 Expiring${total > 0 ? ` (${total})` : ''}`;
  btn.onclick   = showAllocNotifSection;

  hdr.insertBefore(btn, hdr.firstChild);
}

function showAllocNotifSection() {
  const existing = document.getElementById('alloc-notif-section');
  if (existing) { existing.remove(); return; }

  const scan  = _scanExpiringAllocations();
  const total = scan.critical.length + scan.warning.length + scan.notice.length;

  const section = document.createElement('div');
  section.id    = 'alloc-notif-section';
  section.style.marginBottom = '18px';

  if (total === 0) {
    section.innerHTML = `<div class="alert a-ok">✅ No allocations ending in the next 30 days.</div>`;
  } else {
    const buildRows = (items, label, badgeCls, icon) => {
      if (!items.length) return '';
      return `
        <div class="avail-tier ${badgeCls}" style="margin-top:12px">
          ${icon} ${label} — ${items.length} allocation${items.length>1?'s':''}
        </div>
        <div class="tbl-wrap">
          <table>
            <thead>
              <tr>
                <th>Employee</th><th>Band</th><th>Project</th>
                <th>Allocation</th><th>End Date</th><th>Days Left</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${items.map(a => {
                const emp  = a._emp || {};
                const empB = BAND.normalize(emp.designation || emp.band || '');
                const urgCls = a._daysLeft <= 7 ? 'b-red' : a._daysLeft <= 14 ? 'b-amber' : 'b-cyan';
                return `<tr>
                  <td><strong>${emp.name || '?'}</strong></td>
                  <td>${empB ? BAND.renderBand(empB) : '—'}</td>
                  <td>${a.projectName}</td>
                  <td>${progBar(a.percentage)}</td>
                  <td style="font-family:var(--mono);font-size:.82rem">${a.endDate}</td>
                  <td><span class="badge ${urgCls}">${a._daysLeft}d</span></td>
                  <td>
                    <div style="display:flex;gap:4px;flex-wrap:wrap">
                      <button class="btn btn-xs btn-teal"    onclick="notifExtend('${a.id}')">📅 Extend</button>
                      <button class="btn btn-xs btn-outline" onclick="dlgEditAlloc('${a.id}')">✏️ Edit</button>
                      <button class="btn btn-xs btn-ghost"   onclick="snoozeNotif('${a.id}');showAllocNotifSection();showAllocNotifSection()">💤 Snooze</button>
                      <button class="btn btn-xs btn-red"     onclick="notifRemove('${a.id}');showAllocNotifSection();showAllocNotifSection()">🗑 Remove</button>
                    </div>
                  </td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>`;
    };

    section.innerHTML = `
      <div class="card">
        <div class="card-hdr">
          <span class="card-title">🔔 Expiring Allocations — Next 30 Days</span>
          <button class="btn btn-xs btn-ghost" onclick="dismissAllNotifs();document.getElementById('alloc-notif-section')?.remove()">Dismiss All</button>
        </div>
        ${buildRows(scan.critical, 'Critical ≤7 Days',  'at-none',     '🔴')}
        ${buildRows(scan.warning,  'Warning ≤14 Days',  'at-partial',  '🟡')}
        ${buildRows(scan.notice,   'Notice ≤30 Days',   'at-ending',   '📅')}
      </div>`;
  }

  // Insert before the first card on the allocations page
  const body = document.getElementById('page-body');
  const firstCard = body?.querySelector('.card');
  if (firstCard) body.insertBefore(section, firstCard);
  else body?.appendChild(section);
}

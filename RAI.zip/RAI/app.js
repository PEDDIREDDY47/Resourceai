// 'use strict';
// // ═══════════════════════════════════════════════════════
// // APP.JS — Interactive view routing & event aggregators
// // Depends on: security.js, database.js, colmapper.js,
// //             excel.js, ai.js (BAND + AI), config.js
// // ═══════════════════════════════════════════════════════

// let CU = null; // Current logged-in user

// // ── Page switcher ─────────────────────────────────────
// function showPage(id){
//   document.querySelectorAll('.page').forEach(p=>{p.classList.remove('active');p.style.display='';});
//   const el = document.getElementById(id); if(!el) return;
//   el.classList.add('active');
//   if(id==='pg-app') el.style.display='flex';
//   if(id==='pg-register'){
//     const sel = document.getElementById('r-dept');
//     sel.innerHTML = '<option value="">Select...</option>';
//     DB.getDepts().forEach(d => sel.innerHTML += `<option>${d}</option>`);
//   }
//   updateLandingMetrics();
// }

// // ════════════════════════════════════════════════════════
// // AUTH LOGIC
// // ════════════════════════════════════════════════════════
// let _loginAttempts=0, _lockUntil=0;

// function doLogin(){
//   if(Date.now()<_lockUntil) return showAlert('login-alert',`Too many attempts. Try again in ${Math.ceil((_lockUntil-Date.now())/60000)} min.`,'warn');
//   const email = document.getElementById('l-email').value.trim();
//   const pass  = document.getElementById('l-pass').value;
//   if(!email||!pass) return showAlert('login-alert','Please enter email and password.');
//   const user = DB.getByEmail(email);
//   if(!user||!SEC.verify(pass, user.passHash||user.password||'')){
//     _loginAttempts++;
//     if(_loginAttempts>=5){_lockUntil=Date.now()+5*60*1000;_loginAttempts=0;}
//     return showAlert('login-alert','Incorrect email or password.');
//   }
//   if(!user.approved) return showAlert('login-alert','Account pending admin approval. Check your email.','warn');
//   _loginAttempts=0; CU=user; DB.setSession(user);
//   showPage('pg-app'); launchApp();
//   toast(`Welcome back, ${user.name.split(' ')[0]}! 👋`,'ok');
// }

// function doRegister(){
//   const name  = document.getElementById('r-name').value.trim();
//   const email = document.getElementById('r-email').value.trim();
//   const dept  = document.getElementById('r-dept').value;
//   const pass  = document.getElementById('r-pass').value;
//   const pass2 = document.getElementById('r-pass2').value;
//   if(!name||!email||!dept||!pass) return showAlert('reg-alert','Fill all required fields.');
//   if(!/\S+@\S+\.\S+/.test(email)) return showAlert('reg-alert','Enter a valid email.');
//   if(pass.length<8) return showAlert('reg-alert','Password min 8 characters.');
//   if(pass!==pass2) return showAlert('reg-alert','Passwords do not match.');
//   if(DB.getByEmail(email)) return showAlert('reg-alert','Account already exists with that email.');
//   const reg = DB.addPending({name,email,passHash:SEC.hash(pass),role:'user',department:dept,reason:document.getElementById('r-reason').value.trim()});
//   Notify.onRegister(reg);
//   showAlert('reg-alert','Request submitted! You will be emailed once approved.','ok');
// }

// function doLogout(){CU=null;DB.clearSession();showPage('pg-landing');toast('Signed out.','info');}

// function sendRecovery(){
//   const email = document.getElementById('f-email').value.trim();
//   if(!email) return showAlert('forgot-alert','Enter your email.');
//   const user = DB.getByEmail(email);
//   if(!user) return showAlert('forgot-alert','No account found with that email.');
//   const token = SEC.genToken(); DB.setToken(email,token); Notify.onRecovery(email,token);
//   showAlert('forgot-alert',`Recovery code sent! Check admin Email Log for: ${email}`,'ok');
//   setTimeout(()=>{document.getElementById('forgot-step1').style.display='none';document.getElementById('forgot-step2').style.display='block';},1500);
// }

// function doResetPass(){
//   const email = document.getElementById('f-email').value.trim();
//   const token = document.getElementById('f-token').value.trim();
//   const np    = document.getElementById('f-newpass').value;
//   const np2   = document.getElementById('f-newpass2').value;
//   if(!token||!np) return showAlert('forgot-alert','Enter code and new password.');
//   if(np!==np2) return showAlert('forgot-alert','Passwords do not match.');
//   if(np.length<8) return showAlert('forgot-alert','Password min 8 characters.');
//   if(!DB.verifyToken(email,token)) return showAlert('forgot-alert','Invalid or expired code.');
//   const user = DB.getByEmail(email); if(!user) return showAlert('forgot-alert','User not found.');
//   DB.updateUser(user.id,{passHash:SEC.hash(np)}); DB.clearToken(email);
//   showAlert('forgot-alert','Password reset! You can now sign in.','ok');
//   setTimeout(()=>showPage('pg-login'),2000);
// }

// // ════════════════════════════════════════════════════════
// // APP LAUNCH & NAVIGATION
// // ════════════════════════════════════════════════════════
// function launchApp(){
//   const ini = CU.name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);
//   document.getElementById('tb-avatar').textContent = ini;
//   document.getElementById('sb-avatar').textContent = ini;
//   document.getElementById('tb-uname').textContent  = CU.name.split(' ')[0];
//   document.getElementById('sb-uname').textContent  = CU.name;
//   document.getElementById('sb-udept').textContent  = CU.role==='admin'?'⚡ Admin':CU.department;
//   document.getElementById('tb-dept').textContent   = CU.role==='admin'?'⚡ Administrator':`🏢 ${CU.department}`;
//   document.getElementById('footer-info').textContent = `${CU.name} · ${CU.department} · ${CU.role}`;
//   buildSidebar();
//   navigateTo('dashboard');
//   // Notifications: inject bell after sidebar is built
//   if(typeof initNotifications === 'function') initNotifications();
//   // Password: force change if using default
//   if(typeof _needsForcedChange === 'function' && _needsForcedChange(CU)){
//     setTimeout(()=>{ if(typeof dlgForceChangePassword==='function') dlgForceChangePassword(); }, 900);
//   }
// }

// const NAV_ADMIN = [
//   {id:'dashboard', icon:'📊', label:'Dashboard',    sec:'Main'},
//   {id:'employees', icon:'👥', label:'Employees',    sec:'Main'},
//   {id:'allocations',icon:'🎯',label:'Allocations',  sec:'Main'},
//   {id:'requirements',icon:'📋',label:'Requirements',sec:'Main'},
//   {id:'workforce', icon:'🧠', label:'Workforce AI', sec:'Intelligence'},
//   {id:'reports',   icon:'📈', label:'Reports',      sec:'Analytics'},
//   {id:'upload',    icon:'📂', label:'Data Import',  sec:'Data'},
//   {id:'admin',     icon:'⚙️', label:'Admin Center', sec:'Admin', badge:()=>DB.getPending().length},
// ];
// const NAV_USER = [
//   {id:'dashboard', icon:'📊', label:'Dashboard',    sec:'Main'},
//   {id:'employees', icon:'👥', label:'SkillSet',     sec:'Main'},
//   {id:'allocations',icon:'🎯',label:'Allocations',  sec:'Main'},
//   {id:'requirements',icon:'📋',label:'Requirements',sec:'Main'},
//   {id:'workforce', icon:'🧠', label:'Workforce AI', sec:'Intelligence'},
//   {id:'reports',   icon:'📈', label:'Reports',      sec:'Analytics'},
//   {id:'upload',    icon:'📂', label:'Data Import',  sec:'Data'},
// ];

// function buildSidebar(){
//   const pages = CU.role==='admin' ? NAV_ADMIN : NAV_USER;
//   let html=''; let lastSec='';
//   for(const p of pages){
//     if(p.sec!==lastSec){html+=`<div class="sb-sec"><div class="sb-sec-label">${p.sec}</div>`;lastSec=p.sec;}
//     const b = p.badge ? p.badge() : 0;
//     html+=`<button class="sb-item" id="sb-${p.id}" onclick="navigateTo('${p.id}')"><span class="sb-icon">${p.icon}</span>${p.label}${b>0?`<span class="sb-badge">${b}</span>`:''}</button>`;
//   }
//   html += '</div>';
//   document.getElementById('sb-scroll').innerHTML = html;
// }

// function navigateTo(page){
//   // Close mobile sidebar if open
//   document.getElementById('sidebar')?.classList.remove('mob-open');
//   document.getElementById('sb-overlay')?.classList.remove('visible');
//   document.querySelectorAll('.sb-item').forEach(el=>el.classList.remove('active'));
//   document.getElementById(`sb-${page}`)?.classList.add('active');
//   document.getElementById('tb-page').textContent = page.charAt(0).toUpperCase()+page.slice(1);
//   const body = document.getElementById('page-body');
//   if(!body){ console.error('page-body element not found'); return; }
//   const deptScope = CU.role==='admin' ? null : CU.department;
//   try {
//     switch(page){
//       case 'dashboard':   body.innerHTML=pageDash();      initDash(deptScope);    break;
//       case 'employees':   body.innerHTML=pageEmps();      initEmps(deptScope);    break;
//       case 'allocations': body.innerHTML=pageAllocs();    initAllocs(deptScope);  break;
//       case 'requirements':body.innerHTML=pageReqs();      initReqs();             break;
//       case 'workforce':   body.innerHTML=pageWorkforce(); break;
//       case 'reports':     body.innerHTML=pageReports();   initReports(deptScope); break;
//       case 'upload':      body.innerHTML=pageUpload();    break;
//       case 'admin':       body.innerHTML=pageAdmin();     initAdmin();            break;
//       default:            body.innerHTML=pageDash();      initDash(deptScope);
//     }
//   } catch(err) {
//     console.error('navigateTo error on page:', page, err);
//     body.innerHTML = `<div class="empty"><div class="empty-ico">⚠️</div><div class="empty-msg">Error loading ${page}: ${err.message}</div></div>`;
//   }
// }

// // Shorthand helpers
// function sc(){ return CU.role==='admin' ? null : CU.department; }
// function uDept(){ return CU.department; }

// // ════════════════════════════════════════════════════════
// // UI HELPERS
// // ════════════════════════════════════════════════════════
// function toast(msg, type='info', dur=3500){
//   const w = document.getElementById('toasts');
//   const t = document.createElement('div');
//   const icons = {ok:'✅',err:'❌',info:'ℹ️',warn:'⚠️'};
//   t.className = `toast t-${type}`;
//   t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${msg}</span>`;
//   w.appendChild(t);
//   setTimeout(()=>{t.classList.add('hiding');setTimeout(()=>t.remove(),300);}, dur);
// }
// function showAlert(id, msg, type='err'){
//   const el = document.getElementById(id); if(!el) return;
//   el.innerHTML = `<div class="alert a-${type}">${msg}</div>`;
//   setTimeout(()=>{if(el)el.innerHTML='';}, 5500);
// }
// function openDlg(html){
//   closeDlg();
//   const ov = document.createElement('div');
//   ov.className='dlg-overlay'; ov.id='dlg-active';
//   ov.innerHTML = `<div class="dlg">${html}<button class="dlg-close" onclick="closeDlg()">✕</button></div>`;
//   ov.addEventListener('click', e=>{if(e.target===ov)closeDlg();});
//   document.getElementById('dlg-root').appendChild(ov);
// }
// function closeDlg(){const el=document.getElementById('dlg-active');if(el)el.remove();}
// function addDynField(id){
//   const w=document.getElementById(id);const r=document.createElement('div');r.className='dyn-row';
//   r.innerHTML=`<input class="form-input ek" placeholder="Field name" style="max-width:130px"/><input class="form-input ev" placeholder="Value"/><button class="btn btn-xs btn-red" onclick="this.parentElement.remove()" style="flex-shrink:0">✕</button>`;
//   w.appendChild(r);
// }
// function getDynFields(id){
//   const out={};
//   document.querySelectorAll(`#${id} .dyn-row`).forEach(r=>{
//     const k=r.querySelector('.ek')?.value.trim(); const v=r.querySelector('.ev')?.value.trim();
//     if(k&&v) out['_extra_'+k]=v;
//   });
//   return out;
// }
// function skillChips(skills, max=5){
//   if(!skills) return '—';
//   const arr = String(skills).split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
//   const shown = arr.slice(0,max); const extra = arr.length-shown.length;
//   return shown.map(s=>`<span class="chip">${s}</span>`).join('') + (extra>0?`<span class="chip">+${extra}</span>`:'');
// }
// function utilBadge(u){const c=u>=90?'b-red':u>=70?'b-amber':'b-green';return`<span class="badge ${c}">${u}%</span>`}
// function availBadge(a){const c=a>=100?'b-green':a>=50?'b-teal':a>=20?'b-amber':'b-red';return`<span class="badge ${c}">${a}% free</span>`}
// function progBar(v){const p=Math.min(100,v);const c=p>=90?'pf-err':p>=70?'pf-warn':p>=40?'pf-half':'pf-ok';return`<div class="prog-wrap"><div class="prog-bar"><div class="prog-fill ${c}" style="width:${p}%"></div></div><span class="prog-pct">${v}%</span></div>`}
// function formatExtra(obj){return Object.entries(obj).filter(([k])=>k.startsWith('_extra_')).map(([k,v])=>`<span class="chip chip-teal">${k.replace('_extra_','')}: ${v}</span>`).join('')}
// function togglePass(id,btn){const el=document.getElementById(id);if(!el)return;const show=el.type==='password';el.type=show?'text':'password';btn.textContent=show?'🙈':'👁';}
// function checkStrength(p){
//   const bar=document.getElementById('ps-bar');const lbl=document.getElementById('ps-label');if(!bar)return;
//   let score=0;if(p.length>=8)score++;if(/[A-Z]/.test(p))score++;if(/[0-9]/.test(p))score++;if(/[^A-Za-z0-9]/.test(p))score++;if(p.length>=12)score++;
//   const pcts=[0,25,50,75,100];const cols=['var(--red)','var(--red)','var(--amber)','var(--amber2)','var(--green)'];const labels=['','Weak','Fair','Good','Strong'];
//   bar.style.width=pcts[score]+'%';bar.style.background=cols[score];if(lbl){lbl.textContent=labels[score];lbl.style.color=cols[score];}
// }
// function toggleUMenu(){document.getElementById('user-dd').classList.toggle('open');}
// document.addEventListener('click',e=>{if(!e.target.closest('.user-menu'))document.getElementById('user-dd')?.classList.remove('open');});

// // ════════════════════════════════════════════════════════
// // DASHBOARD
// // ════════════════════════════════════════════════════════
// function pageDash(){return`
// <div class="page-hdr">
//   <div class="page-hdr-left"><h1>Dashboard</h1><p>Live workforce allocation overview</p></div>
//   <div class="page-hdr-actions">
//     <button class="btn btn-ghost btn-sm" onclick="navigateTo('upload')">📂 Import</button>
//     <button class="btn btn-teal btn-sm" onclick="navigateTo('workforce')">🧠 AI Search</button>
//   </div>
// </div>
// <div class="stat-grid" id="d-stats"></div>
// <div class="grid-2" style="margin-bottom:17px">
//   <div class="card"><div class="card-hdr"><span class="card-title">Utilization Distribution</span></div><div class="chart-box"><canvas id="ch-util"></canvas></div></div>
//   <div class="card"><div class="card-hdr"><span class="card-title">Top Skills</span></div><div class="chart-box"><canvas id="ch-sk"></canvas></div></div>
// </div>
// <div class="grid-2">
//   <div class="card"><div class="card-hdr"><span class="card-title">Recent Allocations</span><button class="btn btn-xs btn-outline" onclick="navigateTo('allocations')">All →</button></div><div id="d-allocs"></div></div>
//   <div class="card"><div class="card-hdr"><span class="card-title">Open Requirements</span><button class="btn btn-xs btn-outline" onclick="navigateTo('requirements')">All →</button></div><div id="d-reqs"></div></div>
// </div>`}

// function initDash(dept){
//   const emps=DB.getEmployees(dept);const allocs=DB.getAllocations(dept);
//   const projs=DB.getProjects(dept);const reqs=DB.getRequirements(dept);
//   const openR=reqs.filter(r=>r.status==='Open').length;
//   const avgU=emps.length?Math.round(emps.reduce((s,e)=>s+DB.empUtil(e.id),0)/emps.length):0;
//   const free=emps.filter(e=>DB.empUtil(e.id)===0).length;
//   const endingSoon=emps.filter(e=>DB.empAllocs(e.id).some(a=>AI.endingWithinDays(a,30))).length;

//   document.getElementById('d-stats').innerHTML=`
//     <div class="stat-card"><div class="stat-card-icon">👥</div><div class="stat-label">Employees</div><div class="stat-val">${emps.length}</div><div class="stat-meta ok">${free} fully free</div><div class="stat-bar"><div class="stat-bar-fill" style="width:100%;background:var(--teal)"></div></div></div>
//     <div class="stat-card"><div class="stat-card-icon">🎯</div><div class="stat-label">Active Projects</div><div class="stat-val">${projs.length}</div><div class="stat-meta">${allocs.length} allocations</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${Math.min(100,projs.length*8)}%;background:var(--blue)"></div></div></div>
//     <div class="stat-card"><div class="stat-card-icon">⚡</div><div class="stat-label">Avg Utilization</div><div class="stat-val">${avgU}<small style="font-size:.9rem">%</small></div><div class="stat-meta ${avgU>85?'err':avgU>70?'warn':'ok'}">${avgU>85?'⚠ Overloaded':avgU>70?'◉ Moderate':'✓ Healthy'}</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${avgU}%;background:${avgU>85?'var(--red)':avgU>70?'var(--amber)':'var(--teal)'}"></div></div></div>
//     <div class="stat-card"><div class="stat-card-icon">📋</div><div class="stat-label">Open Requirements</div><div class="stat-val">${openR}</div><div class="stat-meta warn">${reqs.length} total</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${reqs.length?openR/reqs.length*100:0}%;background:var(--amber)"></div></div></div>
//     <div class="stat-card"><div class="stat-card-icon">📅</div><div class="stat-label">Ending in 30d</div><div class="stat-val">${endingSoon}</div><div class="stat-meta ${endingSoon>0?'warn':'ok'}">${endingSoon>0?'⚠ Plan replacements':'✓ Stable'}</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${emps.length?endingSoon/emps.length*100:0}%;background:var(--cyan)"></div></div></div>`;

//   const buckets={'Free':0,'≤25%':0,'26–50%':0,'51–75%':0,'76–99%':0,'100%':0};
//   emps.forEach(e=>{const u=DB.empUtil(e.id);if(u===0)buckets['Free']++;else if(u<=25)buckets['≤25%']++;else if(u<=50)buckets['26–50%']++;else if(u<=75)buckets['51–75%']++;else if(u<100)buckets['76–99%']++;else buckets['100%']++;});
//   const ctx1=document.getElementById('ch-util')?.getContext('2d');
//   if(ctx1)new Chart(ctx1,{type:'bar',data:{labels:Object.keys(buckets),datasets:[{data:Object.values(buckets),backgroundColor:['#22d46a','#00c8b4','#3d8bff','#f0a500','#ff7043','#ff4466'],borderRadius:5,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070',font:{size:11}},grid:{color:'rgba(0,200,180,.04)'}},y:{ticks:{color:'#4a6070',stepSize:1},grid:{color:'rgba(0,200,180,.04)'},beginAtZero:true}}}});

//   const skCount={};emps.forEach(e=>String(e.skills||'').split(/[,;|]/).map(s=>s.trim().toLowerCase()).filter(s=>s.length>1).forEach(s=>{skCount[s]=(skCount[s]||0)+1;}));
//   const topSk=Object.entries(skCount).sort((a,b)=>b[1]-a[1]).slice(0,7);
//   const ctx2=document.getElementById('ch-sk')?.getContext('2d');
//   if(ctx2)new Chart(ctx2,{type:'doughnut',data:{labels:topSk.map(s=>s[0]),datasets:[{data:topSk.map(s=>s[1]),backgroundColor:['#00c8b4','#3d8bff','#22d46a','#f0a500','#ff4466','#a55eea','#06c8e8'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{color:'#7fa0b0',boxWidth:10,padding:9,font:{size:11}}}}}});

//   const recentA=[...allocs].sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)).slice(0,5);
//   const dA=document.getElementById('d-allocs');
//   if(!recentA.length){dA.innerHTML=`<div class="empty"><div class="empty-ico">🎯</div><div class="empty-msg">No allocations yet</div></div>`;}
//   else dA.innerHTML=`<div class="tbl-wrap"><table><thead><tr><th>Employee</th><th>Project</th><th>%</th></tr></thead><tbody>${recentA.map(a=>{const emp=DB.getEmployees().find(e=>e.id===a.employeeId);return`<tr><td><strong>${emp?.name||'?'}</strong></td><td>${a.projectName}</td><td>${utilBadge(a.percentage)}</td></tr>`;}).join('')}</tbody></table></div>`;

//   const openRqs=reqs.filter(r=>r.status==='Open').slice(0,5);
//   const dR=document.getElementById('d-reqs');
//   if(!openRqs.length){dR.innerHTML=`<div class="empty"><div class="empty-ico">📋</div><div class="empty-msg">No open requirements</div></div>`;}
//   else dR.innerHTML=`<div class="tbl-wrap"><table><thead><tr><th>Role</th><th>Band</th><th>Priority</th></tr></thead><tbody>${openRqs.map(r=>`<tr><td><strong>${r.role||'—'}</strong></td><td>${BAND.renderBand(BAND.normalize(r.designation||r.band||''))}</td><td><span class="badge ${r.priority==='High'?'b-red':r.priority==='Medium'?'b-amber':'b-blue'}">${r.priority||'Normal'}</span></td></tr>`).join('')}</tbody></table></div>`;
// }

// // ════════════════════════════════════════════════════════
// // EMPLOYEES PAGE
// // ════════════════════════════════════════════════════════
// function pageEmps(){return`
// <div class="page-hdr">
//   <div class="page-hdr-left"><h1>${CU.role==='admin'?'All Employees':'SkillSet'}</h1><p>Manage profiles, designations, skills and allocation status</p></div>
//   <div class="page-hdr-actions">
//     <button class="btn btn-ghost btn-sm" onclick="exportEmps()">⬇ Export</button>
//     <button class="btn btn-teal btn-sm" onclick="dlgAddEmp()">+ Add Employee</button>
//   </div>
// </div>
// <div class="filter-row">
//   <input type="text" id="f-es" class="fi-text" style="min-width:210px" placeholder="🔍 Search name, skills, band..."/>
//   <select id="f-ed" class="fi" onchange="renderEmps()">${CU.role==='admin'?'<option value="">All Departments</option>'+DB.getDepts().map(d=>`<option>${d}</option>`).join(''):`<option>${CU.department}</option>`}</select>
//   <select id="f-eb" class="fi" onchange="renderEmps()"><option value="">All Bands</option>${BAND.ORDER.map(b=>`<option>${b}</option>`).join('')}</select>
//   <select id="f-ea" class="fi" onchange="renderEmps()"><option value="">Any Availability</option><option value="free">100% Free</option><option value="partial">≤50% Allocated</option><option value="ending">Ending in 30d</option><option value="internal">Internal Only</option><option value="busy">Busy (&gt;50%)</option></select>
//   <select id="f-el" class="fi" onchange="renderEmps()"><option value="">All Locations</option></select>
// </div>
// <div class="card">
//   <div class="card-hdr"><span class="card-title" id="emp-cnt">Loading...</span></div>
//   <div class="tbl-wrap"><table>
//     <thead><tr><th>Employee</th><th>Emp ID</th><th>Cert</th><th>Department</th><th>Designation/Band</th><th>Skills</th><th>Experience</th><th>Location</th><th>Utilization</th><th>Available</th><th>Status</th><th>Actions</th></tr></thead>
//     <tbody id="emp-tbody"></tbody>
//   </table></div>
// </div>`}

// function initEmps(dept){
//   const emps=DB.getEmployees(dept);
//   const locs=[...new Set(emps.map(e=>e.location||'').filter(Boolean))];
//   const ls=document.getElementById('f-el');locs.forEach(l=>ls.innerHTML+=`<option>${l}</option>`);
//   if(CU.role!=='admin'){const ds=document.getElementById('f-ed');if(ds)ds.disabled=true;}
//   document.getElementById('f-es').addEventListener('input',renderEmps);
//   renderEmps();
// }

// function renderEmps(){
//   const search=(document.getElementById('f-es')?.value||'').toLowerCase();
//   const deptF=document.getElementById('f-ed')?.value||'';
//   const bandF=document.getElementById('f-eb')?.value||'';
//   const availF=document.getElementById('f-ea')?.value||'';
//   const locF=document.getElementById('f-el')?.value||'';
//   let emps=DB.getEmployees(sc());
//   if(deptF)emps=emps.filter(e=>e.department===deptF);
//   if(bandF)emps=emps.filter(e=>BAND.normalize(e.designation||e.band||'')===(bandF));
//   if(locF)emps=emps.filter(e=>(e.location||'').toLowerCase()===locF.toLowerCase());
//   if(search)emps=emps.filter(e=>String(e.name||'').toLowerCase().includes(search)||String(e.skills||'').toLowerCase().includes(search)||String(e.designation||'').toLowerCase().includes(search)||String(e.location||'').toLowerCase().includes(search));
//   if(availF){
//     emps=emps.filter(e=>{
//       const u=DB.empUtil(e.id);const allocs=DB.empAllocs(e.id);
//       if(availF==='free')return u===0;
//       if(availF==='partial')return u>0&&u<=50;
//       if(availF==='ending')return allocs.some(al=>AI.endingWithinDays(al,30));
//       if(availF==='internal')return allocs.length>0&&allocs.every(al=>AI.isInternal(al.projectName));
//       if(availF==='busy')return u>50;
//       return true;
//     });
//   }
//   const lbl=document.getElementById('emp-cnt');if(lbl)lbl.textContent=`${emps.length} employee${emps.length!==1?'s':''} found`;
//   const tbody=document.getElementById('emp-tbody');if(!tbody)return;
//   if(!emps.length){tbody.innerHTML=`<tr><td colspan="12"><div class="empty"><div class="empty-ico">👥</div><div class="empty-msg">No employees match your filters</div></div></td></tr>`;return;}
//   tbody.innerHTML=emps.map(e=>{
//     const u=DB.empUtil(e.id);const a=100-u;const empB=BAND.normalize(e.designation||e.band||e.level||'');
//     const allocs=DB.empAllocs(e.id);
//     const endingSoon=allocs.some(al=>AI.endingWithinDays(al,30));
//     const ending60=allocs.some(al=>AI.endingWithinDays(al,60));
//     const allInternal=allocs.length>0&&allocs.every(al=>AI.isInternal(al.projectName));
//     let statusBadge='';
//     if(u===0)statusBadge='<span class="badge b-green">Free</span>';
//     else if(u<=50)statusBadge=`<span class="badge b-teal">Partial</span>`;
//     else if(endingSoon)statusBadge='<span class="badge b-cyan">Ending 30d</span>';
//     else if(ending60)statusBadge='<span class="badge b-blue">Ending 60d</span>';
//     else if(allInternal)statusBadge='<span class="badge b-purple">Internal</span>';
//     else statusBadge=`<span class="badge b-amber">Busy</span>`;
//     // Certified detection — check isCertified field and any _extra_ cert column
//     const certRaw=String(e.isCertified||e._certified||e['_extra_Certified']||e['_extra_Certification']||e['_extra_Certified or Not']||'').toLowerCase().trim();
//     const certified=certRaw==='yes'||certRaw==='y'||certRaw==='1'||certRaw==='true'||certRaw==='certified';
//     // Aspiring skills — those with (aspiring) suffix in skills field
//     const aspiringSkills=AI.getAspiringSkills(e);
//     const aspiringHtml=aspiringSkills.length?`<div style="margin-top:3px">${aspiringSkills.slice(0,3).map(s=>`<span class="chip" style="font-size:.61rem;color:var(--purple);border:1px solid rgba(165,94,234,.3);background:rgba(165,94,234,.06)" title="Interested to learn">📚 ${s}</span>`).join('')}${aspiringSkills.length>3?`<span class="chip" style="font-size:.61rem">+${aspiringSkills.length-3}</span>`:''}</div>`:'';
//     const empIdHtml=e.employeeId?`<span style="font-family:var(--mono);font-size:.74rem;color:var(--text2)">${e.employeeId}</span>`:`<span style="color:var(--text3);font-size:.72rem">—</span>`;
//     const certHtml=certified?`<span class="badge b-green" title="Certified">🏅 Yes</span>`:`<span style="color:var(--text3);font-size:.72rem">No</span>`;
//     return`<tr>
//       <td><div style="font-weight:700">${e.name}</div>${e.email?`<div style="font-size:.71rem;color:var(--text3)">${e.email}</div>`:''}</td>
//       <td>${empIdHtml}</td>
//       <td>${certHtml}</td>
//       <td><span class="badge b-blue">${e.department||'—'}</span></td>
//       <td>${empB?BAND.renderBand(empB):'<span style="color:var(--text3)">—</span>'}<br/><span style="font-size:.71rem;color:var(--text3)">${e.designation||''}</span></td>
//       <td style="max-width:200px">${skillChips(e.skills)}${aspiringHtml}</td>
//       <td style="font-family:var(--mono);font-size:.82rem">${e.experienceYears?e.experienceYears+' yr':'—'}</td>
//       <td>${e.location?`📍 ${e.location}`:'—'}</td>
//       <td style="min-width:125px">${progBar(u)}</td>
//       <td>${availBadge(a)}</td>
//       <td>${statusBadge}</td>
//       <td><div style="display:flex;gap:4px;flex-wrap:wrap">
//         <button class="btn btn-xs btn-outline" onclick="dlgAllocate('${e.id}')">Allocate</button>
//         <button class="btn btn-xs btn-ghost" onclick="dlgEditEmp('${e.id}')">Edit</button>
//         <button class="btn btn-xs btn-red" onclick="delEmp('${e.id}')">Del</button>
//       </div></td>
//     </tr>`;
//   }).join('');
// }

// function exportEmps(){
//   if(!window.XLSX){toast('XLSX not available','err');return;}
//   const emps=DB.getEmployees(sc());if(!emps.length)return toast('No data','warn');
//   const rows=emps.map(e=>({Name:e.name,Email:e.email,Dept:e.department,Designation:e.designation,Band:BAND.normalize(e.designation||e.band||''),Exp:e.experienceYears,Location:e.location,Skills:e.skills,Util:DB.empUtil(e.id)+'%',Avail:(100-DB.empUtil(e.id))+'%'}));
//   const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Employees');XLSX.writeFile(wb,'ResourceAI_Employees.xlsx');toast('Exported!','ok');
// }

// function dlgAddEmp(){
//   openDlg(`<div class="dlg-title">Add Employee</div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Full Name *</label><input id="de-n" class="form-input" placeholder="John Doe"/></div><div class="form-group"><label class="form-label">Email</label><input id="de-e" type="email" class="form-input" placeholder="john@co.com"/></div></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Employee ID</label><input id="de-id" class="form-input" placeholder="EMP001"/></div><div class="form-group"><label class="form-label">Department *</label><select id="de-d" class="form-select">${DB.getDepts().map(d=>`<option ${d===uDept()?'selected':''}>${d}</option>`).join('')}</select></div></div>
//   <div class="form-row">
//     <div class="form-group"><label class="form-label">Designation / Band *</label>
//       <input id="de-b" class="form-input" placeholder="Click a band below or type..." readonly style="cursor:pointer"/>
//       <div class="band-explain" style="margin-top:6px">${BAND.ORDER.map(b=>`<button type="button" class="band-pill ${BAND.getBandClass(b)}" style="cursor:pointer;border:none;font-family:var(--font);font-weight:700;padding:3px 9px;border-radius:4px" onclick="document.getElementById('de-b').value='${b}';this.closest('.band-explain').querySelectorAll('.band-pill').forEach(x=>x.style.outline='none');this.style.outline='2px solid var(--teal)'">${b}</button>`).join('')}</div>
//     </div>
//     <div class="form-group"><label class="form-label">Experience (years)</label><input id="de-exp" type="number" class="form-input" placeholder="5" min="0"/></div>
//   </div>
//   <div class="form-group"><label class="form-label">Location</label><input id="de-loc" class="form-input" placeholder="Hyderabad, Bangalore, Remote..."/></div>
//   <div class="form-group"><label class="form-label">Primary Skills (comma-separated)</label><textarea id="de-sk" class="form-textarea" placeholder="React, Node.js, Python, AWS..."></textarea></div>
//   <div class="form-group"><label class="form-label">Secondary Skills</label><input id="de-sk2" class="form-input" placeholder="Docker, SQL, Git..."/></div>
//   <div><label class="form-label">Custom Fields</label><div id="de-ex"></div><button class="btn btn-xs btn-ghost" style="margin-top:5px" onclick="addDynField('de-ex')">+ Field</button></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:16px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveAddEmp()">Save</button>
//   </div>`);
// }

// function saveAddEmp(){
//   const name=document.getElementById('de-n').value.trim();const dept=document.getElementById('de-d').value;
//   if(!name||!dept)return toast('Name and Department required','err');
//   const rawBand=document.getElementById('de-b').value.trim();
//   DB.addEmployee({name,email:document.getElementById('de-e').value.trim(),employeeId:document.getElementById('de-id').value.trim(),department:dept,designation:rawBand,_normalizedBand:BAND.normalize(rawBand)||rawBand,experienceYears:document.getElementById('de-exp').value.trim(),location:document.getElementById('de-loc').value.trim(),skills:document.getElementById('de-sk').value.trim(),secondarySkills:document.getElementById('de-sk2').value.trim(),...getDynFields('de-ex')});
//   closeDlg();renderEmps();toast('Employee added','ok');
// }

// function dlgEditEmp(id){
//   const e=DB.getEmployees().find(x=>x.id===id);if(!e)return;
//   openDlg(`<div class="dlg-title">Edit: ${e.name}</div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Name</label><input id="ee-n" class="form-input" value="${e.name||''}"/></div><div class="form-group"><label class="form-label">Email</label><input id="ee-e" class="form-input" value="${e.email||''}"/></div></div>
//   <div class="form-row">
//     <div class="form-group"><label class="form-label">Designation / Band</label>
//       <input id="ee-b" class="form-input" value="${e.designation||''}" placeholder="Click a band below or type..." readonly style="cursor:pointer"/>
//       <div class="band-explain" style="margin-top:6px">${BAND.ORDER.map(b=>`<button type="button" class="band-pill ${BAND.getBandClass(b)}" style="cursor:pointer;border:none;font-family:var(--font);font-weight:700;padding:3px 9px;border-radius:4px;${(BAND.normalize(e.designation||'')||'')==b?'outline:2px solid var(--teal)':''}" onclick="document.getElementById('ee-b').value='${b}';this.closest('.band-explain').querySelectorAll('.band-pill').forEach(x=>x.style.outline='none');this.style.outline='2px solid var(--teal)'">${b}</button>`).join('')}` +
//       `</div>
//     </div>
//     <div class="form-group"><label class="form-label">Experience (yrs)</label><input id="ee-exp" type="number" class="form-input" value="${e.experienceYears||''}"/></div>
//   </div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Location</label><input id="ee-loc" class="form-input" value="${e.location||''}"/></div><div class="form-group"><label class="form-label">Department</label><input id="ee-d" class="form-input" value="${e.department||''}"/></div></div>
//   <div class="form-group"><label class="form-label">Primary Skills</label><textarea id="ee-sk" class="form-textarea">${e.skills||''}</textarea></div>
//   <div class="form-group"><label class="form-label">Secondary Skills</label><input id="ee-sk2" class="form-input" value="${e.secondarySkills||''}"/></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:16px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveEditEmp('${id}')">Update</button>
//   </div>`);
// }

// function saveEditEmp(id){
//   const rawBand=document.getElementById('ee-b').value.trim();
//   DB.updateEmployee(id,{name:document.getElementById('ee-n').value.trim(),email:document.getElementById('ee-e').value.trim(),designation:rawBand,_normalizedBand:BAND.normalize(rawBand)||rawBand,experienceYears:document.getElementById('ee-exp').value.trim(),location:document.getElementById('ee-loc').value.trim(),department:document.getElementById('ee-d').value.trim(),skills:document.getElementById('ee-sk').value.trim(),secondarySkills:document.getElementById('ee-sk2').value.trim()});
//   closeDlg();renderEmps();toast('Updated','ok');
// }

// function delEmp(id){
//   const e=DB.getEmployees().find(x=>x.id===id);if(!confirm(`Remove ${e?.name}?`))return;
//   DB.deleteEmployee(id);DB.empAllocs(id).forEach(a=>DB.removeAllocation(a.id));renderEmps();toast('Removed','info');
// }

// function dlgAllocate(empId){
//   const emp=DB.getEmployees().find(e=>e.id===empId);if(!emp)return;
//   const util=DB.empUtil(empId);const avail=100-util;const existing=DB.empAllocs(empId);const projs=DB.getProjects(sc());
//   openDlg(`<div class="dlg-title">Allocate: ${emp.name} ${BAND.renderBand(BAND.normalize(emp.designation||emp.band||''))}</div>
//   <div class="alert a-info" style="margin-bottom:13px">Utilization: <strong>${util}%</strong> &nbsp;·&nbsp; Available: <strong>${avail}%</strong></div>
//   ${existing.length?`<div style="margin-bottom:14px"><label class="form-label">Current Allocations</label><div class="tbl-wrap"><table><tbody>${existing.map(a=>{const ending=AI.endingWithinDays(a,60);return`<tr><td>${a.projectName}${AI.isInternal(a.projectName)?'<span class="badge b-purple" style="margin-left:5px">Internal</span>':''}</td><td><strong style="color:var(--teal)">${a.percentage}%</strong></td><td style="font-size:.75rem;color:var(--text3)">${a.startDate||'—'} → ${a.endDate||'—'}${ending?` <span class="badge b-cyan">ending soon</span>`:''}</td><td><button class="btn btn-xs btn-red" onclick="rmAllocInDlg('${a.id}','${empId}')">Remove</button></td></tr>`;}).join('')}</tbody></table></div></div>`:''}
//   <div class="form-group"><label class="form-label">Project *</label>
//     <select id="al-p" class="form-select" onchange="checkNewPrj()">
//       <option value="">Select...</option>${projs.map(p=>`<option value="${p.id}">${p.name}${p.isInternal?' (Internal)':''}</option>`).join('')}
//       <option value="__new__">+ Create new project</option>
//     </select>
//   </div>
//   <div id="al-np-wrap" style="display:none">
//     <div class="form-row">
//       <div class="form-group"><label class="form-label">Project Name</label><input id="al-pname" class="form-input" placeholder="Project Alpha"/></div>
//       <div class="form-group"><label class="form-label">Type</label><select id="al-ptype" class="form-select"><option value="">Client / External</option><option value="internal">Internal / Bench</option></select></div>
//     </div>
//   </div>
//   <div class="form-row">
//     <div class="form-group"><label class="form-label">Allocation % (max ${avail}%)</label><input id="al-pct" type="number" class="form-input" min="1" max="${avail}" placeholder="30"/></div>
//     <div class="form-group"><label class="form-label">Start Date</label><input id="al-sd" type="date" class="form-input"/></div>
//   </div>
//   <div class="form-group"><label class="form-label">End Date</label><input id="al-ed" type="date" class="form-input"/></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveAlloc('${empId}')">Allocate</button>
//   </div>`);
// }

// function checkNewPrj(){const v=document.getElementById('al-p')?.value;const w=document.getElementById('al-np-wrap');if(w)w.style.display=v==='__new__'?'block':'none';}
// function rmAllocInDlg(allocId,empId){if(!confirm('Remove?'))return;DB.removeAllocation(allocId);closeDlg();dlgAllocate(empId);}

// function saveAlloc(empId){
//   let projId=document.getElementById('al-p')?.value;const pct=parseFloat(document.getElementById('al-pct')?.value||'0');
//   const util=DB.empUtil(empId);const avail=100-util;
//   if(!projId)return toast('Select project','err');
//   if(pct<=0||pct>avail)return toast(`Must be 1–${avail}%`,'err');
//   let projName='';let isInternal=false;
//   if(projId==='__new__'){const n=document.getElementById('al-pname')?.value.trim();if(!n)return toast('Enter project name','err');isInternal=document.getElementById('al-ptype')?.value==='internal';const p=DB.addProject({name:n,department:uDept(),isInternal});projId=p.id;projName=n;}
//   else{const p=DB.getProjects().find(x=>x.id===projId);projName=p?.name||'Unknown';isInternal=p?.isInternal||false;}
//   DB.addAllocation({employeeId:empId,projectId:projId,projectName:projName,isInternal,percentage:pct,startDate:document.getElementById('al-sd')?.value||'',endDate:document.getElementById('al-ed')?.value||''});
//   closeDlg();renderEmps();toast(`Allocated ${pct}% to ${projName}`,'ok');
// }

// // ════════════════════════════════════════════════════════
// // ALLOCATIONS PAGE
// // ════════════════════════════════════════════════════════
// function pageAllocs(){return`
// <div class="page-hdr">
//   <div class="page-hdr-left"><h1>Allocations</h1><p>All project allocations with real-time utilization tracking</p></div>
//   <div class="page-hdr-actions">
//     <button class="btn btn-ghost btn-sm" onclick="expAllocs()">⬇ Export</button>
//     <button class="btn btn-teal btn-sm" onclick="dlgNewAlloc()">+ New</button>
//   </div>
// </div>
// <div class="filter-row">
//   <input type="text" id="f-as" class="fi-text" style="min-width:200px" placeholder="🔍 Search employee..."/>
//   <select id="f-ap" class="fi" onchange="renderAllocs()"><option value="">All Projects</option></select>
//   <select id="f-atype" class="fi" onchange="renderAllocs()"><option value="">All Types</option><option value="external">Client/External</option><option value="internal">Internal/Bench</option></select>
// </div>
// <div class="card">
//   <div class="card-hdr"><span class="card-title" id="al-cnt">Loading...</span></div>
//   <div class="tbl-wrap"><table><thead><tr><th>Employee</th><th>Emp ID</th><th>Cert</th><th>Band</th><th>Dept</th><th>Project</th><th>Type</th><th>Allocation</th><th>Period</th><th>Total Util.</th><th>Actions</th></tr></thead>
//   <tbody id="al-tbody"></tbody></table></div>
// </div>`}

// function initAllocs(dept){
//   const projs=DB.getProjects(dept);const ps=document.getElementById('f-ap');
//   projs.forEach(p=>ps.innerHTML+=`<option value="${p.id}">${p.name}</option>`);
//   document.getElementById('f-as').addEventListener('input',renderAllocs);renderAllocs();
//   // Inject notification tab if notifications module loaded
//   if(typeof _injectAllocNotifTab==='function') _injectAllocNotifTab();
// }

// function renderAllocs(){
//   const search=(document.getElementById('f-as')?.value||'').toLowerCase();
//   const projF=document.getElementById('f-ap')?.value||'';
//   const typeF=document.getElementById('f-atype')?.value||'';
//   let allocs=DB.getAllocations(sc());
//   if(projF)allocs=allocs.filter(a=>a.projectId===projF);
//   if(typeF)allocs=allocs.filter(a=>typeF==='internal'?a.isInternal||AI.isInternal(a.projectName):!a.isInternal&&!AI.isInternal(a.projectName));
//   const tbody=document.getElementById('al-tbody');if(!tbody)return;
//   const rows=allocs.filter(a=>{const emp=DB.getEmployees().find(e=>e.id===a.employeeId);return emp&&(!search||emp.name.toLowerCase().includes(search)||(emp.employeeId||'').toLowerCase().includes(search));})
//   .map(a=>{
//     const emp=DB.getEmployees().find(e=>e.id===a.employeeId)||{};
//     const empB=BAND.normalize(emp.designation||emp.band||'');
//     const util=DB.empUtil(a.employeeId);const ending=AI.endingWithinDays(a,60);
//     const internal=a.isInternal||AI.isInternal(a.projectName);
//     const certRaw=String(emp.isCertified||emp._certified||emp['_extra_Certified']||emp['_extra_Certification']||'').toLowerCase().trim();
//     const certified=certRaw==='yes'||certRaw==='y'||certRaw==='1'||certRaw==='true'||certRaw==='certified';
//     const empIdHtml=emp.employeeId?`<span style="font-family:var(--mono);font-size:.74rem;color:var(--text2)">${emp.employeeId}</span>`:`<span style="color:var(--text3);font-size:.72rem">—</span>`;
//     const certHtml=certified?`<span class="badge b-green" title="Certified">🏅 Yes</span>`:`<span style="color:var(--text3);font-size:.72rem">No</span>`;
//     return`<tr>
//       <td><strong>${emp.name||'?'}</strong></td>
//       <td>${empIdHtml}</td>
//       <td>${certHtml}</td>
//       <td>${empB?BAND.renderBand(empB):'—'}</td>
//       <td><span class="badge b-blue">${emp.department||'—'}</span></td>
//       <td>${a.projectName}</td>
//       <td>${internal?'<span class="badge b-purple">Internal</span>':'<span class="badge b-teal">Client</span>'}</td>
//       <td>${progBar(a.percentage)}</td>
//       <td style="font-size:.76rem;color:var(--text2)">${a.startDate||'—'} → ${a.endDate||'—'}${ending?` <span class="badge b-cyan">⏰ ending</span>`:''}</td>
//       <td>${utilBadge(util)}</td>
//       <td><div style="display:flex;gap:4px">
//         <button class="btn btn-xs btn-ghost" onclick="dlgEditAlloc('${a.id}')">Edit</button>
//         <button class="btn btn-xs btn-red" onclick="delAlloc('${a.id}')">Del</button>
//       </div></td>
//     </tr>`;});
//   const lbl=document.getElementById('al-cnt');if(lbl)lbl.textContent=`${rows.length} allocation${rows.length!==1?'s':''}`;
//   tbody.innerHTML=rows.length?rows.join(''):`<tr><td colspan="11"><div class="empty"><div class="empty-ico">🎯</div><div class="empty-msg">No allocations found</div></div></td></tr>`;
// }

// function delAlloc(id){if(!confirm('Remove?'))return;DB.removeAllocation(id);renderAllocs();toast('Removed','info');}

// function dlgEditAlloc(id){
//   const a=DB.getAllocations().find(x=>x.id===id);if(!a)return;
//   const emp=DB.getEmployees().find(e=>e.id===a.employeeId);
//   const baseUtil=DB.empUtil(a.employeeId)-a.percentage;const max=100-baseUtil;
//   openDlg(`<div class="dlg-title">Edit Allocation</div>
//   <p style="color:var(--text2);margin-bottom:13px">${emp?.name||'?'} → ${a.projectName}</p>
//   <div class="form-group"><label class="form-label">Allocation % (max ${max}%)</label><input id="ea-p" type="number" class="form-input" value="${a.percentage}" min="1" max="${max}"/></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Start Date</label><input id="ea-s" type="date" class="form-input" value="${a.startDate||''}"/></div><div class="form-group"><label class="form-label">End Date</label><input id="ea-e" type="date" class="form-input" value="${a.endDate||''}"/></div></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveEditAlloc('${id}',${max})">Update</button>
//   </div>`);
// }

// function saveEditAlloc(id,max){
//   const p=parseFloat(document.getElementById('ea-p').value||0);if(p<=0||p>max)return toast(`1–${max}%`,'err');
//   DB.updateAllocation(id,{percentage:p,startDate:document.getElementById('ea-s').value,endDate:document.getElementById('ea-e').value});
//   closeDlg();renderAllocs();toast('Updated','ok');
// }

// function dlgNewAlloc(){
//   const emps=DB.getEmployees(sc());const projs=DB.getProjects(sc());
//   openDlg(`<div class="dlg-title">New Allocation</div>
//   <div class="form-group"><label class="form-label">Employee *</label>
//     <select id="na-emp" class="form-select" onchange="updateAvailNA()"><option value="">Select...</option>
//       ${emps.map(e=>{const u=DB.empUtil(e.id);return`<option value="${e.id}" data-avail="${100-u}">${e.name} ${BAND.normalize(e.designation||'')||''} (${100-u}% free)</option>`;}).join('')}
//     </select>
//   </div>
//   <div id="na-avail"></div>
//   <div class="form-group"><label class="form-label">Project *</label>
//     <select id="na-proj" class="form-select" onchange="checkNewPrjNA()"><option value="">Select...</option>
//       ${projs.map(p=>`<option value="${p.id}">${p.name}${p.isInternal?' (Internal)':''}</option>`).join('')}
//       <option value="__new__">+ New Project</option>
//     </select>
//   </div>
//   <div id="na-np" style="display:none"><div class="form-group"><label class="form-label">Project Name</label><input id="na-pn" class="form-input" placeholder="Project Name"/></div></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">% *</label><input id="na-pct" type="number" class="form-input" min="1" placeholder="30"/></div><div class="form-group"><label class="form-label">Start</label><input id="na-sd" type="date" class="form-input"/></div></div>
//   <div class="form-group"><label class="form-label">End</label><input id="na-ed" type="date" class="form-input"/></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveNewAlloc()">Allocate</button>
//   </div>`);
// }

// function updateAvailNA(){const sel=document.getElementById('na-emp');const av=sel.selectedOptions[0]?.dataset.avail;const info=document.getElementById('na-avail');if(av&&info){info.innerHTML=`<div class="alert a-info" style="margin-bottom:10px">Available: <strong>${av}%</strong></div>`;document.getElementById('na-pct').max=av;}}
// function checkNewPrjNA(){const v=document.getElementById('na-proj')?.value;const w=document.getElementById('na-np');if(w)w.style.display=v==='__new__'?'block':'none';}

// function saveNewAlloc(){
//   const empId=document.getElementById('na-emp')?.value;let projId=document.getElementById('na-proj')?.value;
//   const pct=parseFloat(document.getElementById('na-pct')?.value||'0');
//   if(!empId)return toast('Select employee','err');if(!projId)return toast('Select project','err');
//   const util=DB.empUtil(empId);const avail=100-util;
//   if(pct<=0||pct>avail)return toast(`1–${avail}%`,'err');
//   let projName='';
//   if(projId==='__new__'){const n=document.getElementById('na-pn')?.value.trim();if(!n)return toast('Enter project name','err');const p=DB.addProject({name:n,department:uDept()});projId=p.id;projName=n;}
//   else projName=DB.getProjects().find(p=>p.id===projId)?.name||'Unknown';
//   DB.addAllocation({employeeId:empId,projectId:projId,projectName:projName,percentage:pct,startDate:document.getElementById('na-sd')?.value||'',endDate:document.getElementById('na-ed')?.value||''});
//   closeDlg();renderAllocs();toast('Allocated!','ok');
// }

// function expAllocs(){
//   if(!window.XLSX)return toast('XLSX unavailable','err');
//   const allocs=DB.getAllocations(sc());if(!allocs.length)return toast('No data','warn');
//   const rows=allocs.map(a=>{const emp=DB.getEmployees().find(e=>e.id===a.employeeId)||{};return{Employee:emp.name,Band:BAND.normalize(emp.designation||''),Dept:emp.department,Project:a.projectName,Type:a.isInternal?'Internal':'Client','Alloc%':a.percentage,Start:a.startDate,End:a.endDate};});
//   const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Allocations');XLSX.writeFile(wb,'ResourceAI_Allocations.xlsx');toast('Exported!','ok');
// }

// // ════════════════════════════════════════════════════════
// // REQUIREMENTS PAGE
// // ════════════════════════════════════════════════════════
// function pageReqs(){return`
// <div class="page-hdr">
//   <div class="page-hdr-left"><h1>Requirements</h1><p>Project staffing requirements with band-aware AI matching</p></div>
//   <button class="btn btn-teal btn-sm" onclick="dlgAddReq()">+ New Requirement</button>
// </div>
// <div class="filter-row">
//   <input id="f-rs" type="text" class="fi-text" style="min-width:200px" placeholder="🔍 Search role, skills..."/>
//   <select id="f-rstat" class="fi" onchange="renderReqs()"><option value="">All Status</option><option>Open</option><option>In Progress</option><option>Fulfilled</option><option>Cancelled</option></select>
//   <select id="f-rpri" class="fi" onchange="renderReqs()"><option value="">All Priority</option><option>High</option><option>Medium</option><option>Low</option></select>
// </div>
// <div id="req-container"></div>`}

// function initReqs(){document.getElementById('f-rs').addEventListener('input',renderReqs);renderReqs();}

// function renderReqs(){
//   const search=(document.getElementById('f-rs')?.value||'').toLowerCase();
//   const statF=document.getElementById('f-rstat')?.value||'';const priF=document.getElementById('f-rpri')?.value||'';
//   let reqs=DB.getRequirements(sc());
//   if(statF)reqs=reqs.filter(r=>r.status===statF);if(priF)reqs=reqs.filter(r=>r.priority===priF);
//   if(search)reqs=reqs.filter(r=>String(r.role||'').toLowerCase().includes(search)||String(r.skills||'').toLowerCase().includes(search));
//   const container=document.getElementById('req-container');if(!container)return;
//   if(!reqs.length){container.innerHTML=`<div class="empty"><div class="empty-ico">📋</div><div class="empty-msg">No requirements. Add your first one.</div></div>`;return;}
//   container.innerHTML=reqs.map(r=>{
//     const normB=BAND.normalize(r.designation||r.band||'');
//     return`<div class="card" style="margin-bottom:13px" id="rc-${r.id}">
//       <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:11px">
//         <div style="flex:1;min-width:230px">
//           <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:7px">
//             <span style="font-weight:800;font-size:1rem">${r.role||r.title||'Requirement'}</span>
//             <span class="badge ${r.priority==='High'?'b-red':r.priority==='Medium'?'b-amber':'b-blue'}">${r.priority||'Normal'}</span>
//             <span class="badge ${r.status==='Open'?'b-green':r.status==='Fulfilled'?'b-teal':'b-gray'}">${r.status}</span>
//             ${r.forFreshers?'<span class="badge b-purple">Freshers Only (A1/A2)</span>':''}
//           </div>
//           <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:.8rem;color:var(--text2)">
//             ${r.skills?`<span>🔧 ${r.skills}</span>`:''}${r.experienceYears?`<span>📅 ${r.experienceYears}+ yrs</span>`:''}
//             ${normB?`<span>🎯 Band: ${BAND.renderBand(normB)}</span>`:''}${r.location?`<span>📍 ${r.location}</span>`:''}
//             ${r.headcount?`<span>👥 ${r.headcount} headcount</span>`:''}
//           </div>
//           ${r.description?`<p style="font-size:.8rem;color:var(--text3);margin-top:6px;line-height:1.55">${r.description}</p>`:''}
//         </div>
//         <div style="display:flex;gap:6px;flex-wrap:wrap;flex-shrink:0">
//           <button class="btn btn-teal btn-sm" onclick="findForReq('${r.id}')">🧠 Find Employees</button>
//           <button class="btn btn-outline btn-sm" onclick="dlgEditReq('${r.id}')">Edit</button>
//           <button class="btn btn-ghost btn-sm" onclick="cycleReqStatus('${r.id}','${r.status}')">↻</button>
//           <button class="btn btn-red btn-sm" onclick="delReq('${r.id}')">Del</button>
//         </div>
//       </div>
//       <div id="rm-${r.id}" style="margin-top:0"></div>
//     </div>`;
//   }).join('');
// }

// function cycleReqStatus(id,cur){const order=['Open','In Progress','Fulfilled','Cancelled'];DB.updateRequirement(id,{status:order[(order.indexOf(cur)+1)%order.length]});renderReqs();toast('Status updated','info');}
// function delReq(id){if(!confirm('Delete?'))return;DB.deleteRequirement(id);renderReqs();toast('Deleted','info');}

// function findForReq(reqId){
//   const req=DB.getRequirements().find(r=>r.id===reqId);if(!req)return;
//   const container=document.getElementById(`rm-${reqId}`);
//   container.innerHTML=`<div style="border-top:1px solid var(--border);margin-top:13px;padding-top:13px;display:flex;align-items:center;gap:10px;color:var(--text2);font-size:.84rem"><div class="spin"></div> AI matching employees by availability, band hierarchy, and skills...</div>`;
//   setTimeout(()=>{
//     const result=AI.findMatches(req,sc());
//     const total=result.free.length+result.partial.length+result.ending.length+result.internal.length;
//     if(total===0&&result.noMatch.length===0){container.innerHTML=`<div style="border-top:1px solid var(--border);margin-top:13px;padding-top:13px"><div class="alert a-warn">No employees match this requirement. Try adjusting band or skills, or import more employee data.</div></div>`;return;}
//     const normB=BAND.normalize(req.designation||req.band||'');
//     const validBandStr=normB?BAND.getValidBands(normB).join(', '):'Any';
//     let html=`<div style="border-top:1px solid var(--border);margin-top:13px;padding-top:13px">
//       <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:.76rem;color:var(--text3);margin-bottom:14px">
//         <span>🎯 Required Band: ${normB?BAND.renderBand(normB):'Any'}</span>
//         <span>📋 Eligible bands: <span style="font-family:var(--mono)">${validBandStr}</span></span>
//         ${req.forFreshers?'<span>🎓 Freshers only (A1/A2)</span>':''}
//       </div>`;
//     if(result.free.length){html+=`<div class="avail-tier at-free">🟢 Tier 1 — 100% Available (${result.free.length})</div>`;html+=result.free.map((e,i)=>renderMatchCard(e,i,'free')).join('');}
//     if(result.partial.length){html+=`<div class="avail-tier at-partial" style="margin-top:10px">🟡 Tier 2 — Partially Available ≤50% (${result.partial.length})</div>`;html+=result.partial.map((e,i)=>renderMatchCard(e,i,'partial')).join('');}
//     if(result.ending.length){html+=`<div class="avail-tier at-ending" style="margin-top:10px">📅 Tier 3 — Allocation Ending Soon 30–60d (${result.ending.length})</div>`;html+=result.ending.map((e,i)=>renderMatchCard(e,i,'ending')).join('');}
//     if(result.internal.length){html+=`<div class="avail-tier at-internal" style="margin-top:10px">🏢 Tier 4 — On Internal Project (${result.internal.length})</div>`;html+=result.internal.map((e,i)=>renderMatchCard(e,i,'internal')).join('');}
//     if(result.noMatch.length&&total>0){html+=`<div class="avail-tier at-none" style="margin-top:10px">🔴 Skill-Matched but Busy</div>`;html+=result.noMatch.map((e,i)=>renderMatchCard(e,i,'busy')).join('');}
//     if(total===0){html+=`<div class="alert a-warn">No band-matched employees available. Consider expanding the requirement.</div>`;}
//     html+='</div>';
//     container.innerHTML=html;
//   },500);
// }

// function renderMatchCard(e,i,tier){
//   const empB=BAND.normalize(e.designation||e.band||e.level||'');
//   const scCls=e._score>=75?'sr-high':e._score>=45?'sr-mid':'sr-low';
//   let tierInfo='';
//   if(tier==='ending')tierInfo=`<span class="badge b-cyan">⏰ Ends ${e._endDate||'soon'}</span>`;
//   if(tier==='internal')tierInfo=`<span class="badge b-purple">🏢 ${e._internalProj}</span>`;
//   const aspiringSkills=AI.getAspiringSkills(e);
//   const effectiveExp=AI.getEffectiveExp(e);
//   const allSkills=AI.getSkillObjects(e).filter(s=>!s.isAspiring);
//   const skillsHtml=allSkills.length>0
//     ?allSkills.slice(0,6).map(s=>{
//         const lvlColor=s.level==='expert'?'var(--teal)':s.level==='advanced'?'var(--amber2)':s.level==='beginner'?'var(--text3)':'var(--text2)';
//         const lvlBg=s.level==='expert'?'rgba(0,200,180,.12)':s.level==='advanced'?'rgba(240,165,0,.12)':'var(--surface3)';
//         return`<span class="chip" title="${s.level}" style="background:${lvlBg};color:${lvlColor}">${s.skill}${s.level==='expert'?'<sup>★★★</sup>':s.level==='advanced'?'<sup>★★</sup>':''}</span>`;
//       }).join('')+(allSkills.length>6?`<span class="chip">+${allSkills.length-6}</span>`:'')
//     :skillChips(e.skills,6);
//   return`<div class="ai-card" style="margin-top:8px">
//     <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
//       <div style="font-weight:900;font-size:.78rem;color:var(--text3);width:22px">#${i+1}</div>
//       <div class="score-ring ${scCls}">${e._score}%</div>
//       <div style="flex:1;min-width:180px">
//         <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:3px">
//           <strong style="font-size:.95rem">${e.name}</strong>
//           ${empB?BAND.renderBand(empB):''}
//           <span class="badge b-blue">${e.department||'—'}</span>
//           ${tierInfo}
//         </div>
//         <div style="font-size:.76rem;color:var(--text2);margin-bottom:5px">${effectiveExp||'?'} yrs exp · 📍 ${e.location||'—'}</div>
//         <div>${skillsHtml}</div>
//         ${aspiringSkills.length?`<div style="margin-top:4px"><span style="font-size:.65rem;color:var(--text3);font-style:italic">📚 Aspiring: </span>${aspiringSkills.slice(0,4).map(s=>`<span class="chip" style="color:var(--purple);font-style:italic">${s}</span>`).join('')}</div>`:''}
//       </div>
//       <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0">
//         ${availBadge(e._avail)}
//         <div style="font-size:.7rem;color:var(--text3)">${e._util}% allocated</div>
//         <button class="btn btn-teal btn-xs" onclick="dlgAllocate('${e.id}')">Allocate →</button>
//       </div>
//     </div>
//   </div>`;
// }

// function dlgAddReq(){
//   openDlg(`<div class="dlg-title">New Requirement</div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Role / Title *</label><input id="nr-r" class="form-input" placeholder="Senior React Developer"/></div><div class="form-group"><label class="form-label">Priority</label><select id="nr-p" class="form-select"><option>High</option><option selected>Medium</option><option>Low</option></select></div></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Required Skills (comma-sep)</label><input id="nr-sk" class="form-input" placeholder="React, Node.js, AWS..."/></div><div class="form-group"><label class="form-label">Min Experience (yrs)</label><input id="nr-exp" type="number" class="form-input" placeholder="3"/></div></div>
//   <div class="form-row">
//     <div class="form-group"><label class="form-label">Required Band</label>
//       <input id="nr-b" class="form-input" placeholder="B2, Senior, L4..." list="req-band-list"/>
//       <datalist id="req-band-list">${BAND.ORDER.map(b=>`<option value="${b}">`).join('')}</datalist>
//       <div class="band-explain" style="margin-top:5px">${BAND.ORDER.map(b=>`<span class="band-pill ${BAND.getBandClass(b)}">${b}</span>`).join('')}</div>
//     </div>
//     <div class="form-group"><label class="form-label">Location</label><input id="nr-loc" class="form-input" placeholder="Hyderabad, Remote..."/></div>
//   </div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Headcount</label><input id="nr-hc" type="number" class="form-input" value="1" min="1"/></div><div class="form-group"><label class="form-label">Department</label><select id="nr-d" class="form-select">${DB.getDepts().map(d=>`<option ${d===uDept()?'selected':''}>${d}</option>`).join('')}</select></div></div>
//   <div class="form-group" style="display:flex;align-items:center;gap:10px"><input type="checkbox" id="nr-fresh" style="width:16px;height:16px"/><label for="nr-fresh" style="font-size:.85rem;cursor:pointer;color:var(--text2)">🎓 For Freshers / New Joiners only (A1/A2)</label></div>
//   <div class="form-group"><label class="form-label">Description</label><textarea id="nr-desc" class="form-textarea" placeholder="Additional context..."></textarea></div>
//   <div><label class="form-label">Custom Fields</label><div id="nr-ex"></div><button class="btn btn-xs btn-ghost" style="margin-top:5px" onclick="addDynField('nr-ex')">+ Field</button></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveAddReq()">Save</button>
//   </div>`);
// }

// function saveAddReq(){
//   const role=document.getElementById('nr-r').value.trim();if(!role)return toast('Role required','err');
//   DB.addRequirement({role,priority:document.getElementById('nr-p').value,skills:document.getElementById('nr-sk').value.trim(),experienceYears:document.getElementById('nr-exp').value.trim(),designation:document.getElementById('nr-b').value.trim(),location:document.getElementById('nr-loc').value.trim(),headcount:document.getElementById('nr-hc').value.trim(),department:document.getElementById('nr-d').value,forFreshers:document.getElementById('nr-fresh').checked,description:document.getElementById('nr-desc').value.trim(),...getDynFields('nr-ex')});
//   closeDlg();renderReqs();toast('Requirement saved','ok');
// }

// function dlgEditReq(id){
//   const r=DB.getRequirements().find(x=>x.id===id);if(!r)return;
//   openDlg(`<div class="dlg-title">Edit Requirement</div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Role</label><input id="er-r" class="form-input" value="${r.role||''}"/></div><div class="form-group"><label class="form-label">Priority</label><select id="er-p" class="form-select"><option ${r.priority==='High'?'selected':''}>High</option><option ${r.priority==='Medium'?'selected':''}>Medium</option><option ${r.priority==='Low'?'selected':''}>Low</option></select></div></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Skills</label><input id="er-sk" class="form-input" value="${r.skills||''}"/></div><div class="form-group"><label class="form-label">Min Exp (yrs)</label><input id="er-exp" type="number" class="form-input" value="${r.experienceYears||''}"/></div></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Band</label><input id="er-b" class="form-input" value="${r.designation||''}"/></div><div class="form-group"><label class="form-label">Location</label><input id="er-loc" class="form-input" value="${r.location||''}"/></div></div>
//   <div class="form-group"><label class="form-label">Status</label><select id="er-s" class="form-select">${['Open','In Progress','Fulfilled','Cancelled'].map(s=>`<option ${r.status===s?'selected':''}>${s}</option>`).join('')}</select></div>
//   <div class="form-group" style="display:flex;align-items:center;gap:10px"><input type="checkbox" id="er-fresh" ${r.forFreshers?'checked':''} style="width:16px;height:16px"/><label for="er-fresh" style="font-size:.85rem;cursor:pointer;color:var(--text2)">🎓 Freshers only (A1/A2)</label></div>
//   <div class="form-group"><label class="form-label">Description</label><textarea id="er-desc" class="form-textarea">${r.description||''}</textarea></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveEditReq('${id}')">Update</button>
//   </div>`);
// }

// function saveEditReq(id){
//   DB.updateRequirement(id,{role:document.getElementById('er-r').value.trim(),priority:document.getElementById('er-p').value,skills:document.getElementById('er-sk').value.trim(),experienceYears:document.getElementById('er-exp').value.trim(),designation:document.getElementById('er-b').value.trim(),location:document.getElementById('er-loc').value.trim(),status:document.getElementById('er-s').value,forFreshers:document.getElementById('er-fresh').checked,description:document.getElementById('er-desc').value.trim()});
//   closeDlg();renderReqs();toast('Updated','ok');
// }

// // ════════════════════════════════════════════════════════
// // WORKFORCE AI PAGE
// // ════════════════════════════════════════════════════════
// function pageWorkforce(){return`
// <div class="page-hdr">
//   <div class="page-hdr-left"><h1>🧠 Workforce AI</h1><p>Semantic search — understands bands, synonyms, experience, availability and location</p></div>
// </div>
// <div class="card" style="margin-bottom:17px">
//   <div style="margin-bottom:12px">
//     <div style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--teal);margin-bottom:9px">Query examples</div>
//     <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:.8rem;color:var(--text2)">
//       <div>🔧 "React developer B2 Hyderabad"</div><div>📅 "Python engineer 5 years senior"</div>
//       <div>🎯 "DevOps AWS Cloud A3 available"</div><div>🎓 "Fresher Java A1 Bangalore"</div>
//     </div>
//   </div>
//   <div style="display:flex;gap:9px;margin-bottom:12px">
//     <div style="flex:1;display:flex;align-items:center;gap:9px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-sm);padding:9px 13px;transition:var(--t)" onfocusin="this.style.borderColor='var(--teal)'" onfocusout="this.style.borderColor='var(--border)'">
//       <span style="color:var(--text3)">🧠</span>
//       <input id="ai-q" type="text" style="flex:1;background:transparent;border:none;outline:none;color:var(--text);font-family:var(--font);font-size:.875rem" placeholder='e.g. "Senior React developer B2 4 years Hyderabad available"...' onkeydown="if(event.key==='Enter')doAISearch()" autocomplete="off"/>
//     </div>
//     <button class="btn btn-teal" onclick="doAISearch()" style="padding:10px 24px">Search</button>
//   </div>
//   <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:11px">
//     ${['React B2 developer','Python ML senior C1','DevOps AWS B3','Java backend B1','Project Manager C2 Hyderabad'].map(q=>`<button class="chip" style="cursor:pointer;padding:4px 9px;font-size:.75rem" onclick="document.getElementById('ai-q').value='${q}';doAISearch()">${q}</button>`).join('')}
//   </div>
//   <div class="filter-row" style="margin-bottom:0">
//     <select id="ai-dept" class="fi"><option value="">All Departments</option>${DB.getDepts().map(d=>`<option ${d===uDept()&&CU.role!=='admin'?'selected':''}>${d}</option>`).join('')}</select>
//     <select id="ai-avail" class="fi"><option value="">Any Availability</option><option value="100">100% Free only</option><option value="50">50%+ Available</option><option value="30">30%+ Available</option></select>
//     <select id="ai-band-filter" class="fi"><option value="">Any Band</option>${BAND.ORDER.map(b=>`<option>${b}</option>`).join('')}</select>
//   </div>
// </div>
// <div id="ai-results"></div>`}

// function doAISearch(){
//   const query=document.getElementById('ai-q')?.value.trim();if(!query)return toast('Enter a query','warn');
//   const deptF=document.getElementById('ai-dept')?.value||'';
//   const availMin=parseInt(document.getElementById('ai-avail')?.value||'0');
//   const bandFilter=document.getElementById('ai-band-filter')?.value||'';
//   const resEl=document.getElementById('ai-results');
//   resEl.innerHTML=`<div style="display:flex;align-items:center;gap:11px;color:var(--text2);font-size:.875rem;padding:16px 0"><div class="spin"></div> Analyzing query and scoring ${DB.getEmployees(sc()).length} employees...</div>`;
//   setTimeout(()=>{
//     const deptToSearch=CU.role==='admin'?(deptF||null):CU.department;
//     let results=AI.search(query,deptToSearch);
//     if(availMin>0)results=results.filter(e=>e._avail>=availMin);
//     if(bandFilter)results=results.filter(e=>e._band===bandFilter);
//     if(!results.length){
//       const freeEmps=DB.getEmployees(deptToSearch).filter(e=>DB.empUtil(e.id)===0).slice(0,4);
//       resEl.innerHTML=`<div class="alert a-warn" style="margin-bottom:14px">No employees matched <em>"${query}"</em>.</div>
//         ${freeEmps.length?`<div class="card"><div class="card-hdr"><span class="card-title">100% Free employees (no skill match)</span></div>${freeEmps.map(e=>`<div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid var(--border)"><div style="flex:1"><strong>${e.name}</strong> ${BAND.renderBand(BAND.normalize(e.designation||''))} <div style="font-size:.75rem;color:var(--text2)">${skillChips(e.skills,4)}</div></div><span class="badge b-green">100% free</span><button class="btn btn-xs btn-outline" onclick="dlgAllocate('${e.id}')">Allocate</button></div>`).join('')}</div>`:''}`;
//       return;
//     }
//     resEl.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:13px;flex-wrap:wrap;gap:7px">
//       <div style="font-size:.84rem;color:var(--text2)"><strong style="color:var(--text)">${results.length}</strong> employees matched <em>"${query}"</em></div>
//       <div style="font-size:.72rem;color:var(--text3)">Sorted by: Availability → Score → Band proximity</div>
//     </div>
//     ${results.map((e,i)=>{
//       const scCls=e._score>=70?'sr-high':e._score>=40?'sr-mid':'sr-low';
//       const empB=e._band;const bd=e._breakdown;
//       return`<div class="ai-card">
//         <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
//           <div style="font-weight:900;font-size:.78rem;color:var(--text3);width:22px">#${i+1}</div>
//           <div class="score-ring ${scCls}">${e._score}%</div>
//           <div style="flex:1;min-width:180px">
//             <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:3px">
//               <strong style="font-size:.97rem">${e.name}</strong>
//               ${empB?BAND.renderBand(empB):''}
//               <span class="badge b-blue">${e.department||'—'}</span>
//               ${e._endingSoon?'<span class="badge b-cyan">⏰ Ending 60d</span>':''}
//               ${e._allInternal?'<span class="badge b-purple">🏢 Internal</span>':''}
//             </div>
//             <div style="font-size:.76rem;color:var(--text2);margin-bottom:5px">${e.experienceYears||'?'} yrs · 📍 ${e.location||'—'}</div>
//             <div>${skillChips(e.skills,5)}</div>
//             <div style="display:flex;gap:10px;flex-wrap:wrap;font-size:.69rem;color:var(--text3);margin-top:7px">
//               <span>🔧 Skills:<strong style="color:var(--teal)">${bd?.skill||0}%</strong></span>
//               <span>📅 Exp:<strong style="color:var(--teal)">${bd?.exp||0}%</strong></span>
//               <span>🎯 Band:<strong style="color:var(--teal)">${bd?.band||0}%</strong></span>
//               <span>⚡ Avail:<strong style="color:var(--teal)">${bd?.avail||0}%</strong></span>
//               <span>📍 Loc:<strong style="color:var(--teal)">${bd?.loc||0}%</strong></span>
//             </div>
//           </div>
//           <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0">
//             ${availBadge(e._avail)}
//             <div style="font-size:.69rem;color:var(--text3)">${e._util}% allocated</div>
//             <button class="btn btn-teal btn-sm" onclick="dlgAllocate('${e.id}')">Allocate</button>
//             <button class="btn btn-ghost btn-xs" onclick="dlgEditEmp('${e.id}')">Edit</button>
//           </div>
//         </div>
//       </div>`;
//     }).join('')}`;
//   },600);
// }

// // ════════════════════════════════════════════════════════
// // REPORTS PAGE
// // ════════════════════════════════════════════════════════
// function pageReports(){return`
// <div class="page-hdr"><div class="page-hdr-left"><h1>Reports</h1><p>Interactive analytics across your workforce</p></div><button class="btn btn-ghost btn-sm" onclick="expReport()">⬇ Export</button></div>
// <div class="tab-strip">
//   <button class="tab-btn active" onclick="switchRTab(this,'r-util')">📊 Utilization</button>
//   <button class="tab-btn" onclick="switchRTab(this,'r-skills')">🔧 Skills</button>
//   <button class="tab-btn" onclick="switchRTab(this,'r-projs')">🎯 Projects</button>
//   <button class="tab-btn" onclick="switchRTab(this,'r-bands')">🏅 Bands</button>
//   <button class="tab-btn" onclick="switchRTab(this,'r-forecast')">📅 Forecast</button>
// </div>
// <div id="r-util">
//   <div class="grid-2" style="margin-bottom:17px">
//     <div class="card"><div class="card-hdr"><span class="card-title">Utilization by Employee</span></div><div class="chart-box" style="height:270px"><canvas id="rc-ue"></canvas></div></div>
//     <div class="card"><div class="card-hdr"><span class="card-title">Department Avg</span></div><div class="chart-box" style="height:270px"><canvas id="rc-ud"></canvas></div></div>
//   </div>
//   <div class="card"><div class="card-hdr"><span class="card-title">Full Utilization Detail</span></div><div class="tbl-wrap" id="r-util-tbl"></div></div>
// </div>
// <div id="r-skills" style="display:none"><div class="grid-2"><div class="card"><div class="card-hdr"><span class="card-title">Skill Distribution</span></div><div class="chart-box" style="height:270px"><canvas id="rc-sb"></canvas></div></div><div class="card"><div class="card-hdr"><span class="card-title">Coverage</span></div><div class="chart-box" style="height:270px"><canvas id="rc-sp"></canvas></div></div></div></div>
// <div id="r-projs" style="display:none"><div class="card" style="margin-bottom:17px"><div class="card-hdr"><span class="card-title">Headcount per Project</span></div><div class="chart-box" style="height:270px"><canvas id="rc-pb"></canvas></div></div><div class="card"><div class="card-hdr"><span class="card-title">Project Details</span></div><div class="tbl-wrap" id="r-proj-tbl"></div></div></div>
// <div id="r-bands" style="display:none"><div class="grid-2"><div class="card"><div class="card-hdr"><span class="card-title">Band Distribution</span></div><div class="chart-box" style="height:270px"><canvas id="rc-bd"></canvas></div></div><div class="card"><div class="card-hdr"><span class="card-title">Band Utilization</span></div><div class="tbl-wrap" id="r-band-tbl"></div></div></div></div>
// <div id="r-forecast" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Allocations Ending in Next 60 Days</span></div><div class="tbl-wrap" id="r-fc-tbl"></div></div></div>`}

// function switchRTab(btn,tabId){
//   document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
//   ['r-util','r-skills','r-projs','r-bands','r-forecast'].forEach(id=>{const el=document.getElementById(id);if(el)el.style.display='none';});
//   document.getElementById(tabId).style.display='block';
// }

// function initReports(dept){
//   const emps=DB.getEmployees(dept);const allocs=DB.getAllocations(dept);
//   const top12=emps.map(e=>({n:e.name.split(' ')[0],u:DB.empUtil(e.id)})).sort((a,b)=>b.u-a.u).slice(0,12);
//   const ctx1=document.getElementById('rc-ue')?.getContext('2d');
//   if(ctx1)new Chart(ctx1,{type:'bar',data:{labels:top12.map(e=>e.n),datasets:[{data:top12.map(e=>e.u),backgroundColor:top12.map(e=>e.u>=90?'#ff4466':e.u>=70?'#f0a500':'#00c8b4'),borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070'},grid:{color:'rgba(0,200,180,.04)'},max:100},y:{ticks:{color:'#7fa0b0'},grid:{color:'rgba(0,200,180,.04)'}}}}});
//   const depts=DB.getDepts();const actDepts=depts.filter(d=>DB.getEmployees(d).length>0);
//   const dUtils=actDepts.map(d=>{const de=DB.getEmployees(d);return de.length?Math.round(de.reduce((s,e)=>s+DB.empUtil(e.id),0)/de.length):0;});
//   const ctx2=document.getElementById('rc-ud')?.getContext('2d');
//   if(ctx2)new Chart(ctx2,{type:'radar',data:{labels:actDepts.slice(0,8),datasets:[{label:'Avg %',data:dUtils.slice(0,8),backgroundColor:'rgba(0,200,180,.1)',borderColor:'var(--teal)',borderWidth:2,pointBackgroundColor:'var(--teal)',pointRadius:3}]},options:{responsive:true,maintainAspectRatio:false,scales:{r:{ticks:{color:'#4a6070',stepSize:20},grid:{color:'rgba(0,200,180,.08)'},pointLabels:{color:'#7fa0b0'},min:0,max:100}},plugins:{legend:{display:false}}}});
//   const utEl=document.getElementById('r-util-tbl');
//   if(utEl)utEl.innerHTML=`<table><thead><tr><th>Employee</th><th>Band</th><th>Dept</th><th>Exp</th><th>Utilization</th><th>Available</th><th>Projects</th><th>Status</th></tr></thead><tbody>${emps.map(e=>{const u=DB.empUtil(e.id);const empB=BAND.normalize(e.designation||e.band||'');const cnt=DB.empAllocs(e.id).length;const endS=DB.empAllocs(e.id).some(a=>AI.endingWithinDays(a,30));return`<tr><td><strong>${e.name}</strong></td><td>${empB?BAND.renderBand(empB):'—'}</td><td>${e.department||'—'}</td><td style="font-family:var(--mono)">${e.experienceYears||'?'}</td><td style="min-width:130px">${progBar(u)}</td><td>${availBadge(100-u)}</td><td>${cnt}</td><td>${endS?'<span class="badge b-cyan">Ending 30d</span>':u===0?'<span class="badge b-green">Free</span>':u<=50?'<span class="badge b-teal">Partial</span>':'<span class="badge b-amber">Busy</span>'}</td></tr>`;}).join('')}</tbody></table>`;
//   const skC={};emps.forEach(e=>String(e.skills||'').split(/[,;|]/).map(s=>s.trim().toLowerCase()).filter(s=>s.length>1).forEach(s=>{skC[s]=(skC[s]||0)+1;}));
//   const topSk=Object.entries(skC).sort((a,b)=>b[1]-a[1]).slice(0,10);
//   const ctx3=document.getElementById('rc-sb')?.getContext('2d');if(ctx3)new Chart(ctx3,{type:'bar',data:{labels:topSk.map(s=>s[0]),datasets:[{data:topSk.map(s=>s[1]),backgroundColor:'#00c8b4',borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070'},grid:{color:'rgba(0,200,180,.04)'}},y:{ticks:{color:'#4a6070',stepSize:1},grid:{color:'rgba(0,200,180,.04)'},beginAtZero:true}}}});
//   const ctx4=document.getElementById('rc-sp')?.getContext('2d');if(ctx4)new Chart(ctx4,{type:'doughnut',data:{labels:topSk.slice(0,6).map(s=>s[0]),datasets:[{data:topSk.slice(0,6).map(s=>s[1]),backgroundColor:['#00c8b4','#3d8bff','#22d46a','#f0a500','#ff4466','#a55eea'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{color:'#7fa0b0',boxWidth:10,padding:8,font:{size:11}}}}}});
//   const projM={};allocs.forEach(a=>{projM[a.projectName]=(projM[a.projectName]||0)+1;});
//   const pE=Object.entries(projM).sort((a,b)=>b[1]-a[1]);
//   const ctx5=document.getElementById('rc-pb')?.getContext('2d');if(ctx5)new Chart(ctx5,{type:'bar',data:{labels:pE.map(p=>p[0]),datasets:[{label:'Employees',data:pE.map(p=>p[1]),backgroundColor:'#3d8bff',borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070'},grid:{color:'rgba(0,200,180,.04)'}},y:{ticks:{color:'#4a6070',stepSize:1},grid:{color:'rgba(0,200,180,.04)'},beginAtZero:true}}}});
//   const ptEl=document.getElementById('r-proj-tbl');if(ptEl)ptEl.innerHTML=`<table><thead><tr><th>Project</th><th>Employees</th><th>Type</th><th>Total Alloc</th></tr></thead><tbody>${pE.map(([n,c])=>{const total=allocs.filter(a=>a.projectName===n).reduce((s,a)=>s+(parseFloat(a.percentage)||0),0);const internal=AI.isInternal(n)||allocs.find(a=>a.projectName===n)?.isInternal;return`<tr><td><strong>${n}</strong></td><td>${c}</td><td>${internal?'<span class="badge b-purple">Internal</span>':'<span class="badge b-teal">Client</span>'}</td><td>${total}%</td></tr>`;}).join('')}</tbody></table>`;
//   const bandC={};emps.forEach(e=>{const b=BAND.normalize(e.designation||e.band||'')||'Unknown';bandC[b]=(bandC[b]||0)+1;});
//   const bandE=Object.entries(bandC);
//   const ctx6=document.getElementById('rc-bd')?.getContext('2d');if(ctx6)new Chart(ctx6,{type:'doughnut',data:{labels:bandE.map(b=>b[0]),datasets:[{data:bandE.map(b=>b[1]),backgroundColor:['#22d46a','#00c8b4','#06c8e8','#3d8bff','#a55eea','#f0a500','#ff4466','#ffbe2e','#ff7043','#00d2d3','#4ecdc4','#c7f464'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{color:'#7fa0b0',boxWidth:10,padding:8,font:{size:11}}}}}});
//   const btEl=document.getElementById('r-band-tbl');if(btEl)btEl.innerHTML=`<table><thead><tr><th>Band</th><th>Count</th><th>Avg Util</th><th>Avg Avail</th></tr></thead><tbody>${BAND.ORDER.filter(b=>bandC[b]).map(b=>{const be=emps.filter(e=>BAND.normalize(e.designation||e.band||'')===b);const avgU=be.length?Math.round(be.reduce((s,e)=>s+DB.empUtil(e.id),0)/be.length):0;return`<tr><td>${BAND.renderBand(b)}</td><td>${bandC[b]||0}</td><td>${utilBadge(avgU)}</td><td>${availBadge(100-avgU)}</td></tr>`;}).join('')}</tbody></table>`;
//   const fcEl=document.getElementById('r-fc-tbl');
//   if(fcEl){
//     const ending60=[];
//     allocs.forEach(a=>{if(AI.endingWithinDays(a,60)){const emp=DB.getEmployees().find(e=>e.id===a.employeeId);if(emp)ending60.push({...a,emp});}});
//     if(!ending60.length){fcEl.innerHTML=`<div class="empty"><div class="empty-ico">📅</div><div class="empty-msg">No allocations ending in the next 60 days</div></div>`;}
//     else fcEl.innerHTML=`<table><thead><tr><th>Employee</th><th>Band</th><th>Project</th><th>End Date</th><th>Days Left</th><th>Current Util</th></tr></thead><tbody>${ending60.sort((a,b)=>new Date(a.endDate)-new Date(b.endDate)).map(a=>{const daysLeft=Math.ceil((new Date(a.endDate)-new Date())/(1000*60*60*24));const empB=BAND.normalize(a.emp.designation||a.emp.band||'');return`<tr><td><strong>${a.emp.name}</strong></td><td>${empB?BAND.renderBand(empB):'—'}</td><td>${a.projectName}</td><td style="font-family:var(--mono)">${a.endDate}</td><td><span class="badge ${daysLeft<=14?'b-red':daysLeft<=30?'b-amber':'b-cyan'}">${daysLeft}d</span></td><td>${utilBadge(DB.empUtil(a.emp.id))}</td></tr>`;}).join('')}</tbody></table>`;
//   }
// }

// function expReport(){
//   if(!window.XLSX)return toast('XLSX unavailable','err');
//   const emps=DB.getEmployees(sc());if(!emps.length)return toast('No data','warn');
//   const rows=emps.map(e=>({Name:e.name,Email:e.email,Dept:e.department,Designation:e.designation,Band:BAND.normalize(e.designation||e.band||''),Exp:e.experienceYears,Loc:e.location,Skills:e.skills,Util:DB.empUtil(e.id)+'%',Avail:(100-DB.empUtil(e.id))+'%',Projects:DB.empAllocs(e.id).map(a=>a.projectName).join(', ')}));
//   const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Report');XLSX.writeFile(wb,'ResourceAI_Report.xlsx');toast('Exported!','ok');
// }

// // ════════════════════════════════════════════════════════
// // DATA IMPORT PAGE — handled by importer.js
// // All functions: pageUpload, runImport, processFile, resetUp,
// //   dzO, dzL, dzD, fileSel, updateUpBar, showExcelViewer
// //   _importRequirements, _importReqRows
// // ════════════════════════════════════════════════════════

// // ════════════════════════════════════════════════════════
// // ADMIN CENTER
// // ════════════════════════════════════════════════════════
// function pageAdmin(){
//   if(CU.role!=='admin')return`<div class="empty"><div class="empty-ico">🔒</div><div class="empty-msg">Admin only</div></div>`;
//   return`<div class="page-hdr"><div class="page-hdr-left"><h1>Admin Center</h1><p>Manage users, departments, approvals and system settings</p></div></div>
//   <div class="tab-strip">
//     <button class="tab-btn active" onclick="switchATab(this,'a-pend')">⏳ Pending</button>
//     <button class="tab-btn" onclick="switchATab(this,'a-users')">👥 Users</button>
//     <button class="tab-btn" onclick="switchATab(this,'a-depts')">🏢 Departments</button>
//     <button class="tab-btn" onclick="switchATab(this,'a-emails')">📬 Email Log</button>
//     <button class="tab-btn" onclick="switchATab(this,'a-data')">🗄️ Data</button>
//   </div>
//   <div id="a-pend"><div class="card" id="pend-content"></div></div>
//   <div id="a-users" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">All Users</span><button class="btn btn-teal btn-sm" onclick="dlgAddUser()">+ Add User</button></div><div class="tbl-wrap" id="users-tbl"></div></div></div>
//   <div id="a-depts" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Departments</span></div><div style="display:flex;gap:9px;margin-bottom:14px"><input id="new-d" class="form-input" style="max-width:230px" placeholder="Department name"/><button class="btn btn-teal" onclick="addDeptAdmin()">Add</button></div><div id="depts-list"></div></div></div>
//   <div id="a-emails" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Email Log</span><span style="font-size:.75rem;color:var(--text3)">(Connect SMTP for real delivery)</span></div><div class="tbl-wrap" id="emails-tbl"></div></div></div>
//   <div id="a-data" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Data Management</span></div><div id="data-content"></div></div></div>`;
// }

// function switchATab(btn,tabId){
//   document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
//   ['a-pend','a-users','a-depts','a-emails','a-data'].forEach(id=>{const el=document.getElementById(id);if(el)el.style.display='none';});
//   document.getElementById(tabId).style.display='block';
// }

// function initAdmin(){
//   if(CU.role!=='admin')return;
//   // patch users table with password status if password module loaded
//   setTimeout(()=>{ if(typeof _patchUsersTable==='function') _patchUsersTable(); },80);
//   const pending=DB.getPending();const pEl=document.getElementById('pend-content');
//   if(pEl){if(!pending.length){pEl.innerHTML=`<div class="empty"><div class="empty-ico">✅</div><div class="empty-msg">No pending requests</div></div>`;}
//   else pEl.innerHTML=`<div class="card-hdr"><span class="card-title">Pending Approvals (${pending.length})</span></div><div class="tbl-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Dept</th><th>Reason</th><th>Requested</th><th>Actions</th></tr></thead><tbody>${pending.map(r=>`<tr><td><strong>${r.name}</strong></td><td>${r.email}</td><td><span class="badge b-blue">${r.department}</span></td><td style="font-size:.78rem;color:var(--text3)">${r.reason||'—'}</td><td style="font-size:.76rem;color:var(--text3)">${new Date(r.at).toLocaleString()}</td><td><div style="display:flex;gap:5px"><button class="btn btn-green btn-xs" onclick="approvePend('${r.id}')">✓ Approve</button><button class="btn btn-red btn-xs" onclick="rejectPend('${r.id}')">✕ Reject</button></div></td></tr>`).join('')}</tbody></table></div>`;}
//   const uEl=document.getElementById('users-tbl');
//   if(uEl){const users=DB.getUsers();uEl.innerHTML=`<table><thead><tr><th>Name</th><th>Email</th><th>Dept</th><th>Role</th><th>Actions</th></tr></thead><tbody>${users.map(u=>`<tr><td><strong>${u.name}</strong></td><td>${u.email}</td><td>${u.department}</td><td><span class="badge ${u.role==='admin'?'b-amber':'b-teal'}">${u.role}</span></td><td>${u.id!==CU.id?`<button class="btn btn-red btn-xs" onclick="delUser('${u.id}')">Remove</button>`:'<span class="badge b-gray">You</span>'}</td></tr>`).join('')}</tbody></table>`;}
//   const dEl=document.getElementById('depts-list');
//   if(dEl)dEl.innerHTML=`<div style="display:flex;flex-wrap:wrap;gap:8px">${DB.getDepts().map(d=>`<div style="display:flex;align-items:center;gap:6px;background:var(--bg3);padding:7px 12px;border-radius:var(--r-sm)"><span style="font-size:.84rem">${d}</span><button class="btn btn-xs btn-red" onclick="rmDept('${d}')">✕</button></div>`).join('')}</div>`;
//   const eEl=document.getElementById('emails-tbl');
//   if(eEl){const logs=DB.getEmailLog();if(!logs.length){eEl.innerHTML=`<div class="empty"><div class="empty-ico">📬</div><div class="empty-msg">No emails logged</div></div>`;}else eEl.innerHTML=`<table><thead><tr><th>To</th><th>Subject</th><th>Sent At</th></tr></thead><tbody>${logs.map(l=>`<tr><td>${l.to}</td><td>${l.subject}</td><td style="font-size:.76rem;color:var(--text3)">${new Date(l.at).toLocaleString()}</td></tr>`).join('')}</tbody></table>`;}
//   const dCEl=document.getElementById('data-content');
//   if(dCEl)dCEl.innerHTML=`${[['Employees',DB.getEmployees().length,'emps'],['Allocations',DB.getAllocations().length,'allocs'],['Requirements',DB.getRequirements().length,'reqs'],['Projects',DB.getProjects().length,'projs']].map(([lbl,cnt,key])=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:13px;background:var(--bg3);border-radius:var(--r-sm);margin-bottom:9px"><div><strong>${lbl}</strong> <span style="color:var(--text3);font-size:.83rem">${cnt} records</span></div><button class="btn btn-red btn-sm" onclick="clrData('${key}')">Clear</button></div>`).join('')}<div style="padding-top:11px;border-top:1px solid var(--border)"><button class="btn btn-red" onclick="factoryReset()">🔥 Factory Reset</button></div>`;
// }

// function approvePend(id){const u=DB.approvePending(id);if(u){Notify.onApprove(u);buildSidebar();initAdmin();toast(`${u.name} approved!`,'ok');}}
// function rejectPend(id){const r=DB.getPending().find(x=>x.id===id);if(!confirm(`Reject ${r?.name}?`))return;Notify.onReject(r);DB.rejectPending(id);initAdmin();toast('Rejected','info');}
// function delUser(id){if(!confirm('Delete user?'))return;DB.deleteUser(id);initAdmin();toast('Deleted','info');}
// function addDeptAdmin(){const n=document.getElementById('new-d')?.value.trim();if(!n)return;DB.addDept(n);document.getElementById('new-d').value='';initAdmin();toast(`"${n}" added`,'ok');}
// function rmDept(n){if(!confirm(`Remove "${n}"?`))return;DB.removeDept(n);initAdmin();toast('Removed','info');}
// function clrData(type){if(!confirm(`Clear all ${type}?`))return;const m={emps:()=>DB.clearEmployees(null),allocs:()=>DB.clearAllocs(null),reqs:()=>DB._s('requirements',[]),projs:()=>DB._s('projects',[])};m[type]?.();initAdmin();toast('Cleared','info');}
// function factoryReset(){if(!confirm('FACTORY RESET — delete ALL data?'))return;if(!confirm('Are you absolutely sure?'))return;localStorage.clear();DB.init();doLogout();toast('Reset done','info');}

// function dlgAddUser(){
//   openDlg(`<div class="dlg-title">Add User</div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Name</label><input id="au-n" class="form-input" placeholder="Full name"/></div><div class="form-group"><label class="form-label">Email</label><input id="au-e" type="email" class="form-input"/></div></div>
//   <div class="form-row"><div class="form-group"><label class="form-label">Department</label><select id="au-d" class="form-select">${DB.getDepts().map(d=>`<option>${d}</option>`).join('')}</select></div><div class="form-group"><label class="form-label">Role</label><select id="au-r" class="form-select"><option value="user">User</option><option value="admin">Admin</option></select></div></div>
//   <div class="form-group"><label class="form-label">Password (min 8)</label><input id="au-p" type="password" class="form-input"/></div>
//   <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
//     <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
//     <button class="btn btn-teal" onclick="saveAddUser()">Create</button>
//   </div>`);
// }

// function saveAddUser(){
//   const n=document.getElementById('au-n').value.trim();const e=document.getElementById('au-e').value.trim();const p=document.getElementById('au-p').value;
//   if(!n||!e||!p)return toast('Fill all fields','err');if(p.length<8)return toast('Min 8 chars','err');if(DB.getByEmail(e))return toast('Email exists','err');
//   DB.addUser({name:n,email:e,passHash:SEC.hash(p),role:document.getElementById('au-r').value,department:document.getElementById('au-d').value,approved:true});
//   closeDlg();initAdmin();toast('User created','ok');
// }

// // ════════════════════════════════════════════════════════
// // LANDING PARTICLES & LIVE METRICS
// // ════════════════════════════════════════════════════════
// function initParticles(){
//   const c=document.getElementById('particles');if(!c)return;
//   for(let i=0;i<22;i++){const p=document.createElement('div');p.className='pt';p.style.cssText=`left:${Math.random()*100}%;top:${Math.random()*100}%;--d:${6+Math.random()*8}s;--dl:${Math.random()*8}s;width:${1+Math.random()*2}px;height:${1+Math.random()*2}px`;c.appendChild(p);}
// }

// function updateLandingMetrics(){
//   function animN(id,t){const el=document.getElementById(id);if(!el)return;let c=0;const s=Math.max(1,Math.ceil(t/25));const ti=setInterval(()=>{c=Math.min(c+s,t);el.textContent=c;if(c>=t)clearInterval(ti);},40);}
//   animN('lm-e',DB.getEmployees().length);
//   animN('lm-p',DB.getProjects().length);
//   animN('lm-r',DB.getRequirements().filter(r=>r.status==='Open').length);
// }

// // ════════════════════════════════════════════════════════
// // BOOTSTRAP — runs on page load
// // ════════════════════════════════════════════════════════
// DB.init();
// initParticles();
// updateLandingMetrics();

// // Restore session if still valid
// const _saved = DB.session();
// if(_saved && _saved.email){
//   const _u = DB.getByEmail(_saved.email);
//   if(_u && _u.approved){ CU=_u; showPage('pg-app'); launchApp(); }
// }


'use strict';
// ═══════════════════════════════════════════════════════
// APP.JS — Interactive view routing & event aggregators
// Depends on: security.js, database.js, colmapper.js,
//             excel.js, ai.js (BAND + AI), config.js
// ═══════════════════════════════════════════════════════

let CU = null; // Current logged-in user

// ── Page switcher ─────────────────────────────────────
function showPage(id){
  document.querySelectorAll('.page').forEach(p=>{p.classList.remove('active');p.style.display='';});
  const el = document.getElementById(id); if(!el) return;
  el.classList.add('active');
  if(id==='pg-app') el.style.display='flex';
  if(id==='pg-register'){
    const sel = document.getElementById('r-dept');
    sel.innerHTML = '<option value="">Select...</option>';
    DB.getDepts().forEach(d => sel.innerHTML += `<option>${d}</option>`);
  }
  updateLandingMetrics();
}

// ════════════════════════════════════════════════════════
// AUTH LOGIC
// ════════════════════════════════════════════════════════
let _loginAttempts=0, _lockUntil=0;

function doLogin(){
  if(Date.now()<_lockUntil) return showAlert('login-alert',`Too many attempts. Try again in ${Math.ceil((_lockUntil-Date.now())/60000)} min.`,'warn');
  const email = document.getElementById('l-email').value.trim();
  const pass  = document.getElementById('l-pass').value;
  if(!email||!pass) return showAlert('login-alert','Please enter email and password.');
  const user = DB.getByEmail(email);
  if(!user||!SEC.verify(pass, user.passHash||user.password||'')){
    _loginAttempts++;
    if(_loginAttempts>=5){_lockUntil=Date.now()+5*60*1000;_loginAttempts=0;}
    return showAlert('login-alert','Incorrect email or password.');
  }
  if(!user.approved) return showAlert('login-alert','Account pending admin approval. Check your email.','warn');
  _loginAttempts=0; CU=user; DB.setSession(user);
  showPage('pg-app'); launchApp();
  toast(`Welcome back, ${user.name.split(' ')[0]}! 👋`,'ok');
}

function doRegister(){
  const name  = document.getElementById('r-name').value.trim();
  const email = document.getElementById('r-email').value.trim();
  const dept  = document.getElementById('r-dept').value;
  const pass  = document.getElementById('r-pass').value;
  const pass2 = document.getElementById('r-pass2').value;
  if(!name||!email||!dept||!pass) return showAlert('reg-alert','Fill all required fields.');
  if(!/\S+@\S+\.\S+/.test(email)) return showAlert('reg-alert','Enter a valid email.');
  if(pass.length<8) return showAlert('reg-alert','Password min 8 characters.');
  if(pass!==pass2) return showAlert('reg-alert','Passwords do not match.');
  if(DB.getByEmail(email)) return showAlert('reg-alert','Account already exists with that email.');
  const reg = DB.addPending({name,email,passHash:SEC.hash(pass),role:'user',department:dept,reason:document.getElementById('r-reason').value.trim()});
  Notify.onRegister(reg);
  showAlert('reg-alert','Request submitted! You will be emailed once approved.','ok');
}

function doLogout(){CU=null;DB.clearSession();showPage('pg-landing');toast('Signed out.','info');}

function sendRecovery(){
  const email = document.getElementById('f-email').value.trim();
  if(!email) return showAlert('forgot-alert','Enter your email.');
  const user = DB.getByEmail(email);
  if(!user) return showAlert('forgot-alert','No account found with that email.');
  const token = SEC.genToken(); DB.setToken(email,token); Notify.onRecovery(email,token);
  showAlert('forgot-alert',`Recovery code sent! Check admin Email Log for: ${email}`,'ok');
  setTimeout(()=>{document.getElementById('forgot-step1').style.display='none';document.getElementById('forgot-step2').style.display='block';},1500);
}

function doResetPass(){
  const email = document.getElementById('f-email').value.trim();
  const token = document.getElementById('f-token').value.trim();
  const np    = document.getElementById('f-newpass').value;
  const np2   = document.getElementById('f-newpass2').value;
  if(!token||!np) return showAlert('forgot-alert','Enter code and new password.');
  if(np!==np2) return showAlert('forgot-alert','Passwords do not match.');
  if(np.length<8) return showAlert('forgot-alert','Password min 8 characters.');
  if(!DB.verifyToken(email,token)) return showAlert('forgot-alert','Invalid or expired code.');
  const user = DB.getByEmail(email); if(!user) return showAlert('forgot-alert','User not found.');
  DB.updateUser(user.id,{passHash:SEC.hash(np)}); DB.clearToken(email);
  showAlert('forgot-alert','Password reset! You can now sign in.','ok');
  setTimeout(()=>showPage('pg-login'),2000);
}

// ════════════════════════════════════════════════════════
// APP LAUNCH & NAVIGATION
// ════════════════════════════════════════════════════════
function launchApp(){
  const ini = CU.name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);
  document.getElementById('tb-avatar').textContent = ini;
  document.getElementById('sb-avatar').textContent = ini;
  document.getElementById('tb-uname').textContent  = CU.name.split(' ')[0];
  document.getElementById('sb-uname').textContent  = CU.name;
  document.getElementById('sb-udept').textContent  = CU.role==='admin'?'⚡ Admin':CU.department;
  document.getElementById('tb-dept').textContent   = CU.role==='admin'?'⚡ Administrator':`🏢 ${CU.department}`;
  document.getElementById('footer-info').textContent = `${CU.name} · ${CU.department} · ${CU.role}`;
  buildSidebar();
  navigateTo('dashboard');
  // Notifications: inject bell after sidebar is built
  if(typeof initNotifications === 'function') initNotifications();
  // Password: force change if using default
  if(typeof _needsForcedChange === 'function' && _needsForcedChange(CU)){
    setTimeout(()=>{ if(typeof dlgForceChangePassword==='function') dlgForceChangePassword(); }, 900);
  }
}

const NAV_ADMIN = [
  {id:'dashboard', icon:'📊', label:'Dashboard',    sec:'Main'},
  {id:'employees', icon:'👥', label:'Employees',    sec:'Main'},
  {id:'allocations',icon:'🎯',label:'Allocations',  sec:'Main'},
  {id:'requirements',icon:'📋',label:'Requirements',sec:'Main'},
  {id:'workforce', icon:'🧠', label:'Workforce AI', sec:'Intelligence'},
  {id:'reports',   icon:'📈', label:'Reports',      sec:'Analytics'},
  {id:'upload',    icon:'📂', label:'Data Import',  sec:'Data'},
  {id:'admin',     icon:'⚙️', label:'Admin Center', sec:'Admin', badge:()=>DB.getPending().length},
];
const NAV_USER = [
  {id:'dashboard', icon:'📊', label:'Dashboard',    sec:'Main'},
  {id:'employees', icon:'👥', label:'SkillSet',     sec:'Main'},
  {id:'allocations',icon:'🎯',label:'Allocations',  sec:'Main'},
  {id:'requirements',icon:'📋',label:'Requirements',sec:'Main'},
  {id:'workforce', icon:'🧠', label:'Workforce AI', sec:'Intelligence'},
  {id:'reports',   icon:'📈', label:'Reports',      sec:'Analytics'},
  {id:'upload',    icon:'📂', label:'Data Import',  sec:'Data'},
];

function buildSidebar(){
  const pages = CU.role==='admin' ? NAV_ADMIN : NAV_USER;
  let html=''; let lastSec='';
  for(const p of pages){
    if(p.sec!==lastSec){html+=`<div class="sb-sec"><div class="sb-sec-label">${p.sec}</div>`;lastSec=p.sec;}
    const b = p.badge ? p.badge() : 0;
    html+=`<button class="sb-item" id="sb-${p.id}" onclick="navigateTo('${p.id}')"><span class="sb-icon">${p.icon}</span>${p.label}${b>0?`<span class="sb-badge">${b}</span>`:''}</button>`;
  }
  html += '</div>';
  document.getElementById('sb-scroll').innerHTML = html;
}

function navigateTo(page){
  // Close mobile sidebar if open
  document.getElementById('sidebar')?.classList.remove('mob-open');
  document.getElementById('sb-overlay')?.classList.remove('visible');
  document.querySelectorAll('.sb-item').forEach(el=>el.classList.remove('active'));
  document.getElementById(`sb-${page}`)?.classList.add('active');
  document.getElementById('tb-page').textContent = page.charAt(0).toUpperCase()+page.slice(1);
  const body = document.getElementById('page-body');
  if(!body){ console.error('page-body element not found'); return; }
  const deptScope = CU.role==='admin' ? null : CU.department;
  try {
    switch(page){
      case 'dashboard':   body.innerHTML=pageDash();      initDash(deptScope);    break;
      case 'employees':   body.innerHTML=pageEmps();      initEmps(deptScope);    break;
      case 'allocations': body.innerHTML=pageAllocs();    initAllocs(deptScope);  break;
      case 'requirements':body.innerHTML=pageReqs();      initReqs();             break;
      case 'workforce':   body.innerHTML=pageWorkforce(); break;
      case 'reports':     body.innerHTML=pageReports();   initReports(deptScope); break;
      case 'upload':      body.innerHTML=pageUpload();    break;
      case 'admin':       body.innerHTML=pageAdmin();     initAdmin();            break;
      default:            body.innerHTML=pageDash();      initDash(deptScope);
    }
  } catch(err) {
    console.error('navigateTo error on page:', page, err);
    body.innerHTML = `<div class="empty"><div class="empty-ico">⚠️</div><div class="empty-msg">Error loading ${page}: ${err.message}</div></div>`;
  }
}

// Shorthand helpers
function sc(){ return CU.role==='admin' ? null : CU.department; }
function uDept(){ return CU.department; }

// ════════════════════════════════════════════════════════
// UI HELPERS
// ════════════════════════════════════════════════════════
function toast(msg, type='info', dur=3500){
  const w = document.getElementById('toasts');
  const t = document.createElement('div');
  const icons = {ok:'✅',err:'❌',info:'ℹ️',warn:'⚠️'};
  t.className = `toast t-${type}`;
  t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${msg}</span>`;
  w.appendChild(t);
  setTimeout(()=>{t.classList.add('hiding');setTimeout(()=>t.remove(),300);}, dur);
}
function showAlert(id, msg, type='err'){
  const el = document.getElementById(id); if(!el) return;
  el.innerHTML = `<div class="alert a-${type}">${msg}</div>`;
  setTimeout(()=>{if(el)el.innerHTML='';}, 5500);
}
function openDlg(html){
  closeDlg();
  const ov = document.createElement('div');
  ov.className='dlg-overlay'; ov.id='dlg-active';
  ov.innerHTML = `<div class="dlg">${html}<button class="dlg-close" onclick="closeDlg()">✕</button></div>`;
  ov.addEventListener('click', e=>{if(e.target===ov)closeDlg();});
  document.getElementById('dlg-root').appendChild(ov);
}
function closeDlg(){const el=document.getElementById('dlg-active');if(el)el.remove();}
function addDynField(id){
  const w=document.getElementById(id);const r=document.createElement('div');r.className='dyn-row';
  r.innerHTML=`<input class="form-input ek" placeholder="Field name" style="max-width:130px"/><input class="form-input ev" placeholder="Value"/><button class="btn btn-xs btn-red" onclick="this.parentElement.remove()" style="flex-shrink:0">✕</button>`;
  w.appendChild(r);
}
function getDynFields(id){
  const out={};
  document.querySelectorAll(`#${id} .dyn-row`).forEach(r=>{
    const k=r.querySelector('.ek')?.value.trim(); const v=r.querySelector('.ev')?.value.trim();
    if(k&&v) out['_extra_'+k]=v;
  });
  return out;
}
function skillChips(skills, max=5){
  if(!skills) return '—';
  // Filter OUT aspiring skills — they are shown separately as purple chips
  const arr = String(skills).split(/[,;|]/).map(s=>s.trim())
    .filter(s=>s && !s.toLowerCase().includes('(aspiring)'));
  if(!arr.length) return '—';
  const shown = arr.slice(0,max); const extra = arr.length-shown.length;
  return shown.map(s=>`<span class="chip">${s}</span>`).join('') + (extra>0?`<span class="chip">+${extra}</span>`:'');
}
function utilBadge(u){const c=u>=90?'b-red':u>=70?'b-amber':'b-green';return`<span class="badge ${c}">${u}%</span>`}
function availBadge(a){const c=a>=100?'b-green':a>=50?'b-teal':a>=20?'b-amber':'b-red';return`<span class="badge ${c}">${a}% free</span>`}
function progBar(v){const p=Math.min(100,v);const c=p>=90?'pf-err':p>=70?'pf-warn':p>=40?'pf-half':'pf-ok';return`<div class="prog-wrap"><div class="prog-bar"><div class="prog-fill ${c}" style="width:${p}%"></div></div><span class="prog-pct">${v}%</span></div>`}
function formatExtra(obj){return Object.entries(obj).filter(([k])=>k.startsWith('_extra_')).map(([k,v])=>`<span class="chip chip-teal">${k.replace('_extra_','')}: ${v}</span>`).join('')}
function togglePass(id,btn){const el=document.getElementById(id);if(!el)return;const show=el.type==='password';el.type=show?'text':'password';btn.textContent=show?'🙈':'👁';}
function checkStrength(p){
  const bar=document.getElementById('ps-bar');const lbl=document.getElementById('ps-label');if(!bar)return;
  let score=0;if(p.length>=8)score++;if(/[A-Z]/.test(p))score++;if(/[0-9]/.test(p))score++;if(/[^A-Za-z0-9]/.test(p))score++;if(p.length>=12)score++;
  const pcts=[0,25,50,75,100];const cols=['var(--red)','var(--red)','var(--amber)','var(--amber2)','var(--green)'];const labels=['','Weak','Fair','Good','Strong'];
  bar.style.width=pcts[score]+'%';bar.style.background=cols[score];if(lbl){lbl.textContent=labels[score];lbl.style.color=cols[score];}
}
function toggleUMenu(){document.getElementById('user-dd').classList.toggle('open');}
document.addEventListener('click',e=>{if(!e.target.closest('.user-menu'))document.getElementById('user-dd')?.classList.remove('open');});

// ════════════════════════════════════════════════════════
// DASHBOARD
// ════════════════════════════════════════════════════════
function pageDash(){return`
<div class="page-hdr">
  <div class="page-hdr-left"><h1>Dashboard</h1><p>Live workforce allocation overview</p></div>
  <div class="page-hdr-actions">
    <button class="btn btn-ghost btn-sm" onclick="navigateTo('upload')">📂 Import</button>
    <button class="btn btn-teal btn-sm" onclick="navigateTo('workforce')">🧠 AI Search</button>
  </div>
</div>
<div class="stat-grid" id="d-stats"></div>
<div class="grid-2" style="margin-bottom:17px">
  <div class="card"><div class="card-hdr"><span class="card-title">Utilization Distribution</span></div><div class="chart-box"><canvas id="ch-util"></canvas></div></div>
  <div class="card"><div class="card-hdr"><span class="card-title">Top Skills</span></div><div class="chart-box"><canvas id="ch-sk"></canvas></div></div>
</div>
<div class="grid-2">
  <div class="card"><div class="card-hdr"><span class="card-title">Recent Allocations</span><button class="btn btn-xs btn-outline" onclick="navigateTo('allocations')">All →</button></div><div id="d-allocs"></div></div>
  <div class="card"><div class="card-hdr"><span class="card-title">Open Requirements</span><button class="btn btn-xs btn-outline" onclick="navigateTo('requirements')">All →</button></div><div id="d-reqs"></div></div>
</div>`}

function initDash(dept){
  const emps=DB.getEmployees(dept);const allocs=DB.getAllocations(dept);
  const projs=DB.getProjects(dept);const reqs=DB.getRequirements(dept);
  const openR=reqs.filter(r=>r.status==='Open').length;
  const avgU=emps.length?Math.round(emps.reduce((s,e)=>s+DB.empUtil(e.id),0)/emps.length):0;
  const free=emps.filter(e=>DB.empUtil(e.id)===0).length;
  const endingSoon=emps.filter(e=>DB.empAllocs(e.id).some(a=>AI.endingWithinDays(a,30))).length;

  document.getElementById('d-stats').innerHTML=`
    <div class="stat-card"><div class="stat-card-icon">👥</div><div class="stat-label">Employees</div><div class="stat-val">${emps.length}</div><div class="stat-meta ok">${free} fully free</div><div class="stat-bar"><div class="stat-bar-fill" style="width:100%;background:var(--teal)"></div></div></div>
    <div class="stat-card"><div class="stat-card-icon">🎯</div><div class="stat-label">Active Projects</div><div class="stat-val">${projs.length}</div><div class="stat-meta">${allocs.length} allocations</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${Math.min(100,projs.length*8)}%;background:var(--blue)"></div></div></div>
    <div class="stat-card"><div class="stat-card-icon">⚡</div><div class="stat-label">Avg Utilization</div><div class="stat-val">${avgU}<small style="font-size:.9rem">%</small></div><div class="stat-meta ${avgU>85?'err':avgU>70?'warn':'ok'}">${avgU>85?'⚠ Overloaded':avgU>70?'◉ Moderate':'✓ Healthy'}</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${avgU}%;background:${avgU>85?'var(--red)':avgU>70?'var(--amber)':'var(--teal)'}"></div></div></div>
    <div class="stat-card"><div class="stat-card-icon">📋</div><div class="stat-label">Open Requirements</div><div class="stat-val">${openR}</div><div class="stat-meta warn">${reqs.length} total</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${reqs.length?openR/reqs.length*100:0}%;background:var(--amber)"></div></div></div>
    <div class="stat-card"><div class="stat-card-icon">📅</div><div class="stat-label">Ending in 30d</div><div class="stat-val">${endingSoon}</div><div class="stat-meta ${endingSoon>0?'warn':'ok'}">${endingSoon>0?'⚠ Plan replacements':'✓ Stable'}</div><div class="stat-bar"><div class="stat-bar-fill" style="width:${emps.length?endingSoon/emps.length*100:0}%;background:var(--cyan)"></div></div></div>`;

  const buckets={'Free':0,'≤25%':0,'26–50%':0,'51–75%':0,'76–99%':0,'100%':0};
  emps.forEach(e=>{const u=DB.empUtil(e.id);if(u===0)buckets['Free']++;else if(u<=25)buckets['≤25%']++;else if(u<=50)buckets['26–50%']++;else if(u<=75)buckets['51–75%']++;else if(u<100)buckets['76–99%']++;else buckets['100%']++;});
  const ctx1=document.getElementById('ch-util')?.getContext('2d');
  if(ctx1)new Chart(ctx1,{type:'bar',data:{labels:Object.keys(buckets),datasets:[{data:Object.values(buckets),backgroundColor:['#22d46a','#00c8b4','#3d8bff','#f0a500','#ff7043','#ff4466'],borderRadius:5,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070',font:{size:11}},grid:{color:'rgba(0,200,180,.04)'}},y:{ticks:{color:'#4a6070',stepSize:1},grid:{color:'rgba(0,200,180,.04)'},beginAtZero:true}}}});

  const skCount={};emps.forEach(e=>String(e.skills||'').split(/[,;|]/).map(s=>s.trim().toLowerCase()).filter(s=>s.length>1).forEach(s=>{skCount[s]=(skCount[s]||0)+1;}));
  const topSk=Object.entries(skCount).sort((a,b)=>b[1]-a[1]).slice(0,7);
  const ctx2=document.getElementById('ch-sk')?.getContext('2d');
  if(ctx2)new Chart(ctx2,{type:'doughnut',data:{labels:topSk.map(s=>s[0]),datasets:[{data:topSk.map(s=>s[1]),backgroundColor:['#00c8b4','#3d8bff','#22d46a','#f0a500','#ff4466','#a55eea','#06c8e8'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{color:'#7fa0b0',boxWidth:10,padding:9,font:{size:11}}}}}});

  const recentA=[...allocs].sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)).slice(0,5);
  const dA=document.getElementById('d-allocs');
  if(!recentA.length){dA.innerHTML=`<div class="empty"><div class="empty-ico">🎯</div><div class="empty-msg">No allocations yet</div></div>`;}
  else dA.innerHTML=`<div class="tbl-wrap"><table><thead><tr><th>Employee</th><th>Project</th><th>%</th></tr></thead><tbody>${recentA.map(a=>{const emp=DB.getEmployees().find(e=>e.id===a.employeeId);return`<tr><td><strong>${emp?.name||'?'}</strong></td><td>${a.projectName}</td><td>${utilBadge(a.percentage)}</td></tr>`;}).join('')}</tbody></table></div>`;

  const openRqs=reqs.filter(r=>r.status==='Open').slice(0,5);
  const dR=document.getElementById('d-reqs');
  if(!openRqs.length){dR.innerHTML=`<div class="empty"><div class="empty-ico">📋</div><div class="empty-msg">No open requirements</div></div>`;}
  else dR.innerHTML=`<div class="tbl-wrap"><table><thead><tr><th>Role</th><th>Band</th><th>Priority</th></tr></thead><tbody>${openRqs.map(r=>`<tr><td><strong>${r.role||'—'}</strong></td><td>${BAND.renderBand(BAND.normalize(r.designation||r.band||''))}</td><td><span class="badge ${r.priority==='High'?'b-red':r.priority==='Medium'?'b-amber':'b-blue'}">${r.priority||'Normal'}</span></td></tr>`).join('')}</tbody></table></div>`;
}

// ════════════════════════════════════════════════════════
// EMPLOYEES PAGE
// ════════════════════════════════════════════════════════
function pageEmps(){return`
<div class="page-hdr">
  <div class="page-hdr-left"><h1>${CU.role==='admin'?'All Employees':'SkillSet'}</h1><p>Manage profiles, designations, skills and allocation status</p></div>
  <div class="page-hdr-actions">
    <button class="btn btn-ghost btn-sm" onclick="exportEmps()">⬇ Export</button>
    <button class="btn btn-teal btn-sm" onclick="dlgAddEmp()">+ Add Employee</button>
  </div>
</div>
<div class="filter-row">
  <input type="text" id="f-es" class="fi-text" style="min-width:210px" placeholder="🔍 Search name, skills, band..."/>
  <select id="f-ed" class="fi" onchange="renderEmps()">${CU.role==='admin'?'<option value="">All Departments</option>'+DB.getDepts().map(d=>`<option>${d}</option>`).join(''):`<option>${CU.department}</option>`}</select>
  <select id="f-eb" class="fi" onchange="renderEmps()"><option value="">All Bands</option>${BAND.ORDER.map(b=>`<option>${b}</option>`).join('')}</select>
  <select id="f-ea" class="fi" onchange="renderEmps()"><option value="">Any Availability</option><option value="free">100% Free</option><option value="partial">≤50% Allocated</option><option value="ending">Ending in 30d</option><option value="internal">Internal Only</option><option value="busy">Busy (&gt;50%)</option></select>
  <select id="f-el" class="fi" onchange="renderEmps()"><option value="">All Locations</option></select>
</div>
<div class="card">
  <div class="card-hdr"><span class="card-title" id="emp-cnt">Loading...</span></div>
  <div class="tbl-wrap"><table>
    <thead><tr><th>Employee</th><th>Emp ID</th><th>Cert</th><th>Department</th><th>Designation/Band</th><th>Skills</th><th>Experience</th><th>Location</th><th>Utilization</th><th>Available</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody id="emp-tbody"></tbody>
  </table></div>
</div>`}

function initEmps(dept){
  const emps=DB.getEmployees(dept);
  const locs=[...new Set(emps.map(e=>e.location||'').filter(Boolean))];
  const ls=document.getElementById('f-el');locs.forEach(l=>ls.innerHTML+=`<option>${l}</option>`);
  if(CU.role!=='admin'){const ds=document.getElementById('f-ed');if(ds)ds.disabled=true;}
  document.getElementById('f-es').addEventListener('input',renderEmps);
  renderEmps();
}

function renderEmps(){
  const search=(document.getElementById('f-es')?.value||'').toLowerCase();
  const deptF=document.getElementById('f-ed')?.value||'';
  const bandF=document.getElementById('f-eb')?.value||'';
  const availF=document.getElementById('f-ea')?.value||'';
  const locF=document.getElementById('f-el')?.value||'';
  let emps=DB.getEmployees(sc());
  if(deptF)emps=emps.filter(e=>e.department===deptF);
  if(bandF)emps=emps.filter(e=>BAND.normalize(e.designation||e.band||'')===(bandF));
  if(locF)emps=emps.filter(e=>(e.location||'').toLowerCase()===locF.toLowerCase());
  if(search)emps=emps.filter(e=>String(e.name||'').toLowerCase().includes(search)||String(e.skills||'').toLowerCase().includes(search)||String(e.designation||'').toLowerCase().includes(search)||String(e.location||'').toLowerCase().includes(search));
  if(availF){
    emps=emps.filter(e=>{
      const u=DB.empUtil(e.id);const allocs=DB.empAllocs(e.id);
      if(availF==='free')return u===0;
      if(availF==='partial')return u>0&&u<=50;
      if(availF==='ending')return allocs.some(al=>AI.endingWithinDays(al,30));
      if(availF==='internal')return allocs.length>0&&allocs.every(al=>AI.isInternal(al.projectName));
      if(availF==='busy')return u>50;
      return true;
    });
  }
  const lbl=document.getElementById('emp-cnt');if(lbl)lbl.textContent=`${emps.length} employee${emps.length!==1?'s':''} found`;
  const tbody=document.getElementById('emp-tbody');if(!tbody)return;
  if(!emps.length){tbody.innerHTML=`<tr><td colspan="12"><div class="empty"><div class="empty-ico">👥</div><div class="empty-msg">No employees match your filters</div></div></td></tr>`;return;}
  tbody.innerHTML=emps.map(e=>{
    const u=DB.empUtil(e.id);const a=100-u;const empB=BAND.normalize(e.designation||e.band||e.level||'');
    const allocs=DB.empAllocs(e.id);
    const endingSoon=allocs.some(al=>AI.endingWithinDays(al,30));
    const ending60=allocs.some(al=>AI.endingWithinDays(al,60));
    const allInternal=allocs.length>0&&allocs.every(al=>AI.isInternal(al.projectName));
    let statusBadge='';
    if(u===0)statusBadge='<span class="badge b-green">Free</span>';
    else if(u<=50)statusBadge=`<span class="badge b-teal">Partial</span>`;
    else if(endingSoon)statusBadge='<span class="badge b-cyan">Ending 30d</span>';
    else if(ending60)statusBadge='<span class="badge b-blue">Ending 60d</span>';
    else if(allInternal)statusBadge='<span class="badge b-purple">Internal</span>';
    else statusBadge=`<span class="badge b-amber">Busy</span>`;
    // Certified detection — scan isCertified field + ALL _extra_* cert-like columns
    const _certKws=['certified','certification','iscertified','certifiedyn','certifiedornot'];
    const _certVal=(()=>{
      // Check explicit field first
      const ex=String(e.isCertified||e._certified||'').toLowerCase().trim();
      if(ex)return ex;
      // Scan every _extra_ key for cert keywords
      for(const[k,v] of Object.entries(e)){
        if(!k.startsWith('_extra_'))continue;
        const nk=k.replace('_extra_','').toLowerCase().replace(/[^a-z]/g,'');
        if(_certKws.some(kw=>nk.includes(kw)))return String(v||'').toLowerCase().trim();
      }
      return '';
    })();
    const certified=_certVal==='yes'||_certVal==='y'||_certVal==='1'||_certVal==='true'||_certVal==='certified';
    // Aspiring skills — those with (aspiring) suffix in skills field
    const aspiringSkills=AI.getAspiringSkills(e);
    const aspiringHtml=aspiringSkills.length?`<div style="margin-top:3px">${aspiringSkills.slice(0,3).map(s=>`<span class="chip" style="font-size:.61rem;color:var(--purple);border:1px solid rgba(165,94,234,.3);background:rgba(165,94,234,.06)" title="Interested to learn">📚 ${s}</span>`).join('')}${aspiringSkills.length>3?`<span class="chip" style="font-size:.61rem">+${aspiringSkills.length-3}</span>`:''}</div>`:'';
    const empIdHtml=e.employeeId?`<span style="font-family:var(--mono);font-size:.74rem;color:var(--text2)">${e.employeeId}</span>`:`<span style="color:var(--text3);font-size:.72rem">—</span>`;
    const certHtml=certified?`<span class="badge b-green" title="Certified">🏅 Yes</span>`:`<span style="color:var(--text3);font-size:.72rem">No</span>`;
    return`<tr>
      <td><div style="font-weight:700">${e.name}</div>${e.email?`<div style="font-size:.71rem;color:var(--text3)">${e.email}</div>`:''}</td>
      <td>${empIdHtml}</td>
      <td>${certHtml}</td>
      <td><span class="badge b-blue">${e.department||'—'}</span></td>
      <td>${empB?BAND.renderBand(empB):'<span style="color:var(--text3)">—</span>'}<br/><span style="font-size:.71rem;color:var(--text3)">${e.designation||''}</span></td>
      <td style="max-width:200px">${skillChips(e.skills)}${aspiringHtml}</td>
      <td style="font-family:var(--mono);font-size:.82rem">${e.experienceYears?e.experienceYears+' yr':'—'}</td>
      <td>${e.location?`📍 ${e.location}`:'—'}</td>
      <td style="min-width:125px">${progBar(u)}</td>
      <td>${availBadge(a)}</td>
      <td>${statusBadge}</td>
      <td><div style="display:flex;gap:4px;flex-wrap:wrap">
        <button class="btn btn-xs btn-outline" onclick="dlgAllocate('${e.id}')">Allocate</button>
        <button class="btn btn-xs btn-ghost" onclick="dlgEditEmp('${e.id}')">Edit</button>
        <button class="btn btn-xs btn-red" onclick="delEmp('${e.id}')">Del</button>
      </div></td>
    </tr>`;
  }).join('');
}

function exportEmps(){
  if(!window.XLSX){toast('XLSX not available','err');return;}
  const emps=DB.getEmployees(sc());if(!emps.length)return toast('No data','warn');
  const rows=emps.map(e=>({Name:e.name,Email:e.email,Dept:e.department,Designation:e.designation,Band:BAND.normalize(e.designation||e.band||''),Exp:e.experienceYears,Location:e.location,Skills:e.skills,Util:DB.empUtil(e.id)+'%',Avail:(100-DB.empUtil(e.id))+'%'}));
  const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Employees');XLSX.writeFile(wb,'ResourceAI_Employees.xlsx');toast('Exported!','ok');
}

function dlgAddEmp(){
  openDlg(`<div class="dlg-title">Add Employee</div>
  <div class="form-row"><div class="form-group"><label class="form-label">Full Name *</label><input id="de-n" class="form-input" placeholder="John Doe"/></div><div class="form-group"><label class="form-label">Email</label><input id="de-e" type="email" class="form-input" placeholder="john@co.com"/></div></div>
  <div class="form-row"><div class="form-group"><label class="form-label">Employee ID</label><input id="de-id" class="form-input" placeholder="EMP001"/></div><div class="form-group"><label class="form-label">Department *</label><select id="de-d" class="form-select">${DB.getDepts().map(d=>`<option ${d===uDept()?'selected':''}>${d}</option>`).join('')}</select></div></div>
  <div class="form-row">
    <div class="form-group"><label class="form-label">Designation / Band *</label>
      <input id="de-b" class="form-input" placeholder="Click a band below or type..." readonly style="cursor:pointer"/>
      <div class="band-explain" style="margin-top:6px">${BAND.ORDER.map(b=>`<button type="button" class="band-pill ${BAND.getBandClass(b)}" style="cursor:pointer;border:none;font-family:var(--font);font-weight:700;padding:3px 9px;border-radius:4px" onclick="document.getElementById('de-b').value='${b}';this.closest('.band-explain').querySelectorAll('.band-pill').forEach(x=>x.style.outline='none');this.style.outline='2px solid var(--teal)'">${b}</button>`).join('')}</div>
    </div>
    <div class="form-group"><label class="form-label">Experience (years)</label><input id="de-exp" type="number" class="form-input" placeholder="5" min="0"/></div>
  </div>
  <div class="form-group"><label class="form-label">Location</label><input id="de-loc" class="form-input" placeholder="Hyderabad, Bangalore, Remote..."/></div>
  <div class="form-group"><label class="form-label">Primary Skills (comma-separated)</label><textarea id="de-sk" class="form-textarea" placeholder="React, Node.js, Python, AWS..."></textarea></div>
  <div class="form-group"><label class="form-label">Secondary Skills</label><input id="de-sk2" class="form-input" placeholder="Docker, SQL, Git..."/></div>
  <div><label class="form-label">Custom Fields</label><div id="de-ex"></div><button class="btn btn-xs btn-ghost" style="margin-top:5px" onclick="addDynField('de-ex')">+ Field</button></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:16px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveAddEmp()">Save</button>
  </div>`);
}

function saveAddEmp(){
  const name=document.getElementById('de-n').value.trim();const dept=document.getElementById('de-d').value;
  if(!name||!dept)return toast('Name and Department required','err');
  const rawBand=document.getElementById('de-b').value.trim();
  DB.addEmployee({name,email:document.getElementById('de-e').value.trim(),employeeId:document.getElementById('de-id').value.trim(),department:dept,designation:rawBand,_normalizedBand:BAND.normalize(rawBand)||rawBand,experienceYears:document.getElementById('de-exp').value.trim(),location:document.getElementById('de-loc').value.trim(),skills:document.getElementById('de-sk').value.trim(),secondarySkills:document.getElementById('de-sk2').value.trim(),...getDynFields('de-ex')});
  closeDlg();renderEmps();toast('Employee added','ok');
}

function dlgEditEmp(id){
  const e=DB.getEmployees().find(x=>x.id===id);if(!e)return;
  openDlg(`<div class="dlg-title">Edit: ${e.name}</div>
  <div class="form-row"><div class="form-group"><label class="form-label">Name</label><input id="ee-n" class="form-input" value="${e.name||''}"/></div><div class="form-group"><label class="form-label">Email</label><input id="ee-e" class="form-input" value="${e.email||''}"/></div></div>
  <div class="form-row">
    <div class="form-group"><label class="form-label">Designation / Band</label>
      <input id="ee-b" class="form-input" value="${e.designation||''}" placeholder="Click a band below or type..." readonly style="cursor:pointer"/>
      <div class="band-explain" style="margin-top:6px">${BAND.ORDER.map(b=>`<button type="button" class="band-pill ${BAND.getBandClass(b)}" style="cursor:pointer;border:none;font-family:var(--font);font-weight:700;padding:3px 9px;border-radius:4px;${(BAND.normalize(e.designation||'')||'')==b?'outline:2px solid var(--teal)':''}" onclick="document.getElementById('ee-b').value='${b}';this.closest('.band-explain').querySelectorAll('.band-pill').forEach(x=>x.style.outline='none');this.style.outline='2px solid var(--teal)'">${b}</button>`).join('')}` +
      `</div>
    </div>
    <div class="form-group"><label class="form-label">Experience (yrs)</label><input id="ee-exp" type="number" class="form-input" value="${e.experienceYears||''}"/></div>
  </div>
  <div class="form-row"><div class="form-group"><label class="form-label">Location</label><input id="ee-loc" class="form-input" value="${e.location||''}"/></div><div class="form-group"><label class="form-label">Department</label><input id="ee-d" class="form-input" value="${e.department||''}"/></div></div>
  <div class="form-group"><label class="form-label">Primary Skills</label><textarea id="ee-sk" class="form-textarea">${e.skills||''}</textarea></div>
  <div class="form-group"><label class="form-label">Secondary Skills</label><input id="ee-sk2" class="form-input" value="${e.secondarySkills||''}"/></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:16px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveEditEmp('${id}')">Update</button>
  </div>`);
}

function saveEditEmp(id){
  const rawBand=document.getElementById('ee-b').value.trim();
  DB.updateEmployee(id,{name:document.getElementById('ee-n').value.trim(),email:document.getElementById('ee-e').value.trim(),designation:rawBand,_normalizedBand:BAND.normalize(rawBand)||rawBand,experienceYears:document.getElementById('ee-exp').value.trim(),location:document.getElementById('ee-loc').value.trim(),department:document.getElementById('ee-d').value.trim(),skills:document.getElementById('ee-sk').value.trim(),secondarySkills:document.getElementById('ee-sk2').value.trim()});
  closeDlg();renderEmps();toast('Updated','ok');
}

function delEmp(id){
  const e=DB.getEmployees().find(x=>x.id===id);if(!confirm(`Remove ${e?.name}?`))return;
  DB.deleteEmployee(id);DB.empAllocs(id).forEach(a=>DB.removeAllocation(a.id));renderEmps();toast('Removed','info');
}

function dlgAllocate(empId){
  const emp=DB.getEmployees().find(e=>e.id===empId);if(!emp)return;
  const util=DB.empUtil(empId);const avail=100-util;const existing=DB.empAllocs(empId);const projs=DB.getProjects(sc());
  openDlg(`<div class="dlg-title">Allocate: ${emp.name} ${BAND.renderBand(BAND.normalize(emp.designation||emp.band||''))}</div>
  <div class="alert a-info" style="margin-bottom:13px">Utilization: <strong>${util}%</strong> &nbsp;·&nbsp; Available: <strong>${avail}%</strong></div>
  ${existing.length?`<div style="margin-bottom:14px"><label class="form-label">Current Allocations</label><div class="tbl-wrap"><table><tbody>${existing.map(a=>{const ending=AI.endingWithinDays(a,60);return`<tr><td>${a.projectName}${AI.isInternal(a.projectName)?'<span class="badge b-purple" style="margin-left:5px">Internal</span>':''}</td><td><strong style="color:var(--teal)">${a.percentage}%</strong></td><td style="font-size:.75rem;color:var(--text3)">${a.startDate||'—'} → ${a.endDate||'—'}${ending?` <span class="badge b-cyan">ending soon</span>`:''}</td><td><button class="btn btn-xs btn-red" onclick="rmAllocInDlg('${a.id}','${empId}')">Remove</button></td></tr>`;}).join('')}</tbody></table></div></div>`:''}
  <div class="form-group"><label class="form-label">Project *</label>
    <select id="al-p" class="form-select" onchange="checkNewPrj()">
      <option value="">Select...</option>${projs.map(p=>`<option value="${p.id}">${p.name}${p.isInternal?' (Internal)':''}</option>`).join('')}
      <option value="__new__">+ Create new project</option>
    </select>
  </div>
  <div id="al-np-wrap" style="display:none">
    <div class="form-row">
      <div class="form-group"><label class="form-label">Project Name</label><input id="al-pname" class="form-input" placeholder="Project Alpha"/></div>
      <div class="form-group"><label class="form-label">Type</label><select id="al-ptype" class="form-select"><option value="">Client / External</option><option value="internal">Internal / Bench</option></select></div>
    </div>
  </div>
  <div class="form-row">
    <div class="form-group"><label class="form-label">Allocation % (max ${avail}%)</label><input id="al-pct" type="number" class="form-input" min="1" max="${avail}" placeholder="30"/></div>
    <div class="form-group"><label class="form-label">Start Date</label><input id="al-sd" type="date" class="form-input"/></div>
  </div>
  <div class="form-group"><label class="form-label">End Date</label><input id="al-ed" type="date" class="form-input"/></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveAlloc('${empId}')">Allocate</button>
  </div>`);
}

function checkNewPrj(){const v=document.getElementById('al-p')?.value;const w=document.getElementById('al-np-wrap');if(w)w.style.display=v==='__new__'?'block':'none';}
function rmAllocInDlg(allocId,empId){if(!confirm('Remove?'))return;DB.removeAllocation(allocId);closeDlg();dlgAllocate(empId);}

function saveAlloc(empId){
  let projId=document.getElementById('al-p')?.value;const pct=parseFloat(document.getElementById('al-pct')?.value||'0');
  const util=DB.empUtil(empId);const avail=100-util;
  if(!projId)return toast('Select project','err');
  if(pct<=0||pct>avail)return toast(`Must be 1–${avail}%`,'err');
  let projName='';let isInternal=false;
  if(projId==='__new__'){const n=document.getElementById('al-pname')?.value.trim();if(!n)return toast('Enter project name','err');isInternal=document.getElementById('al-ptype')?.value==='internal';const p=DB.addProject({name:n,department:uDept(),isInternal});projId=p.id;projName=n;}
  else{const p=DB.getProjects().find(x=>x.id===projId);projName=p?.name||'Unknown';isInternal=p?.isInternal||false;}
  DB.addAllocation({employeeId:empId,projectId:projId,projectName:projName,isInternal,percentage:pct,startDate:document.getElementById('al-sd')?.value||'',endDate:document.getElementById('al-ed')?.value||''});
  closeDlg();renderEmps();toast(`Allocated ${pct}% to ${projName}`,'ok');
}

// ════════════════════════════════════════════════════════
// ALLOCATIONS PAGE
// ════════════════════════════════════════════════════════
function pageAllocs(){return`
<div class="page-hdr">
  <div class="page-hdr-left"><h1>Allocations</h1><p>All project allocations with real-time utilization tracking</p></div>
  <div class="page-hdr-actions">
    <button class="btn btn-ghost btn-sm" onclick="expAllocs()">⬇ Export</button>
    <button class="btn btn-teal btn-sm" onclick="dlgNewAlloc()">+ New</button>
  </div>
</div>
<div class="filter-row">
  <input type="text" id="f-as" class="fi-text" style="min-width:200px" placeholder="🔍 Search employee..."/>
  <select id="f-ap" class="fi" onchange="renderAllocs()"><option value="">All Projects</option></select>
  <select id="f-atype" class="fi" onchange="renderAllocs()"><option value="">All Types</option><option value="external">Client/External</option><option value="internal">Internal/Bench</option></select>
</div>
<div class="card">
  <div class="card-hdr"><span class="card-title" id="al-cnt">Loading...</span></div>
  <div class="tbl-wrap"><table><thead><tr><th>Employee</th><th>Emp ID</th><th>Cert</th><th>Band</th><th>Dept</th><th>Project</th><th>Type</th><th>Allocation</th><th>Period</th><th>Total Util.</th><th>Actions</th></tr></thead>
  <tbody id="al-tbody"></tbody></table></div>
</div>`}

function initAllocs(dept){
  const projs=DB.getProjects(dept);const ps=document.getElementById('f-ap');
  projs.forEach(p=>ps.innerHTML+=`<option value="${p.id}">${p.name}</option>`);
  document.getElementById('f-as').addEventListener('input',renderAllocs);renderAllocs();
  // Inject notification tab if notifications module loaded
  if(typeof _injectAllocNotifTab==='function') _injectAllocNotifTab();
}

function renderAllocs(){
  const search=(document.getElementById('f-as')?.value||'').toLowerCase();
  const projF=document.getElementById('f-ap')?.value||'';
  const typeF=document.getElementById('f-atype')?.value||'';
  let allocs=DB.getAllocations(sc());
  if(projF)allocs=allocs.filter(a=>a.projectId===projF);
  if(typeF)allocs=allocs.filter(a=>typeF==='internal'?a.isInternal||AI.isInternal(a.projectName):!a.isInternal&&!AI.isInternal(a.projectName));
  const tbody=document.getElementById('al-tbody');if(!tbody)return;
  const rows=allocs.filter(a=>{const emp=DB.getEmployees().find(e=>e.id===a.employeeId);return emp&&(!search||emp.name.toLowerCase().includes(search)||(emp.employeeId||'').toLowerCase().includes(search));})
  .map(a=>{
    const emp=DB.getEmployees().find(e=>e.id===a.employeeId)||{};
    const empB=BAND.normalize(emp.designation||emp.band||'');
    const util=DB.empUtil(a.employeeId);const ending=AI.endingWithinDays(a,60);
    const internal=a.isInternal||AI.isInternal(a.projectName);
    const _acertVal=(()=>{
      const ex=String(emp.isCertified||emp._certified||'').toLowerCase().trim();
      if(ex)return ex;
      const _ck=['certified','certification','iscertified','certifiedyn','certifiedornot'];
      for(const[k,v] of Object.entries(emp)){
        if(!k.startsWith('_extra_'))continue;
        const nk=k.replace('_extra_','').toLowerCase().replace(/[^a-z]/g,'');
        if(_ck.some(kw=>nk.includes(kw)))return String(v||'').toLowerCase().trim();
      }
      return '';
    })();
    const certified=_acertVal==='yes'||_acertVal==='y'||_acertVal==='1'||_acertVal==='true'||_acertVal==='certified';
    const empIdHtml=emp.employeeId?`<span style="font-family:var(--mono);font-size:.74rem;color:var(--text2)">${emp.employeeId}</span>`:`<span style="color:var(--text3);font-size:.72rem">—</span>`;
    const certHtml=certified?`<span class="badge b-green" title="Certified">🏅 Yes</span>`:`<span style="color:var(--text3);font-size:.72rem">No</span>`;
    return`<tr>
      <td><strong>${emp.name||'?'}</strong></td>
      <td>${empIdHtml}</td>
      <td>${certHtml}</td>
      <td>${empB?BAND.renderBand(empB):'—'}</td>
      <td><span class="badge b-blue">${emp.department||'—'}</span></td>
      <td>${a.projectName}</td>
      <td>${internal?'<span class="badge b-purple">Internal</span>':'<span class="badge b-teal">Client</span>'}</td>
      <td>${progBar(a.percentage)}</td>
      <td style="font-size:.76rem;color:var(--text2)">${a.startDate||'—'} → ${a.endDate||'—'}${ending?` <span class="badge b-cyan">⏰ ending</span>`:''}</td>
      <td>${utilBadge(util)}</td>
      <td><div style="display:flex;gap:4px">
        <button class="btn btn-xs btn-ghost" onclick="dlgEditAlloc('${a.id}')">Edit</button>
        <button class="btn btn-xs btn-red" onclick="delAlloc('${a.id}')">Del</button>
      </div></td>
    </tr>`;});
  const lbl=document.getElementById('al-cnt');if(lbl)lbl.textContent=`${rows.length} allocation${rows.length!==1?'s':''}`;
  tbody.innerHTML=rows.length?rows.join(''):`<tr><td colspan="11"><div class="empty"><div class="empty-ico">🎯</div><div class="empty-msg">No allocations found</div></div></td></tr>`;
}

function delAlloc(id){if(!confirm('Remove?'))return;DB.removeAllocation(id);renderAllocs();toast('Removed','info');}

function dlgEditAlloc(id){
  const a=DB.getAllocations().find(x=>x.id===id);if(!a)return;
  const emp=DB.getEmployees().find(e=>e.id===a.employeeId);
  const baseUtil=DB.empUtil(a.employeeId)-a.percentage;const max=100-baseUtil;
  openDlg(`<div class="dlg-title">Edit Allocation</div>
  <p style="color:var(--text2);margin-bottom:13px">${emp?.name||'?'} → ${a.projectName}</p>
  <div class="form-group"><label class="form-label">Allocation % (max ${max}%)</label><input id="ea-p" type="number" class="form-input" value="${a.percentage}" min="1" max="${max}"/></div>
  <div class="form-row"><div class="form-group"><label class="form-label">Start Date</label><input id="ea-s" type="date" class="form-input" value="${a.startDate||''}"/></div><div class="form-group"><label class="form-label">End Date</label><input id="ea-e" type="date" class="form-input" value="${a.endDate||''}"/></div></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveEditAlloc('${id}',${max})">Update</button>
  </div>`);
}

function saveEditAlloc(id,max){
  const p=parseFloat(document.getElementById('ea-p').value||0);if(p<=0||p>max)return toast(`1–${max}%`,'err');
  DB.updateAllocation(id,{percentage:p,startDate:document.getElementById('ea-s').value,endDate:document.getElementById('ea-e').value});
  closeDlg();renderAllocs();toast('Updated','ok');
}

function dlgNewAlloc(){
  const emps=DB.getEmployees(sc());const projs=DB.getProjects(sc());
  openDlg(`<div class="dlg-title">New Allocation</div>
  <div class="form-group"><label class="form-label">Employee *</label>
    <select id="na-emp" class="form-select" onchange="updateAvailNA()"><option value="">Select...</option>
      ${emps.map(e=>{const u=DB.empUtil(e.id);return`<option value="${e.id}" data-avail="${100-u}">${e.name} ${BAND.normalize(e.designation||'')||''} (${100-u}% free)</option>`;}).join('')}
    </select>
  </div>
  <div id="na-avail"></div>
  <div class="form-group"><label class="form-label">Project *</label>
    <select id="na-proj" class="form-select" onchange="checkNewPrjNA()"><option value="">Select...</option>
      ${projs.map(p=>`<option value="${p.id}">${p.name}${p.isInternal?' (Internal)':''}</option>`).join('')}
      <option value="__new__">+ New Project</option>
    </select>
  </div>
  <div id="na-np" style="display:none"><div class="form-group"><label class="form-label">Project Name</label><input id="na-pn" class="form-input" placeholder="Project Name"/></div></div>
  <div class="form-row"><div class="form-group"><label class="form-label">% *</label><input id="na-pct" type="number" class="form-input" min="1" placeholder="30"/></div><div class="form-group"><label class="form-label">Start</label><input id="na-sd" type="date" class="form-input"/></div></div>
  <div class="form-group"><label class="form-label">End</label><input id="na-ed" type="date" class="form-input"/></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveNewAlloc()">Allocate</button>
  </div>`);
}

function updateAvailNA(){const sel=document.getElementById('na-emp');const av=sel.selectedOptions[0]?.dataset.avail;const info=document.getElementById('na-avail');if(av&&info){info.innerHTML=`<div class="alert a-info" style="margin-bottom:10px">Available: <strong>${av}%</strong></div>`;document.getElementById('na-pct').max=av;}}
function checkNewPrjNA(){const v=document.getElementById('na-proj')?.value;const w=document.getElementById('na-np');if(w)w.style.display=v==='__new__'?'block':'none';}

function saveNewAlloc(){
  const empId=document.getElementById('na-emp')?.value;let projId=document.getElementById('na-proj')?.value;
  const pct=parseFloat(document.getElementById('na-pct')?.value||'0');
  if(!empId)return toast('Select employee','err');if(!projId)return toast('Select project','err');
  const util=DB.empUtil(empId);const avail=100-util;
  if(pct<=0||pct>avail)return toast(`1–${avail}%`,'err');
  let projName='';
  if(projId==='__new__'){const n=document.getElementById('na-pn')?.value.trim();if(!n)return toast('Enter project name','err');const p=DB.addProject({name:n,department:uDept()});projId=p.id;projName=n;}
  else projName=DB.getProjects().find(p=>p.id===projId)?.name||'Unknown';
  DB.addAllocation({employeeId:empId,projectId:projId,projectName:projName,percentage:pct,startDate:document.getElementById('na-sd')?.value||'',endDate:document.getElementById('na-ed')?.value||''});
  closeDlg();renderAllocs();toast('Allocated!','ok');
}

function expAllocs(){
  if(!window.XLSX)return toast('XLSX unavailable','err');
  const allocs=DB.getAllocations(sc());if(!allocs.length)return toast('No data','warn');
  const rows=allocs.map(a=>{const emp=DB.getEmployees().find(e=>e.id===a.employeeId)||{};return{Employee:emp.name,Band:BAND.normalize(emp.designation||''),Dept:emp.department,Project:a.projectName,Type:a.isInternal?'Internal':'Client','Alloc%':a.percentage,Start:a.startDate,End:a.endDate};});
  const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Allocations');XLSX.writeFile(wb,'ResourceAI_Allocations.xlsx');toast('Exported!','ok');
}

// ════════════════════════════════════════════════════════
// REQUIREMENTS PAGE
// ════════════════════════════════════════════════════════
function pageReqs(){return`
<div class="page-hdr">
  <div class="page-hdr-left"><h1>Requirements</h1><p>Project staffing requirements with band-aware AI matching</p></div>
  <button class="btn btn-teal btn-sm" onclick="dlgAddReq()">+ New Requirement</button>
</div>
<div class="filter-row">
  <input id="f-rs" type="text" class="fi-text" style="min-width:200px" placeholder="🔍 Search role, skills..."/>
  <select id="f-rstat" class="fi" onchange="renderReqs()"><option value="">All Status</option><option>Open</option><option>In Progress</option><option>Fulfilled</option><option>Cancelled</option></select>
  <select id="f-rpri" class="fi" onchange="renderReqs()"><option value="">All Priority</option><option>High</option><option>Medium</option><option>Low</option></select>
</div>
<div id="req-container"></div>`}

function initReqs(){document.getElementById('f-rs').addEventListener('input',renderReqs);renderReqs();}

function renderReqs(){
  const search=(document.getElementById('f-rs')?.value||'').toLowerCase();
  const statF=document.getElementById('f-rstat')?.value||'';const priF=document.getElementById('f-rpri')?.value||'';
  let reqs=DB.getRequirements(sc());
  if(statF)reqs=reqs.filter(r=>r.status===statF);if(priF)reqs=reqs.filter(r=>r.priority===priF);
  if(search)reqs=reqs.filter(r=>String(r.role||'').toLowerCase().includes(search)||String(r.skills||'').toLowerCase().includes(search));
  const container=document.getElementById('req-container');if(!container)return;
  if(!reqs.length){container.innerHTML=`<div class="empty"><div class="empty-ico">📋</div><div class="empty-msg">No requirements. Add your first one.</div></div>`;return;}
  container.innerHTML=reqs.map(r=>{
    const normB=BAND.normalize(r.designation||r.band||'');
    const extraFieldsHtml = typeof _buildReqExtraFields === 'function' ? _buildReqExtraFields(r) : '';
    return`<div class="card" style="margin-bottom:13px" id="rc-${r.id}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:11px">
        <div style="flex:1;min-width:230px">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:7px">
            <span style="font-weight:800;font-size:1rem">${r.role||r.title||'Requirement'}</span>
            <span class="badge ${r.priority==='High'?'b-red':r.priority==='Medium'?'b-amber':'b-blue'}">${r.priority||'Normal'}</span>
            <span class="badge ${r.status==='Open'?'b-green':r.status==='Fulfilled'?'b-teal':'b-gray'}">${r.status}</span>
            ${r.forFreshers?'<span class="badge b-purple">Freshers Only (A1/A2)</span>':''}
          </div>
          <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:.8rem;color:var(--text2)">
            ${r.skills?`<span>🔧 ${r.skills}</span>`:''}${r.experienceYears?`<span>📅 ${r.experienceYears}+ yrs</span>`:''}
            ${normB?`<span>🎯 Band: ${BAND.renderBand(normB)}</span>`:''}${r.location?`<span>📍 ${r.location}</span>`:''}
            ${r.headcount?`<span>👥 ${r.headcount} headcount</span>`:''}
          </div>
          ${r.description?`<p style="font-size:.8rem;color:var(--text3);margin-top:6px;line-height:1.55">${r.description}</p>`:''}
          ${extraFieldsHtml}
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;flex-shrink:0">
          <button class="btn btn-teal btn-sm" onclick="findForReq('${r.id}')">🧠 Find Employees</button>
          <button class="btn btn-outline btn-sm" onclick="dlgEditReq('${r.id}')">Edit</button>
          <button class="btn btn-ghost btn-sm" onclick="cycleReqStatus('${r.id}','${r.status}')">↻</button>
          <button class="btn btn-red btn-sm" onclick="delReq('${r.id}')">Del</button>
        </div>
      </div>
      <div id="rm-${r.id}" style="margin-top:0"></div>
    </div>`;
  }).join('');

  if (typeof _REQ_OPEN_PANELS !== 'undefined' && _REQ_OPEN_PANELS && typeof _REQ_OPEN_PANELS.forEach === 'function') {
    _REQ_OPEN_PANELS.forEach((html, reqId) => {
      const panel = document.getElementById(`rm-${reqId}`) || document.getElementById(`rmp-${reqId}`);
      if (panel) {
        panel.innerHTML = html;
        if (typeof _injectCandidateExtraFieldsDOM === 'function') {
          _injectCandidateExtraFieldsDOM(reqId);
        }
      }
    });
  }
}

function cycleReqStatus(id,cur){const order=['Open','In Progress','Fulfilled','Cancelled'];DB.updateRequirement(id,{status:order[(order.indexOf(cur)+1)%order.length]});renderReqs();toast('Status updated','info');}
function delReq(id){if(!confirm('Delete?'))return;DB.deleteRequirement(id);renderReqs();toast('Deleted','info');}

function findForReq(reqId){
  const req=DB.getRequirements().find(r=>r.id===reqId);if(!req)return;
  const container=document.getElementById(`rm-${reqId}`);
  container.innerHTML=`<div style="border-top:1px solid var(--border);margin-top:13px;padding-top:13px;display:flex;align-items:center;gap:10px;color:var(--text2);font-size:.84rem"><div class="spin"></div> AI matching employees by availability, band hierarchy, and skills...</div>`;
  if (typeof _REQ_OPEN_PANELS !== 'undefined' && _REQ_OPEN_PANELS) {
    _REQ_OPEN_PANELS.set(reqId, container.innerHTML);
  }
  setTimeout(()=>{
    const result=AI.findMatches(req,sc());
    const total=result.free.length+result.partial.length+result.ending.length+result.internal.length;
    if(total===0&&result.noMatch.length===0){
      const errHtml=`<div style="border-top:1px solid var(--border);margin-top:13px;padding-top:13px"><div class="alert a-warn">No employees match this requirement. Try adjusting band or skills, or import more employee data.</div></div>`;
      container.innerHTML=errHtml;
      if (typeof _REQ_OPEN_PANELS !== 'undefined' && _REQ_OPEN_PANELS) {
        _REQ_OPEN_PANELS.set(reqId, errHtml);
      }
      return;
    }
    const normB=BAND.normalize(req.designation||req.band||'');
    const validBandStr=normB?BAND.getValidBands(normB).join(', '):'Any';
    let html=`<div style="border-top:1px solid var(--border);margin-top:13px;padding-top:13px">
      <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:.76rem;color:var(--text3);margin-bottom:14px">
        <span>🎯 Required Band: ${normB?BAND.renderBand(normB):'Any'}</span>
        <span>📋 Eligible bands: <span style="font-family:var(--mono)">${validBandStr}</span></span>
        ${req.forFreshers?'<span>🎓 Freshers only (A1/A2)</span>':''}
      </div>`;
    if(result.free.length){html+=`<div class="avail-tier at-free">🟢 Tier 1 — 100% Available (${result.free.length})</div>`;html+=result.free.map((e,i)=>renderMatchCard(e,i,'free')).join('');}
    if(result.partial.length){html+=`<div class="avail-tier at-partial" style="margin-top:10px">🟡 Tier 2 — Partially Available ≤50% (${result.partial.length})</div>`;html+=result.partial.map((e,i)=>renderMatchCard(e,i,'partial')).join('');}
    if(result.ending.length){html+=`<div class="avail-tier at-ending" style="margin-top:10px">📅 Tier 3 — Allocation Ending Soon 30–60d (${result.ending.length})</div>`;html+=result.ending.map((e,i)=>renderMatchCard(e,i,'ending')).join('');}
    if(result.internal.length){html+=`<div class="avail-tier at-internal" style="margin-top:10px">🏢 Tier 4 — On Internal Project (${result.internal.length})</div>`;html+=result.internal.map((e,i)=>renderMatchCard(e,i,'internal')).join('');}
    if(result.noMatch.length&&total>0){html+=`<div class="avail-tier at-none" style="margin-top:10px">🔴 Skill-Matched but Busy</div>`;html+=result.noMatch.map((e,i)=>renderMatchCard(e,i,'busy')).join('');}
    if(total===0){html+=`<div class="alert a-warn">No band-matched employees available. Consider expanding the requirement.</div>`;}
    html+='</div>';
    container.innerHTML=html;
    if (typeof _injectCandidateExtraFieldsDOM === 'function') {
      _injectCandidateExtraFieldsDOM(reqId);
    }
    if (typeof _REQ_OPEN_PANELS !== 'undefined' && _REQ_OPEN_PANELS) {
      _REQ_OPEN_PANELS.set(reqId, container.innerHTML);
    }
  },500);
}

function renderMatchCard(e,i,tier){
  const empB=BAND.normalize(e.designation||e.band||e.level||'');
  const scCls=e._score>=75?'sr-high':e._score>=45?'sr-mid':'sr-low';
  let tierInfo='';
  if(tier==='ending')tierInfo=`<span class="badge b-cyan">⏰ Ends ${e._endDate||'soon'}</span>`;
  if(tier==='internal')tierInfo=`<span class="badge b-purple">🏢 ${e._internalProj}</span>`;
  const aspiringSkills=AI.getAspiringSkills(e);
  const effectiveExp=AI.getEffectiveExp(e);
  const allSkills=AI.getSkillObjects(e).filter(s=>!s.isAspiring);
  const skillsHtml=allSkills.length>0
    ?allSkills.slice(0,6).map(s=>{
        const lvlColor=s.level==='expert'?'var(--teal)':s.level==='advanced'?'var(--amber2)':s.level==='beginner'?'var(--text3)':'var(--text2)';
        const lvlBg=s.level==='expert'?'rgba(0,200,180,.12)':s.level==='advanced'?'rgba(240,165,0,.12)':'var(--surface3)';
        return`<span class="chip" title="${s.level}" style="background:${lvlBg};color:${lvlColor}">${s.skill}${s.level==='expert'?'<sup>★★★</sup>':s.level==='advanced'?'<sup>★★</sup>':''}</span>`;
      }).join('')+(allSkills.length>6?`<span class="chip">+${allSkills.length-6}</span>`:'')
    :skillChips(e.skills,6);
  return`<div class="ai-card" style="margin-top:8px">
    <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
      <div style="font-weight:900;font-size:.78rem;color:var(--text3);width:22px">#${i+1}</div>
      <div class="score-ring ${scCls}">${e._score}%</div>
      <div style="flex:1;min-width:180px">
        <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:3px">
          <strong style="font-size:.95rem">${e.name}</strong>
          ${empB?BAND.renderBand(empB):''}
          <span class="badge b-blue">${e.department||'—'}</span>
          ${tierInfo}
        </div>
        <div style="font-size:.76rem;color:var(--text2);margin-bottom:5px">${effectiveExp||'?'} yrs exp · 📍 ${e.location||'—'}</div>
        <div>${skillsHtml}</div>
        ${aspiringSkills.length?`<div style="margin-top:4px"><span style="font-size:.65rem;color:var(--text3);font-style:italic">📚 Aspiring: </span>${aspiringSkills.slice(0,4).map(s=>`<span class="chip" style="color:var(--purple);font-style:italic">${s}</span>`).join('')}</div>`:''}
        ${typeof _buildCandidateExtraFields === 'function' ? _buildCandidateExtraFields(e) : ''}
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0">
        ${availBadge(e._avail)}
        <div style="font-size:.7rem;color:var(--text3)">${e._util}% allocated</div>
        <button class="btn btn-teal btn-xs" onclick="dlgAllocate('${e.id}')">Allocate →</button>
      </div>
    </div>
  </div>`;
}

function dlgAddReq(){
  openDlg(`<div class="dlg-title">New Requirement</div>
  <div class="form-row"><div class="form-group"><label class="form-label">Role / Title *</label><input id="nr-r" class="form-input" placeholder="Senior React Developer"/></div><div class="form-group"><label class="form-label">Priority</label><select id="nr-p" class="form-select"><option>High</option><option selected>Medium</option><option>Low</option></select></div></div>
  <div class="form-row"><div class="form-group"><label class="form-label">Required Skills (comma-sep)</label><input id="nr-sk" class="form-input" placeholder="React, Node.js, AWS..."/></div><div class="form-group"><label class="form-label">Min Experience (yrs)</label><input id="nr-exp" type="number" class="form-input" placeholder="3"/></div></div>
  <div class="form-row">
    <div class="form-group"><label class="form-label">Required Band</label>
      <input id="nr-b" class="form-input" placeholder="B2, Senior, L4..." list="req-band-list"/>
      <datalist id="req-band-list">${BAND.ORDER.map(b=>`<option value="${b}">`).join('')}</datalist>
      <div class="band-explain" style="margin-top:5px">${BAND.ORDER.map(b=>`<span class="band-pill ${BAND.getBandClass(b)}">${b}</span>`).join('')}</div>
    </div>
    <div class="form-group"><label class="form-label">Location</label><input id="nr-loc" class="form-input" placeholder="Hyderabad, Remote..."/></div>
  </div>
  <div class="form-row"><div class="form-group"><label class="form-label">Headcount</label><input id="nr-hc" type="number" class="form-input" value="1" min="1"/></div><div class="form-group"><label class="form-label">Department</label><select id="nr-d" class="form-select">${DB.getDepts().map(d=>`<option ${d===uDept()?'selected':''}>${d}</option>`).join('')}</select></div></div>
  <div class="form-group" style="display:flex;align-items:center;gap:10px"><input type="checkbox" id="nr-fresh" style="width:16px;height:16px"/><label for="nr-fresh" style="font-size:.85rem;cursor:pointer;color:var(--text2)">🎓 For Freshers / New Joiners only (A1/A2)</label></div>
  <div class="form-group"><label class="form-label">Description</label><textarea id="nr-desc" class="form-textarea" placeholder="Additional context..."></textarea></div>
  <div><label class="form-label">Custom Fields</label><div id="nr-ex"></div><button class="btn btn-xs btn-ghost" style="margin-top:5px" onclick="addDynField('nr-ex')">+ Field</button></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveAddReq()">Save</button>
  </div>`);
}

function saveAddReq(){
  const role=document.getElementById('nr-r').value.trim();if(!role)return toast('Role required','err');
  DB.addRequirement({role,priority:document.getElementById('nr-p').value,skills:document.getElementById('nr-sk').value.trim(),experienceYears:document.getElementById('nr-exp').value.trim(),designation:document.getElementById('nr-b').value.trim(),location:document.getElementById('nr-loc').value.trim(),headcount:document.getElementById('nr-hc').value.trim(),department:document.getElementById('nr-d').value,forFreshers:document.getElementById('nr-fresh').checked,description:document.getElementById('nr-desc').value.trim(),...getDynFields('nr-ex')});
  closeDlg();renderReqs();toast('Requirement saved','ok');
}

function dlgEditReq(id){
  const r=DB.getRequirements().find(x=>x.id===id);if(!r)return;
  openDlg(`<div class="dlg-title">Edit Requirement</div>
  <div class="form-row"><div class="form-group"><label class="form-label">Role</label><input id="er-r" class="form-input" value="${r.role||''}"/></div><div class="form-group"><label class="form-label">Priority</label><select id="er-p" class="form-select"><option ${r.priority==='High'?'selected':''}>High</option><option ${r.priority==='Medium'?'selected':''}>Medium</option><option ${r.priority==='Low'?'selected':''}>Low</option></select></div></div>
  <div class="form-row"><div class="form-group"><label class="form-label">Skills</label><input id="er-sk" class="form-input" value="${r.skills||''}"/></div><div class="form-group"><label class="form-label">Min Exp (yrs)</label><input id="er-exp" type="number" class="form-input" value="${r.experienceYears||''}"/></div></div>
  <div class="form-row"><div class="form-group"><label class="form-label">Band</label><input id="er-b" class="form-input" value="${r.designation||''}"/></div><div class="form-group"><label class="form-label">Location</label><input id="er-loc" class="form-input" value="${r.location||''}"/></div></div>
  <div class="form-group"><label class="form-label">Status</label><select id="er-s" class="form-select">${['Open','In Progress','Fulfilled','Cancelled'].map(s=>`<option ${r.status===s?'selected':''}>${s}</option>`).join('')}</select></div>
  <div class="form-group" style="display:flex;align-items:center;gap:10px"><input type="checkbox" id="er-fresh" ${r.forFreshers?'checked':''} style="width:16px;height:16px"/><label for="er-fresh" style="font-size:.85rem;cursor:pointer;color:var(--text2)">🎓 Freshers only (A1/A2)</label></div>
  <div class="form-group"><label class="form-label">Description</label><textarea id="er-desc" class="form-textarea">${r.description||''}</textarea></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveEditReq('${id}')">Update</button>
  </div>`);
}

function saveEditReq(id){
  DB.updateRequirement(id,{role:document.getElementById('er-r').value.trim(),priority:document.getElementById('er-p').value,skills:document.getElementById('er-sk').value.trim(),experienceYears:document.getElementById('er-exp').value.trim(),designation:document.getElementById('er-b').value.trim(),location:document.getElementById('er-loc').value.trim(),status:document.getElementById('er-s').value,forFreshers:document.getElementById('er-fresh').checked,description:document.getElementById('er-desc').value.trim()});
  closeDlg();renderReqs();toast('Updated','ok');
}

// ════════════════════════════════════════════════════════
// WORKFORCE AI PAGE
// ════════════════════════════════════════════════════════
function pageWorkforce(){return`
<div class="page-hdr">
  <div class="page-hdr-left"><h1>🧠 Workforce AI</h1><p>Semantic search — understands bands, synonyms, experience, availability and location</p></div>
</div>
<div class="card" style="margin-bottom:17px">
  <div style="margin-bottom:12px">
    <div style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--teal);margin-bottom:9px">Query examples</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:.8rem;color:var(--text2)">
      <div>🔧 "React developer B2 Hyderabad"</div><div>📅 "Python engineer 5 years senior"</div>
      <div>🎯 "DevOps AWS Cloud A3 available"</div><div>🎓 "Fresher Java A1 Bangalore"</div>
    </div>
  </div>
  <div style="display:flex;gap:9px;margin-bottom:12px">
    <div style="flex:1;display:flex;align-items:center;gap:9px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-sm);padding:9px 13px;transition:var(--t)" onfocusin="this.style.borderColor='var(--teal)'" onfocusout="this.style.borderColor='var(--border)'">
      <span style="color:var(--text3)">🧠</span>
      <input id="ai-q" type="text" style="flex:1;background:transparent;border:none;outline:none;color:var(--text);font-family:var(--font);font-size:.875rem" placeholder='e.g. "Senior React developer B2 4 years Hyderabad available"...' onkeydown="if(event.key==='Enter')doAISearch()" autocomplete="off"/>
    </div>
    <button class="btn btn-teal" onclick="doAISearch()" style="padding:10px 24px">Search</button>
  </div>
  <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:11px">
    ${['React B2 developer','Python ML senior C1','DevOps AWS B3','Java backend B1','Project Manager C2 Hyderabad'].map(q=>`<button class="chip" style="cursor:pointer;padding:4px 9px;font-size:.75rem" onclick="document.getElementById('ai-q').value='${q}';doAISearch()">${q}</button>`).join('')}
  </div>
  <div class="filter-row" style="margin-bottom:0">
    <select id="ai-dept" class="fi"><option value="">All Departments</option>${DB.getDepts().map(d=>`<option ${d===uDept()&&CU.role!=='admin'?'selected':''}>${d}</option>`).join('')}</select>
    <select id="ai-avail" class="fi"><option value="">Any Availability</option><option value="100">100% Free only</option><option value="50">50%+ Available</option><option value="30">30%+ Available</option></select>
    <select id="ai-band-filter" class="fi"><option value="">Any Band</option>${BAND.ORDER.map(b=>`<option>${b}</option>`).join('')}</select>
  </div>
</div>
<div id="ai-results"></div>`}

function doAISearch(){
  const query=document.getElementById('ai-q')?.value.trim();if(!query)return toast('Enter a query','warn');
  const deptF=document.getElementById('ai-dept')?.value||'';
  const availMin=parseInt(document.getElementById('ai-avail')?.value||'0');
  const bandFilter=document.getElementById('ai-band-filter')?.value||'';
  const resEl=document.getElementById('ai-results');
  resEl.innerHTML=`<div style="display:flex;align-items:center;gap:11px;color:var(--text2);font-size:.875rem;padding:16px 0"><div class="spin"></div> Analyzing query and scoring ${DB.getEmployees(sc()).length} employees...</div>`;
  setTimeout(()=>{
    const deptToSearch=CU.role==='admin'?(deptF||null):CU.department;
    let results=AI.search(query,deptToSearch);
    if(availMin>0)results=results.filter(e=>e._avail>=availMin);
    if(bandFilter)results=results.filter(e=>e._band===bandFilter);
    if(!results.length){
      const freeEmps=DB.getEmployees(deptToSearch).filter(e=>DB.empUtil(e.id)===0).slice(0,4);
      resEl.innerHTML=`<div class="alert a-warn" style="margin-bottom:14px">No employees matched <em>"${query}"</em>.</div>
        ${freeEmps.length?`<div class="card"><div class="card-hdr"><span class="card-title">100% Free employees (no skill match)</span></div>${freeEmps.map(e=>`<div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid var(--border)"><div style="flex:1"><strong>${e.name}</strong> ${BAND.renderBand(BAND.normalize(e.designation||''))} <div style="font-size:.75rem;color:var(--text2)">${skillChips(e.skills,4)}</div></div><span class="badge b-green">100% free</span><button class="btn btn-xs btn-outline" onclick="dlgAllocate('${e.id}')">Allocate</button></div>`).join('')}</div>`:''}`;
      return;
    }
    resEl.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:13px;flex-wrap:wrap;gap:7px">
      <div style="font-size:.84rem;color:var(--text2)"><strong style="color:var(--text)">${results.length}</strong> employees matched <em>"${query}"</em></div>
      <div style="font-size:.72rem;color:var(--text3)">Sorted by: Availability → Score → Band proximity</div>
    </div>
    ${results.map((e,i)=>{
      const scCls=e._score>=70?'sr-high':e._score>=40?'sr-mid':'sr-low';
      const empB=e._band;const bd=e._breakdown;
      return`<div class="ai-card">
        <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap">
          <div style="font-weight:900;font-size:.78rem;color:var(--text3);width:22px">#${i+1}</div>
          <div class="score-ring ${scCls}">${e._score}%</div>
          <div style="flex:1;min-width:180px">
            <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:3px">
              <strong style="font-size:.97rem">${e.name}</strong>
              ${empB?BAND.renderBand(empB):''}
              <span class="badge b-blue">${e.department||'—'}</span>
              ${e._endingSoon?'<span class="badge b-cyan">⏰ Ending 60d</span>':''}
              ${e._allInternal?'<span class="badge b-purple">🏢 Internal</span>':''}
            </div>
            <div style="font-size:.76rem;color:var(--text2);margin-bottom:5px">${e.experienceYears||'?'} yrs · 📍 ${e.location||'—'}</div>
            <div>${skillChips(e.skills,5)}</div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;font-size:.69rem;color:var(--text3);margin-top:7px">
              <span>🔧 Skills:<strong style="color:var(--teal)">${bd?.skill||0}%</strong></span>
              <span>📅 Exp:<strong style="color:var(--teal)">${bd?.exp||0}%</strong></span>
              <span>🎯 Band:<strong style="color:var(--teal)">${bd?.band||0}%</strong></span>
              <span>⚡ Avail:<strong style="color:var(--teal)">${bd?.avail||0}%</strong></span>
              <span>📍 Loc:<strong style="color:var(--teal)">${bd?.loc||0}%</strong></span>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;flex-shrink:0">
            ${availBadge(e._avail)}
            <div style="font-size:.69rem;color:var(--text3)">${e._util}% allocated</div>
            <button class="btn btn-teal btn-sm" onclick="dlgAllocate('${e.id}')">Allocate</button>
            <button class="btn btn-ghost btn-xs" onclick="dlgEditEmp('${e.id}')">Edit</button>
          </div>
        </div>
      </div>`;
    }).join('')}`;
  },600);
}

// ════════════════════════════════════════════════════════
// REPORTS PAGE
// ════════════════════════════════════════════════════════
function pageReports(){return`
<div class="page-hdr"><div class="page-hdr-left"><h1>Reports</h1><p>Interactive analytics across your workforce</p></div><button class="btn btn-ghost btn-sm" onclick="expReport()">⬇ Export</button></div>
<div class="tab-strip">
  <button class="tab-btn active" onclick="switchRTab(this,'r-util')">📊 Utilization</button>
  <button class="tab-btn" onclick="switchRTab(this,'r-skills')">🔧 Skills</button>
  <button class="tab-btn" onclick="switchRTab(this,'r-projs')">🎯 Projects</button>
  <button class="tab-btn" onclick="switchRTab(this,'r-bands')">🏅 Bands</button>
  <button class="tab-btn" onclick="switchRTab(this,'r-forecast')">📅 Forecast</button>
</div>
<div id="r-util">
  <div class="grid-2" style="margin-bottom:17px">
    <div class="card"><div class="card-hdr"><span class="card-title">Utilization by Employee</span></div><div class="chart-box" style="height:270px"><canvas id="rc-ue"></canvas></div></div>
    <div class="card"><div class="card-hdr"><span class="card-title">Department Avg</span></div><div class="chart-box" style="height:270px"><canvas id="rc-ud"></canvas></div></div>
  </div>
  <div class="card"><div class="card-hdr"><span class="card-title">Full Utilization Detail</span></div><div class="tbl-wrap" id="r-util-tbl"></div></div>
</div>
<div id="r-skills" style="display:none"><div class="grid-2"><div class="card"><div class="card-hdr"><span class="card-title">Skill Distribution</span></div><div class="chart-box" style="height:270px"><canvas id="rc-sb"></canvas></div></div><div class="card"><div class="card-hdr"><span class="card-title">Coverage</span></div><div class="chart-box" style="height:270px"><canvas id="rc-sp"></canvas></div></div></div></div>
<div id="r-projs" style="display:none"><div class="card" style="margin-bottom:17px"><div class="card-hdr"><span class="card-title">Headcount per Project</span></div><div class="chart-box" style="height:270px"><canvas id="rc-pb"></canvas></div></div><div class="card"><div class="card-hdr"><span class="card-title">Project Details</span></div><div class="tbl-wrap" id="r-proj-tbl"></div></div></div>
<div id="r-bands" style="display:none"><div class="grid-2"><div class="card"><div class="card-hdr"><span class="card-title">Band Distribution</span></div><div class="chart-box" style="height:270px"><canvas id="rc-bd"></canvas></div></div><div class="card"><div class="card-hdr"><span class="card-title">Band Utilization</span></div><div class="tbl-wrap" id="r-band-tbl"></div></div></div></div>
<div id="r-forecast" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Allocations Ending in Next 60 Days</span></div><div class="tbl-wrap" id="r-fc-tbl"></div></div></div>`}

function switchRTab(btn,tabId){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
  ['r-util','r-skills','r-projs','r-bands','r-forecast'].forEach(id=>{const el=document.getElementById(id);if(el)el.style.display='none';});
  document.getElementById(tabId).style.display='block';
}

function initReports(dept){
  const emps=DB.getEmployees(dept);const allocs=DB.getAllocations(dept);
  const top12=emps.map(e=>({n:e.name.split(' ')[0],u:DB.empUtil(e.id)})).sort((a,b)=>b.u-a.u).slice(0,12);
  const ctx1=document.getElementById('rc-ue')?.getContext('2d');
  if(ctx1)new Chart(ctx1,{type:'bar',data:{labels:top12.map(e=>e.n),datasets:[{data:top12.map(e=>e.u),backgroundColor:top12.map(e=>e.u>=90?'#ff4466':e.u>=70?'#f0a500':'#00c8b4'),borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070'},grid:{color:'rgba(0,200,180,.04)'},max:100},y:{ticks:{color:'#7fa0b0'},grid:{color:'rgba(0,200,180,.04)'}}}}});
  const depts=DB.getDepts();const actDepts=depts.filter(d=>DB.getEmployees(d).length>0);
  const dUtils=actDepts.map(d=>{const de=DB.getEmployees(d);return de.length?Math.round(de.reduce((s,e)=>s+DB.empUtil(e.id),0)/de.length):0;});
  const ctx2=document.getElementById('rc-ud')?.getContext('2d');
  if(ctx2)new Chart(ctx2,{type:'radar',data:{labels:actDepts.slice(0,8),datasets:[{label:'Avg %',data:dUtils.slice(0,8),backgroundColor:'rgba(0,200,180,.1)',borderColor:'var(--teal)',borderWidth:2,pointBackgroundColor:'var(--teal)',pointRadius:3}]},options:{responsive:true,maintainAspectRatio:false,scales:{r:{ticks:{color:'#4a6070',stepSize:20},grid:{color:'rgba(0,200,180,.08)'},pointLabels:{color:'#7fa0b0'},min:0,max:100}},plugins:{legend:{display:false}}}});
  const utEl=document.getElementById('r-util-tbl');
  if(utEl)utEl.innerHTML=`<table><thead><tr><th>Employee</th><th>Band</th><th>Dept</th><th>Exp</th><th>Utilization</th><th>Available</th><th>Projects</th><th>Status</th></tr></thead><tbody>${emps.map(e=>{const u=DB.empUtil(e.id);const empB=BAND.normalize(e.designation||e.band||'');const cnt=DB.empAllocs(e.id).length;const endS=DB.empAllocs(e.id).some(a=>AI.endingWithinDays(a,30));return`<tr><td><strong>${e.name}</strong></td><td>${empB?BAND.renderBand(empB):'—'}</td><td>${e.department||'—'}</td><td style="font-family:var(--mono)">${e.experienceYears||'?'}</td><td style="min-width:130px">${progBar(u)}</td><td>${availBadge(100-u)}</td><td>${cnt}</td><td>${endS?'<span class="badge b-cyan">Ending 30d</span>':u===0?'<span class="badge b-green">Free</span>':u<=50?'<span class="badge b-teal">Partial</span>':'<span class="badge b-amber">Busy</span>'}</td></tr>`;}).join('')}</tbody></table>`;
  const skC={};emps.forEach(e=>String(e.skills||'').split(/[,;|]/).map(s=>s.trim().toLowerCase()).filter(s=>s.length>1).forEach(s=>{skC[s]=(skC[s]||0)+1;}));
  const topSk=Object.entries(skC).sort((a,b)=>b[1]-a[1]).slice(0,10);
  const ctx3=document.getElementById('rc-sb')?.getContext('2d');if(ctx3)new Chart(ctx3,{type:'bar',data:{labels:topSk.map(s=>s[0]),datasets:[{data:topSk.map(s=>s[1]),backgroundColor:'#00c8b4',borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070'},grid:{color:'rgba(0,200,180,.04)'}},y:{ticks:{color:'#4a6070',stepSize:1},grid:{color:'rgba(0,200,180,.04)'},beginAtZero:true}}}});
  const ctx4=document.getElementById('rc-sp')?.getContext('2d');if(ctx4)new Chart(ctx4,{type:'doughnut',data:{labels:topSk.slice(0,6).map(s=>s[0]),datasets:[{data:topSk.slice(0,6).map(s=>s[1]),backgroundColor:['#00c8b4','#3d8bff','#22d46a','#f0a500','#ff4466','#a55eea'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{color:'#7fa0b0',boxWidth:10,padding:8,font:{size:11}}}}}});
  const projM={};allocs.forEach(a=>{projM[a.projectName]=(projM[a.projectName]||0)+1;});
  const pE=Object.entries(projM).sort((a,b)=>b[1]-a[1]);
  const ctx5=document.getElementById('rc-pb')?.getContext('2d');if(ctx5)new Chart(ctx5,{type:'bar',data:{labels:pE.map(p=>p[0]),datasets:[{label:'Employees',data:pE.map(p=>p[1]),backgroundColor:'#3d8bff',borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#4a6070'},grid:{color:'rgba(0,200,180,.04)'}},y:{ticks:{color:'#4a6070',stepSize:1},grid:{color:'rgba(0,200,180,.04)'},beginAtZero:true}}}});
  const ptEl=document.getElementById('r-proj-tbl');if(ptEl)ptEl.innerHTML=`<table><thead><tr><th>Project</th><th>Employees</th><th>Type</th><th>Total Alloc</th></tr></thead><tbody>${pE.map(([n,c])=>{const total=allocs.filter(a=>a.projectName===n).reduce((s,a)=>s+(parseFloat(a.percentage)||0),0);const internal=AI.isInternal(n)||allocs.find(a=>a.projectName===n)?.isInternal;return`<tr><td><strong>${n}</strong></td><td>${c}</td><td>${internal?'<span class="badge b-purple">Internal</span>':'<span class="badge b-teal">Client</span>'}</td><td>${total}%</td></tr>`;}).join('')}</tbody></table>`;
  const bandC={};emps.forEach(e=>{const b=BAND.normalize(e.designation||e.band||'')||'Unknown';bandC[b]=(bandC[b]||0)+1;});
  const bandE=Object.entries(bandC);
  const ctx6=document.getElementById('rc-bd')?.getContext('2d');if(ctx6)new Chart(ctx6,{type:'doughnut',data:{labels:bandE.map(b=>b[0]),datasets:[{data:bandE.map(b=>b[1]),backgroundColor:['#22d46a','#00c8b4','#06c8e8','#3d8bff','#a55eea','#f0a500','#ff4466','#ffbe2e','#ff7043','#00d2d3','#4ecdc4','#c7f464'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{color:'#7fa0b0',boxWidth:10,padding:8,font:{size:11}}}}}});
  const btEl=document.getElementById('r-band-tbl');if(btEl)btEl.innerHTML=`<table><thead><tr><th>Band</th><th>Count</th><th>Avg Util</th><th>Avg Avail</th></tr></thead><tbody>${BAND.ORDER.filter(b=>bandC[b]).map(b=>{const be=emps.filter(e=>BAND.normalize(e.designation||e.band||'')===b);const avgU=be.length?Math.round(be.reduce((s,e)=>s+DB.empUtil(e.id),0)/be.length):0;return`<tr><td>${BAND.renderBand(b)}</td><td>${bandC[b]||0}</td><td>${utilBadge(avgU)}</td><td>${availBadge(100-avgU)}</td></tr>`;}).join('')}</tbody></table>`;
  const fcEl=document.getElementById('r-fc-tbl');
  if(fcEl){
    const ending60=[];
    allocs.forEach(a=>{if(AI.endingWithinDays(a,60)){const emp=DB.getEmployees().find(e=>e.id===a.employeeId);if(emp)ending60.push({...a,emp});}});
    if(!ending60.length){fcEl.innerHTML=`<div class="empty"><div class="empty-ico">📅</div><div class="empty-msg">No allocations ending in the next 60 days</div></div>`;}
    else fcEl.innerHTML=`<table><thead><tr><th>Employee</th><th>Band</th><th>Project</th><th>End Date</th><th>Days Left</th><th>Current Util</th></tr></thead><tbody>${ending60.sort((a,b)=>new Date(a.endDate)-new Date(b.endDate)).map(a=>{const daysLeft=Math.ceil((new Date(a.endDate)-new Date())/(1000*60*60*24));const empB=BAND.normalize(a.emp.designation||a.emp.band||'');return`<tr><td><strong>${a.emp.name}</strong></td><td>${empB?BAND.renderBand(empB):'—'}</td><td>${a.projectName}</td><td style="font-family:var(--mono)">${a.endDate}</td><td><span class="badge ${daysLeft<=14?'b-red':daysLeft<=30?'b-amber':'b-cyan'}">${daysLeft}d</span></td><td>${utilBadge(DB.empUtil(a.emp.id))}</td></tr>`;}).join('')}</tbody></table>`;
  }
}

function expReport(){
  if(!window.XLSX)return toast('XLSX unavailable','err');
  const emps=DB.getEmployees(sc());if(!emps.length)return toast('No data','warn');
  const rows=emps.map(e=>({Name:e.name,Email:e.email,Dept:e.department,Designation:e.designation,Band:BAND.normalize(e.designation||e.band||''),Exp:e.experienceYears,Loc:e.location,Skills:e.skills,Util:DB.empUtil(e.id)+'%',Avail:(100-DB.empUtil(e.id))+'%',Projects:DB.empAllocs(e.id).map(a=>a.projectName).join(', ')}));
  const ws=XLSX.utils.json_to_sheet(rows);const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Report');XLSX.writeFile(wb,'ResourceAI_Report.xlsx');toast('Exported!','ok');
}

// ════════════════════════════════════════════════════════
// DATA IMPORT PAGE — handled by importer.js
// All functions: pageUpload, runImport, processFile, resetUp,
//   dzO, dzL, dzD, fileSel, updateUpBar, showExcelViewer
//   _importRequirements, _importReqRows
// ════════════════════════════════════════════════════════

// ════════════════════════════════════════════════════════
// ADMIN CENTER
// ════════════════════════════════════════════════════════
function pageAdmin(){
  if(CU.role!=='admin')return`<div class="empty"><div class="empty-ico">🔒</div><div class="empty-msg">Admin only</div></div>`;
  return`<div class="page-hdr"><div class="page-hdr-left"><h1>Admin Center</h1><p>Manage users, departments, approvals and system settings</p></div></div>
  <div class="tab-strip">
    <button class="tab-btn active" onclick="switchATab(this,'a-pend')">⏳ Pending</button>
    <button class="tab-btn" onclick="switchATab(this,'a-users')">👥 Users</button>
    <button class="tab-btn" onclick="switchATab(this,'a-depts')">🏢 Departments</button>
    <button class="tab-btn" onclick="switchATab(this,'a-emails')">📬 Email Log</button>
    <button class="tab-btn" onclick="switchATab(this,'a-data')">🗄️ Data</button>
  </div>
  <div id="a-pend"><div class="card" id="pend-content"></div></div>
  <div id="a-users" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">All Users</span><button class="btn btn-teal btn-sm" onclick="dlgAddUser()">+ Add User</button></div><div class="tbl-wrap" id="users-tbl"></div></div></div>
  <div id="a-depts" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Departments</span></div><div style="display:flex;gap:9px;margin-bottom:14px"><input id="new-d" class="form-input" style="max-width:230px" placeholder="Department name"/><button class="btn btn-teal" onclick="addDeptAdmin()">Add</button></div><div id="depts-list"></div></div></div>
  <div id="a-emails" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Email Log</span><span style="font-size:.75rem;color:var(--text3)">(Connect SMTP for real delivery)</span></div><div class="tbl-wrap" id="emails-tbl"></div></div></div>
  <div id="a-data" style="display:none"><div class="card"><div class="card-hdr"><span class="card-title">Data Management</span></div><div id="data-content"></div></div></div>`;
}

function switchATab(btn,tabId){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
  ['a-pend','a-users','a-depts','a-emails','a-data'].forEach(id=>{const el=document.getElementById(id);if(el)el.style.display='none';});
  document.getElementById(tabId).style.display='block';
}

function initAdmin(){
  if(CU.role!=='admin')return;
  // patch users table with password status if password module loaded
  setTimeout(()=>{ if(typeof _patchUsersTable==='function') _patchUsersTable(); },80);
  const pending=DB.getPending();const pEl=document.getElementById('pend-content');
  if(pEl){if(!pending.length){pEl.innerHTML=`<div class="empty"><div class="empty-ico">✅</div><div class="empty-msg">No pending requests</div></div>`;}
  else pEl.innerHTML=`<div class="card-hdr"><span class="card-title">Pending Approvals (${pending.length})</span></div><div class="tbl-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Dept</th><th>Reason</th><th>Requested</th><th>Actions</th></tr></thead><tbody>${pending.map(r=>`<tr><td><strong>${r.name}</strong></td><td>${r.email}</td><td><span class="badge b-blue">${r.department}</span></td><td style="font-size:.78rem;color:var(--text3)">${r.reason||'—'}</td><td style="font-size:.76rem;color:var(--text3)">${new Date(r.at).toLocaleString()}</td><td><div style="display:flex;gap:5px"><button class="btn btn-green btn-xs" onclick="approvePend('${r.id}')">✓ Approve</button><button class="btn btn-red btn-xs" onclick="rejectPend('${r.id}')">✕ Reject</button></div></td></tr>`).join('')}</tbody></table></div>`;}
  const uEl=document.getElementById('users-tbl');
  if(uEl){const users=DB.getUsers();uEl.innerHTML=`<table><thead><tr><th>Name</th><th>Email</th><th>Dept</th><th>Role</th><th>Actions</th></tr></thead><tbody>${users.map(u=>`<tr><td><strong>${u.name}</strong></td><td>${u.email}</td><td>${u.department}</td><td><span class="badge ${u.role==='admin'?'b-amber':'b-teal'}">${u.role}</span></td><td>${u.id!==CU.id?`<button class="btn btn-red btn-xs" onclick="delUser('${u.id}')">Remove</button>`:'<span class="badge b-gray">You</span>'}</td></tr>`).join('')}</tbody></table>`;}
  const dEl=document.getElementById('depts-list');
  if(dEl)dEl.innerHTML=`<div style="display:flex;flex-wrap:wrap;gap:8px">${DB.getDepts().map(d=>`<div style="display:flex;align-items:center;gap:6px;background:var(--bg3);padding:7px 12px;border-radius:var(--r-sm)"><span style="font-size:.84rem">${d}</span><button class="btn btn-xs btn-red" onclick="rmDept('${d}')">✕</button></div>`).join('')}</div>`;
  const eEl=document.getElementById('emails-tbl');
  if(eEl){const logs=DB.getEmailLog();if(!logs.length){eEl.innerHTML=`<div class="empty"><div class="empty-ico">📬</div><div class="empty-msg">No emails logged</div></div>`;}else eEl.innerHTML=`<table><thead><tr><th>To</th><th>Subject</th><th>Sent At</th></tr></thead><tbody>${logs.map(l=>`<tr><td>${l.to}</td><td>${l.subject}</td><td style="font-size:.76rem;color:var(--text3)">${new Date(l.at).toLocaleString()}</td></tr>`).join('')}</tbody></table>`;}
  const dCEl=document.getElementById('data-content');
  if(dCEl)dCEl.innerHTML=`${[['Employees',DB.getEmployees().length,'emps'],['Allocations',DB.getAllocations().length,'allocs'],['Requirements',DB.getRequirements().length,'reqs'],['Projects',DB.getProjects().length,'projs']].map(([lbl,cnt,key])=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:13px;background:var(--bg3);border-radius:var(--r-sm);margin-bottom:9px"><div><strong>${lbl}</strong> <span style="color:var(--text3);font-size:.83rem">${cnt} records</span></div><button class="btn btn-red btn-sm" onclick="clrData('${key}')">Clear</button></div>`).join('')}<div style="padding-top:11px;border-top:1px solid var(--border)"><button class="btn btn-red" onclick="factoryReset()">🔥 Factory Reset</button></div>`;
}

function approvePend(id){const u=DB.approvePending(id);if(u){Notify.onApprove(u);buildSidebar();initAdmin();toast(`${u.name} approved!`,'ok');}}
function rejectPend(id){const r=DB.getPending().find(x=>x.id===id);if(!confirm(`Reject ${r?.name}?`))return;Notify.onReject(r);DB.rejectPending(id);initAdmin();toast('Rejected','info');}
function delUser(id){if(!confirm('Delete user?'))return;DB.deleteUser(id);initAdmin();toast('Deleted','info');}
function addDeptAdmin(){const n=document.getElementById('new-d')?.value.trim();if(!n)return;DB.addDept(n);document.getElementById('new-d').value='';initAdmin();toast(`"${n}" added`,'ok');}
function rmDept(n){if(!confirm(`Remove "${n}"?`))return;DB.removeDept(n);initAdmin();toast('Removed','info');}
function clrData(type){if(!confirm(`Clear all ${type}?`))return;const m={emps:()=>DB.clearEmployees(null),allocs:()=>DB.clearAllocs(null),reqs:()=>DB._s('requirements',[]),projs:()=>DB._s('projects',[])};m[type]?.();initAdmin();toast('Cleared','info');}
function factoryReset(){if(!confirm('FACTORY RESET — delete ALL data?'))return;if(!confirm('Are you absolutely sure?'))return;localStorage.clear();DB.init();doLogout();toast('Reset done','info');}

function dlgAddUser(){
  openDlg(`<div class="dlg-title">Add User</div>
  <div class="form-row"><div class="form-group"><label class="form-label">Name</label><input id="au-n" class="form-input" placeholder="Full name"/></div><div class="form-group"><label class="form-label">Email</label><input id="au-e" type="email" class="form-input"/></div></div>
  <div class="form-row"><div class="form-group"><label class="form-label">Department</label><select id="au-d" class="form-select">${DB.getDepts().map(d=>`<option>${d}</option>`).join('')}</select></div><div class="form-group"><label class="form-label">Role</label><select id="au-r" class="form-select"><option value="user">User</option><option value="admin">Admin</option></select></div></div>
  <div class="form-group"><label class="form-label">Password (min 8)</label><input id="au-p" type="password" class="form-input"/></div>
  <div style="display:flex;gap:9px;justify-content:flex-end;margin-top:15px">
    <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
    <button class="btn btn-teal" onclick="saveAddUser()">Create</button>
  </div>`);
}

function saveAddUser(){
  const n=document.getElementById('au-n').value.trim();const e=document.getElementById('au-e').value.trim();const p=document.getElementById('au-p').value;
  if(!n||!e||!p)return toast('Fill all fields','err');if(p.length<8)return toast('Min 8 chars','err');if(DB.getByEmail(e))return toast('Email exists','err');
  DB.addUser({name:n,email:e,passHash:SEC.hash(p),role:document.getElementById('au-r').value,department:document.getElementById('au-d').value,approved:true});
  closeDlg();initAdmin();toast('User created','ok');
}

// ════════════════════════════════════════════════════════
// LANDING PARTICLES & LIVE METRICS
// ════════════════════════════════════════════════════════
function initParticles(){
  const c=document.getElementById('particles');if(!c)return;
  for(let i=0;i<22;i++){const p=document.createElement('div');p.className='pt';p.style.cssText=`left:${Math.random()*100}%;top:${Math.random()*100}%;--d:${6+Math.random()*8}s;--dl:${Math.random()*8}s;width:${1+Math.random()*2}px;height:${1+Math.random()*2}px`;c.appendChild(p);}
}

function updateLandingMetrics(){
  function animN(id,t){const el=document.getElementById(id);if(!el)return;let c=0;const s=Math.max(1,Math.ceil(t/25));const ti=setInterval(()=>{c=Math.min(c+s,t);el.textContent=c;if(c>=t)clearInterval(ti);},40);}
  animN('lm-e',DB.getEmployees().length);
  animN('lm-p',DB.getProjects().length);
  animN('lm-r',DB.getRequirements().filter(r=>r.status==='Open').length);
}

// ════════════════════════════════════════════════════════
// BOOTSTRAP — runs on page load
// ════════════════════════════════════════════════════════
DB.init();
initParticles();
updateLandingMetrics();

// Restore session if still valid
const _saved = DB.session();
if(_saved && _saved.email){
  const _u = DB.getByEmail(_saved.email);
  if(_u && _u.approved){ CU=_u; showPage('pg-app'); launchApp(); }
}
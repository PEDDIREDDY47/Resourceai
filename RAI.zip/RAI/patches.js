'use strict';
// ═══════════════════════════════════════════════════════════════════════
// PATCHES.JS — Simple utilities only. No function chaining.
// All integration hooks are now directly in app.js using typeof guards:
//   if(typeof initNotifications==='function') initNotifications();
//   if(typeof _needsForcedChange==='function') ...
//   if(typeof _injectAllocNotifTab==='function') ...
//   if(typeof _patchUsersTable==='function') ...
// This file just provides mobile sidebar helpers.
// ═══════════════════════════════════════════════════════════════════════

// Mobile sidebar toggle
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('sb-overlay');
  if (!sb) return;
  const isOpen = sb.classList.toggle('mob-open');
  if (ov) ov.classList.toggle('visible', isOpen);
}

function closeSidebar() {
  document.getElementById('sidebar')?.classList.remove('mob-open');
  document.getElementById('sb-overlay')?.classList.remove('visible');
}

// Password constants — defined here so password.js + notifications.js can both use them
const DEFAULT_ADMIN_HASH = SEC.hash('Admin@2025');

function _needsForcedChange(user) {
  if (!user) return false;
  if (user.passHash === DEFAULT_ADMIN_HASH) return true;
  if (user.mustChangePassword) return true;
  return false;
}

'use strict';
// ═══════════════════════════════════════════════════════════════════════
// WORKDAY.JS — Workday-department skill multiselect
//
// Condition: fires ONLY when the current user's department === 'Workday'
// Applies to: Add Employee dialog  (dlgAddEmp)
//             Add Requirement dialog (dlgAddReq)
//
// Behaviour:
//   • Replaces the free-text skills textarea/input with a visual
//     chip-style multiselect built from the master WORKDAY_SKILLS list
//   • "Other" is always the last option — selecting it reveals a plain
//     text input so the user can type any custom skill
//   • Selected skills are stored as a comma-separated string (same
//     format the rest of the app expects — no downstream changes needed)
//   • For non-Workday users everything works exactly as before
//
// Depends on: app.js (uDept, openDlg, closeDlg, toast, BAND, DB,
//             getDynFields, addDynField, renderEmps, saveAddEmp,
//             renderReqs, saveAddReq)
// ═══════════════════════════════════════════════════════════════════════

// ── Master skill list ─────────────────────────────────────────────────
const WORKDAY_SKILLS = [
  'Absence',
  'Adv Compensation',
  'Benefits',
  'BIRT',
  'Compensation',
  'Core Connector',
  'Data Conversion',
  'EIB',
  'Extend',
  'Finance',
  'HCM',
  'Learning',
  'Payroll',
  'PECI',
  'PICOF',
  'PRISM',
  'Project Management',
  'Recruitment',
  'Reports',
  'Security',
  'Studio',
  'Talent & Performance',
  'Time Tracking',
  'Agentic AI',
  'Orchestration',
  'Other',          // ← always last; triggers free-text input
];

// ── Helper: is the current user in the Workday department? ────────────
function _isWorkday() {
  return (typeof CU !== 'undefined' && CU !== null)
    && String(CU.department || '').trim().toLowerCase() === 'workday';
}

// ═══════════════════════════════════════════════════════════════════════
// MULTISELECT WIDGET BUILDER
// Returns an HTML string for the skills section.
// containerId  — the id of the wrapping div (used to read selections)
// preSelected  — comma-separated string of already-selected skills
//                (used when editing an existing record)
// ═══════════════════════════════════════════════════════════════════════
function _buildWorkdaySkillPicker(containerId, preSelected = '') {
  const selected = new Set(
    preSelected.split(',').map(s => s.trim()).filter(Boolean)
  );
  // Any values in preSelected that aren't in the master list go into "Other"
  const extraValues = [...selected].filter(s => !WORKDAY_SKILLS.slice(0,-1).includes(s));
  const otherPreVal = extraValues.join(', ');
  const hasOther    = selected.has('Other') || extraValues.length > 0;

  const chips = WORKDAY_SKILLS.map(skill => {
    const isOther   = skill === 'Other';
    const isSel     = selected.has(skill) || (isOther && hasOther);
    return `
<button type="button"
  class="wd-chip${isSel ? ' wd-sel' : ''}"
  data-skill="${skill}"
  onclick="_toggleWdChip(this,'${containerId}')">
  ${skill}${isSel && !isOther ? ' ✓' : ''}
</button>`;
  }).join('');

  return `
<div id="${containerId}" class="wd-picker">
  <div class="wd-chips">${chips}</div>

  <!-- "Other" free-text appears only when Other chip is selected -->
  <div id="${containerId}-other-wrap"
       style="margin-top:9px;display:${hasOther ? 'block' : 'none'}">
    <input id="${containerId}-other-input"
           class="form-input"
           placeholder="Type additional skills (comma-separated)…"
           value="${otherPreVal}"
           oninput="_syncWdHidden('${containerId}')"/>
    <div style="font-size:.71rem;color:var(--text3);margin-top:3px">
      These will be appended to selected skills above.
    </div>
  </div>

  <!-- Hidden input keeps the final comma-separated value -->
  <input type="hidden" id="${containerId}-value"/>
</div>`;
}

// ── Toggle a chip on/off ──────────────────────────────────────────────
function _toggleWdChip(btn, containerId) {
  const skill   = btn.dataset.skill;
  const isOther = skill === 'Other';
  const wasSel  = btn.classList.contains('wd-sel');

  btn.classList.toggle('wd-sel', !wasSel);
  btn.textContent = (!wasSel && !isOther) ? skill + ' ✓' : skill;

  // Show/hide the free-text box when "Other" is toggled
  if (isOther) {
    const wrap = document.getElementById(`${containerId}-other-wrap`);
    if (wrap) wrap.style.display = !wasSel ? 'block' : 'none';
    if (!wasSel) {
      setTimeout(() => document.getElementById(`${containerId}-other-input`)?.focus(), 50);
    }
  }

  _syncWdHidden(containerId);
}

// ── Sync hidden input with current chip selections ────────────────────
function _syncWdHidden(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const selected = [];
  container.querySelectorAll('.wd-chip.wd-sel').forEach(btn => {
    const skill = btn.dataset.skill;
    if (skill !== 'Other') selected.push(skill);
  });

  // Append anything typed in the free-text box
  const otherInput = document.getElementById(`${containerId}-other-input`);
  if (otherInput && otherInput.value.trim()) {
    otherInput.value.split(',').map(s => s.trim()).filter(Boolean).forEach(s => {
      if (!selected.includes(s)) selected.push(s);
    });
  }

  const hidden = document.getElementById(`${containerId}-value`);
  if (hidden) hidden.value = selected.join(', ');
}

// ── Read final value from the picker ─────────────────────────────────
function _getWdSkills(containerId) {
  _syncWdHidden(containerId);
  return document.getElementById(`${containerId}-value`)?.value || '';
}

// ── Read final value from a plain text input (non-Workday path) ───────
function _getPlainSkills(inputId) {
  return document.getElementById(inputId)?.value.trim() || '';
}


// ═══════════════════════════════════════════════════════════════════════
// CSS — injected once into the page <head>
// ═══════════════════════════════════════════════════════════════════════
(function _injectWdCSS() {
  if (document.getElementById('wd-styles')) return;
  const style = document.createElement('style');
  style.id = 'wd-styles';
  style.textContent = `
/* Workday skill picker container */
.wd-picker {
  border: 1px solid var(--border);
  border-radius: var(--r-sm);
  padding: 10px 12px;
  background: var(--surface);
  transition: border-color var(--t);
}
.wd-picker:focus-within {
  border-color: var(--teal);
  box-shadow: 0 0 0 3px rgba(0,200,180,.1);
}

/* Chip grid */
.wd-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
}

/* Individual chip */
.wd-chip {
  font-family: var(--font);
  font-size: .78rem;
  font-weight: 600;
  padding: 5px 12px;
  border-radius: 100px;
  border: 1px solid var(--border2);
  background: var(--surface2);
  color: var(--text2);
  cursor: pointer;
  transition: background .13s, border-color .13s, color .13s, transform .1s;
  user-select: none;
  line-height: 1.4;
}
.wd-chip:hover {
  border-color: var(--teal);
  color: var(--text);
  background: rgba(0,200,180,.07);
}

/* Selected state */
.wd-chip.wd-sel {
  background: rgba(0,200,180,.15);
  border-color: var(--teal);
  color: var(--teal);
  font-weight: 700;
}
.wd-chip.wd-sel:hover {
  background: rgba(0,200,180,.25);
}

/* "Other" chip — distinct purple tint */
.wd-chip[data-skill="Other"] {
  border-style: dashed;
  color: var(--purple);
  border-color: rgba(165,94,234,.4);
  background: rgba(165,94,234,.06);
}
.wd-chip[data-skill="Other"].wd-sel {
  background: rgba(165,94,234,.15);
  border-color: var(--purple);
  border-style: solid;
  color: var(--purple);
}

/* Helper label above picker */
.wd-label-hint {
  font-size: .71rem;
  color: var(--teal);
  font-weight: 700;
  letter-spacing: .04em;
  margin-bottom: 7px;
  display: flex;
  align-items: center;
  gap: 6px;
}
  `;
  document.head.appendChild(style);
})();


// ═══════════════════════════════════════════════════════════════════════
// OVERRIDE dlgAddEmp — show Workday picker or plain inputs depending on dept
// ═══════════════════════════════════════════════════════════════════════
const _origDlgAddEmp = window.dlgAddEmp;

window.dlgAddEmp = function() {
  if (!_isWorkday()) {
    // Non-Workday user → original dialog untouched
    _origDlgAddEmp();
    return;
  }

  // Workday user → custom dialog with multiselect
  openDlg(`
<div class="dlg-title">Add Employee
  <span class="badge b-teal" style="margin-left:8px;font-size:.7rem;vertical-align:middle">Workday</span>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Full Name *</label>
    <input id="de-n" class="form-input" placeholder="John Doe"/>
  </div>
  <div class="form-group">
    <label class="form-label">Email</label>
    <input id="de-e" type="email" class="form-input" placeholder="john@co.com"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Employee ID</label>
    <input id="de-id" class="form-input" placeholder="EMP001"/>
  </div>
  <div class="form-group">
    <label class="form-label">Department *</label>
    <select id="de-d" class="form-select">
      ${DB.getDepts().map(d => `<option ${d === uDept() ? 'selected' : ''}>${d}</option>`).join('')}
    </select>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Designation / Band *</label>
    <input id="de-b" class="form-input" placeholder="B2, Senior Engineer, L4…" list="band-list"/>
    <datalist id="band-list">
      ${BAND.ORDER.map(b => `<option value="${b}">`).join('')}
    </datalist>
    <div class="band-explain" style="margin-top:5px">
      ${BAND.ORDER.map(b => `<span class="band-pill ${BAND.getBandClass(b)}">${b}</span>`).join('')}
    </div>
  </div>
  <div class="form-group">
    <label class="form-label">Experience (years)</label>
    <input id="de-exp" type="number" class="form-input" placeholder="5" min="0"/>
  </div>
</div>

<div class="form-group">
  <label class="form-label">Location</label>
  <input id="de-loc" class="form-input" placeholder="Hyderabad, Bangalore, Remote…"/>
</div>

<!-- ── Workday Skill Multiselect ── -->
<div class="form-group">
  <div class="wd-label-hint">
    <span>🔷</span>
    <span>Workday Skills — select all that apply</span>
    <span style="color:var(--text3);font-weight:400">(tap to toggle · Other for custom)</span>
  </div>
  ${_buildWorkdaySkillPicker('de-wd-skills', '')}
</div>

<!-- Secondary skills: plain text still useful for certs, tools etc -->
<div class="form-group">
  <label class="form-label">Secondary / Additional Skills
    <span style="color:var(--text3);font-weight:400">(certifications, tools, soft skills…)</span>
  </label>
  <input id="de-sk2" class="form-input" placeholder="Workday Pro, Excel, Agile…"/>
</div>

<div>
  <label class="form-label">Custom Fields</label>
  <div id="de-ex"></div>
  <button class="btn btn-xs btn-ghost" style="margin-top:5px" onclick="addDynField('de-ex')">+ Field</button>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal"  onclick="_wdSaveAddEmp()">Save Employee</button>
</div>`);
};


// ── Save handler for Workday Add Employee ─────────────────────────────
function _wdSaveAddEmp() {
  const name = document.getElementById('de-n')?.value.trim();
  const dept = document.getElementById('de-d')?.value;
  if (!name || !dept) return toast('Name and Department are required', 'err');

  const skills = _getWdSkills('de-wd-skills');
  if (!skills) return toast('Please select at least one Workday skill', 'warn');

  const rawBand = document.getElementById('de-b')?.value.trim();

  DB.addEmployee({
    name,
    email:          document.getElementById('de-e')?.value.trim(),
    employeeId:     document.getElementById('de-id')?.value.trim(),
    department:     dept,
    designation:    rawBand,
    _normalizedBand: BAND.normalize(rawBand) || rawBand,
    experienceYears: document.getElementById('de-exp')?.value.trim(),
    location:       document.getElementById('de-loc')?.value.trim(),
    skills,                                         // from multiselect
    secondarySkills: document.getElementById('de-sk2')?.value.trim(),
    ...getDynFields('de-ex'),
  });

  closeDlg();
  renderEmps();
  toast(`Employee added with ${skills.split(',').length} Workday skill${skills.split(',').length > 1 ? 's' : ''} ✓`, 'ok');
}


// ═══════════════════════════════════════════════════════════════════════
// OVERRIDE dlgAddReq — show Workday picker only for Workday dept user
// ═══════════════════════════════════════════════════════════════════════
const _origDlgAddReq = window.dlgAddReq;

window.dlgAddReq = function() {
  if (!_isWorkday()) {
    // Non-Workday user → original dialog untouched
    _origDlgAddReq();
    return;
  }

  // Workday user → custom dialog with multiselect for required skills
  openDlg(`
<div class="dlg-title">New Requirement
  <span class="badge b-teal" style="margin-left:8px;font-size:.7rem;vertical-align:middle">Workday</span>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Role / Title *</label>
    <input id="nr-r" class="form-input" placeholder="Workday HCM Consultant"/>
  </div>
  <div class="form-group">
    <label class="form-label">Priority</label>
    <select id="nr-p" class="form-select">
      <option>High</option><option selected>Medium</option><option>Low</option>
    </select>
  </div>
</div>

<!-- ── Workday Required Skills Multiselect ── -->
<div class="form-group">
  <div class="wd-label-hint">
    <span>🔷</span>
    <span>Required Workday Skills — select all that apply</span>
    <span style="color:var(--text3);font-weight:400">(tap to toggle · Other for custom)</span>
  </div>
  ${_buildWorkdaySkillPicker('nr-wd-skills', '')}
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Min Experience (years)</label>
    <input id="nr-exp" type="number" class="form-input" placeholder="3" min="0" step="0.5"/>
  </div>
  <div class="form-group">
    <label class="form-label">Required Band</label>
    <select id="nr-b" class="form-select">
      <option value="">Any Band</option>
      ${BAND.ORDER.map(b => `<option value="${b}">${b}</option>`).join('')}
    </select>
    <div class="band-explain" style="margin-top:5px">
      ${BAND.ORDER.map(b => `<span class="band-pill ${BAND.getBandClass(b)}">${b}</span>`).join('')}
    </div>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Location</label>
    <input id="nr-loc" class="form-input" placeholder="Hyderabad, Remote…"/>
  </div>
  <div class="form-group">
    <label class="form-label">Headcount</label>
    <input id="nr-hc" type="number" class="form-input" value="1" min="1"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Department</label>
    <select id="nr-d" class="form-select">
      ${DB.getDepts().map(d => `<option ${d === uDept() ? 'selected' : ''}>${d}</option>`).join('')}
    </select>
  </div>
  <div class="form-group" style="display:flex;align-items:center;gap:10px;padding-top:24px">
    <input type="checkbox" id="nr-fresh" style="width:16px;height:16px;cursor:pointer"/>
    <label for="nr-fresh" style="font-size:.84rem;cursor:pointer;color:var(--text2)">
      🎓 Freshers only (A1/A2)
    </label>
  </div>
</div>

<div class="form-group">
  <label class="form-label">Description / JD Notes</label>
  <textarea id="nr-desc" class="form-textarea"
    placeholder="Module-specific context, certifications, deployment experience…"></textarea>
</div>

<div>
  <label class="form-label">Custom Fields</label>
  <div id="nr-ex"></div>
  <button class="btn btn-xs btn-ghost" style="margin-top:6px" onclick="addDynField('nr-ex')">+ Field</button>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal"  onclick="_wdSaveAddReq()">Save Requirement</button>
</div>`);
};


// ── Save handler for Workday Add Requirement ──────────────────────────
function _wdSaveAddReq() {
  const role = document.getElementById('nr-r')?.value.trim();
  if (!role) return toast('Role / Title is required', 'err');

  const skills = _getWdSkills('nr-wd-skills');
  if (!skills) return toast('Please select at least one required Workday skill', 'warn');

  DB.addRequirement({
    role,
    priority:        document.getElementById('nr-p').value,
    skills,                                          // from multiselect
    experienceYears: document.getElementById('nr-exp').value.trim(),
    designation:     document.getElementById('nr-b').value.trim(),
    location:        document.getElementById('nr-loc').value.trim(),
    headcount:       document.getElementById('nr-hc').value.trim(),
    department:      document.getElementById('nr-d').value,
    forFreshers:     document.getElementById('nr-fresh').checked,
    description:     document.getElementById('nr-desc').value.trim(),
    ...getDynFields('nr-ex'),
  });

  closeDlg();
  renderReqs();
  toast(`Requirement saved with ${skills.split(',').length} required skill${skills.split(',').length > 1 ? 's' : ''} ✓`, 'ok');
}


// ═══════════════════════════════════════════════════════════════════════
// WORKDAY SKILL PICKER IN EDIT DIALOGS (dlgEditEmp)
// When editing an existing Workday employee, replace the skills textarea
// with the picker pre-populated with their existing skills.
// ═══════════════════════════════════════════════════════════════════════
const _origDlgEditEmp = window.dlgEditEmp;

window.dlgEditEmp = function(id) {
  if (!_isWorkday()) {
    _origDlgEditEmp(id);
    return;
  }

  const e = DB.getEmployees().find(x => x.id === id);
  if (!e) return;

  openDlg(`
<div class="dlg-title">Edit: ${e.name}
  <span class="badge b-teal" style="margin-left:8px;font-size:.7rem;vertical-align:middle">Workday</span>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Name</label>
    <input id="ee-n" class="form-input" value="${e.name || ''}"/>
  </div>
  <div class="form-group">
    <label class="form-label">Email</label>
    <input id="ee-e" class="form-input" value="${e.email || ''}"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Designation / Band</label>
    <input id="ee-b" class="form-input" value="${e.designation || ''}" list="band-list2"
           placeholder="B2, Senior…"/>
    <datalist id="band-list2">
      ${BAND.ORDER.map(b => `<option value="${b}">`).join('')}
    </datalist>
  </div>
  <div class="form-group">
    <label class="form-label">Experience (yrs)</label>
    <input id="ee-exp" type="number" class="form-input" value="${e.experienceYears || ''}"/>
  </div>
</div>

<div class="form-row">
  <div class="form-group">
    <label class="form-label">Location</label>
    <input id="ee-loc" class="form-input" value="${e.location || ''}"/>
  </div>
  <div class="form-group">
    <label class="form-label">Department</label>
    <input id="ee-d" class="form-input" value="${e.department || ''}"/>
  </div>
</div>

<!-- ── Workday Skill Multiselect (pre-populated) ── -->
<div class="form-group">
  <div class="wd-label-hint">
    <span>🔷</span>
    <span>Workday Skills</span>
    <span style="color:var(--text3);font-weight:400">(tap to toggle)</span>
  </div>
  ${_buildWorkdaySkillPicker('ee-wd-skills', e.skills || '')}
</div>

<div class="form-group">
  <label class="form-label">Secondary Skills</label>
  <input id="ee-sk2" class="form-input" value="${e.secondarySkills || ''}"/>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal"  onclick="_wdSaveEditEmp('${id}')">Update</button>
</div>`);
};

function _wdSaveEditEmp(id) {
  const skills  = _getWdSkills('ee-wd-skills');
  const rawBand = document.getElementById('ee-b')?.value.trim();

  DB.updateEmployee(id, {
    name:            document.getElementById('ee-n').value.trim(),
    email:           document.getElementById('ee-e').value.trim(),
    designation:     rawBand,
    _normalizedBand: BAND.normalize(rawBand) || rawBand,
    experienceYears: document.getElementById('ee-exp').value.trim(),
    location:        document.getElementById('ee-loc').value.trim(),
    department:      document.getElementById('ee-d').value.trim(),
    skills,
    secondarySkills: document.getElementById('ee-sk2').value.trim(),
  });

  closeDlg();
  renderEmps();
  toast('Employee updated ✓', 'ok');
}

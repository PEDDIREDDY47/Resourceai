'use strict';
// ═══════════════════════════════════════════════════════════════════════
// IMPORTER.JS — Complete data import engine + full Excel viewer tab
// ═══════════════════════════════════════════════════════════════════════

// ── State ─────────────────────────────────────────────────────────────
const BUFS = { skills: null, alloc: null, req: null };
const MAPS = { skills: null, alloc: null, req: null };
let _importRunning = false;
let _reqSeq = 0;

// ─── Labels for each file type ────────────────────────────────────────
const TYPE_META = {
  skills: { label: '📊 Skills / Employees', icon: '📋', color: 'var(--teal)' },
  alloc: { label: '🎯 Allocations', icon: '🎯', color: 'var(--blue)' },
  req: { label: '📝 Requirements', icon: '📝', color: 'var(--amber2)' },
};

// ═══════════════════════════════════════════════════════════════════════
// IMPORT PAGE  —  three upload zones + full viewer below
// ═══════════════════════════════════════════════════════════════════════
function pageUpload() {
  return `
<div class="page-hdr">
  <div class="page-hdr-left">
    <h1>Data Import</h1>
    <p>AI column mapping — any header format · all skill columns merged · fuzzy name matching</p>
  </div>
</div>

<div class="alert a-info" style="margin-bottom:16px">
  💡 Upload your Skills and Allocation files together — they are merged automatically by employee name.
  After clicking <strong>Import Now</strong> you will be redirected to the Dashboard.
  Use the <strong>👁 View Full Data</strong> tab to inspect every column before importing.
</div>

<!-- ── Upload zones ── -->
<div class="grid-3" style="margin-bottom:18px">

  <div class="card">
    <div style="font-weight:800;margin-bottom:3px">📊 Skills / Employee Matrix</div>
    <div style="color:var(--text2);font-size:.79rem;margin-bottom:11px">
      Any headers: Name, Band, Experience, Location, Skills (all columns merged)
    </div>
    <div class="upload-zone" id="uz-sk"
      ondragover="dzO(event,'uz-sk')" ondragleave="dzL('uz-sk')"
      ondrop="dzD(event,'uz-sk','skills')">
      <input type="file" accept=".xlsx,.xls,.csv" onchange="fileSel(event,'skills')"/>
      <div class="uz-icon">📋</div>
      <div class="uz-title">Drop Skills File</div>
      <div class="uz-sub">Excel or CSV — any header format</div>
    </div>
    <div id="up-psk" style="margin-top:9px"></div>
  </div>

  <div class="card">
    <div style="font-weight:800;margin-bottom:3px">🎯 Allocation Data</div>
    <div style="color:var(--text2);font-size:.79rem;margin-bottom:11px">
      Any headers: Employee, Project, %, Start Date, End Date
    </div>
    <div class="upload-zone" id="uz-al"
      ondragover="dzO(event,'uz-al')" ondragleave="dzL('uz-al')"
      ondrop="dzD(event,'uz-al','alloc')">
      <input type="file" accept=".xlsx,.xls,.csv" onchange="fileSel(event,'alloc')"/>
      <div class="uz-icon">🎯</div>
      <div class="uz-title">Drop Allocation File</div>
      <div class="uz-sub">Excel or CSV — any header format</div>
    </div>
    <div id="up-pal" style="margin-top:9px"></div>
  </div>

  <div class="card">
    <div style="font-weight:800;margin-bottom:3px">📝 Requirements</div>
    <div style="color:var(--text2);font-size:.79rem;margin-bottom:11px">
      Any headers: Role, Skills, Band, Experience, Headcount
    </div>
    <div class="upload-zone" id="uz-rq"
      ondragover="dzO(event,'uz-rq')" ondragleave="dzL('uz-rq')"
      ondrop="dzD(event,'uz-rq','req')">
      <input type="file" accept=".xlsx,.xls,.csv" onchange="fileSel(event,'req')"/>
      <div class="uz-icon">📝</div>
      <div class="uz-title">Drop Requirements File</div>
      <div class="uz-sub">Excel or CSV — any header format</div>
    </div>
    <div id="up-prq" style="margin-top:9px"></div>
  </div>
</div>

<!-- ── Import action bar ── -->
<div id="up-bar" style="display:none;margin-bottom:16px" class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:13px">
    <div>
      <div style="font-weight:700;margin-bottom:3px">Ready to Import</div>
      <div id="up-sum" style="color:var(--text2);font-size:.84rem"></div>
    </div>
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:.84rem;color:var(--text2)">
        <input type="checkbox" id="up-clr" checked/> Replace existing data
      </label>
      <button class="btn btn-red btn-sm" onclick="resetUp()">✕ Reset</button>
      <button class="btn btn-teal" id="import-btn" onclick="runImport()">⚡ Import Now</button>
    </div>
  </div>
</div>

<!-- ── Log output ── -->
<div id="up-log" style="margin-top:12px"></div>

<!-- ── Full data viewer (rendered below upload after file is parsed) ── -->
<div id="up-viewer" style="margin-top:24px"></div>`;
}

// ═══════════════════════════════════════════════════════════════════════
// DRAG / DROP / FILE SELECTION
// ═══════════════════════════════════════════════════════════════════════
function dzO(e, id) { e.preventDefault(); document.getElementById(id)?.classList.add('dz-over'); }
function dzL(id) { document.getElementById(id)?.classList.remove('dz-over'); }
function dzD(e, id, type) {
  e.preventDefault(); dzL(id);
  const f = e.dataTransfer.files[0]; if (f) processFile(f, type);
}
function fileSel(e, type) { const f = e.target.files[0]; if (f) processFile(f, type); }

async function processFile(file, type) {
  const pId = `up-p${type === 'skills' ? 'sk' : type === 'alloc' ? 'al' : 'rq'}`;
  const prev = document.getElementById(pId);
  if (prev) prev.innerHTML = `
    <div style="display:flex;align-items:center;gap:7px;color:var(--text2);font-size:.81rem">
      <div class="spin" style="width:15px;height:15px"></div>Parsing ${file.name}…
    </div>`;

  try {
    const rows = await XL.parse(file);
    if (!rows.length) throw new Error('File is empty or has no data rows');

    BUFS[type] = { rows, name: file.name };

    const schema = type === 'skills' ? ColMapper.SKILL
      : type === 'alloc' ? ColMapper.ALLOC : ColMapper.REQ;
    const headers = Object.keys(rows[0]);
    const mapping = ColMapper.mapHeaders(headers, schema);
    const unmapped = ColMapper.unmapped(headers, mapping);
    MAPS[type] = mapping;

    const mappedHtml = Object.entries(mapping)
      .map(([k, v]) => `<span class="chip"><em style="color:var(--text3)">${v}</em> → <strong style="color:var(--teal)">${k}</strong></span>`)
      .join('');

    const unmappedHtml = unmapped.length
      ? `<div style="margin-top:6px;font-size:.72rem;color:var(--amber2)">
           ⚠ ${unmapped.length} extra column${unmapped.length > 1 ? 's' : ''} preserved as custom fields:
           ${unmapped.map(u => `<span class="chip">${u}</span>`).join('')}
         </div>` : '';

    if (prev) prev.innerHTML = `
      <div class="alert a-ok" style="margin-bottom:7px">
        ✓ <strong>${rows.length}</strong> rows · <em style="color:var(--text3)">${file.name}</em>
      </div>
      <div style="line-height:1.9;margin-bottom:4px">${mappedHtml}</div>
      ${unmappedHtml}
      <button class="btn btn-xs btn-teal" style="margin-top:9px"
        onclick="renderFullViewer('${type}')">
        👁 View Full Data →
      </button>`;

    updateUpBar();
    // Auto-render viewer for this file
    renderFullViewer(type);

  } catch (err) {
    if (prev) prev.innerHTML = `<div class="alert a-err">❌ ${err.message}</div>`;
    BUFS[type] = null;
    console.error('[Import parse error]', type, err);
  }
}

function updateUpBar() {
  const bar = document.getElementById('up-bar');
  const has = Object.values(BUFS).some(v => v !== null);
  if (bar) bar.style.display = has ? 'block' : 'none';
  const parts = [];
  if (BUFS.skills) parts.push(`${BUFS.skills.rows.length} employees`);
  if (BUFS.alloc) parts.push(`${BUFS.alloc.rows.length} allocations`);
  if (BUFS.req) parts.push(`${BUFS.req.rows.length} requirements`);
  const s = document.getElementById('up-sum');
  if (s) s.textContent = parts.join(' · ');
}

function resetUp() {
  ['skills', 'alloc', 'req'].forEach(t => { BUFS[t] = null; MAPS[t] = null; });
  ['up-psk', 'up-pal', 'up-prq'].forEach(id => {
    const el = document.getElementById(id); if (el) el.innerHTML = '';
  });
  ['up-bar', 'up-log', 'up-viewer'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { if (id === 'up-bar') el.style.display = 'none'; else el.innerHTML = ''; }
  });
  _importRunning = false;
  const btn = document.getElementById('import-btn');
  if (btn) { btn.disabled = false; btn.textContent = '⚡ Import Now'; }
}

// ═══════════════════════════════════════════════════════════════════════
// FULL DATA VIEWER  —  tabbed, searchable, filterable, copyable
// Shows ALL columns, highlights mapped vs extra, supports search
// ═══════════════════════════════════════════════════════════════════════
function renderFullViewer(activeType) {
  const viewer = document.getElementById('up-viewer');
  if (!viewer) return;

  // Which tabs have data
  const available = ['skills', 'alloc', 'req'].filter(t => BUFS[t]);
  if (!available.length) { viewer.innerHTML = ''; return; }

  // Default to the tab that was just uploaded
  if (!available.includes(activeType)) activeType = available[0];

  // Build tab strip
  const tabStrip = available.map(t => {
    const m = TYPE_META[t];
    const isActive = t === activeType;
    return `<button class="tab-btn ${isActive ? 'active' : ''}"
      id="vtab-${t}"
      onclick="renderFullViewer('${t}')"
      style="${isActive ? 'color:var(--teal);border-bottom-color:var(--teal)' : ''}">
      ${m.label}
      <span class="badge ${t === 'skills' ? 'b-teal' : t === 'alloc' ? 'b-blue' : 'b-amber'}"
            style="margin-left:5px">${BUFS[t].rows.length}</span>
    </button>`;
  }).join('');

  const buf = BUFS[activeType];
  const mapping = MAPS[activeType] || {};
  const headers = Object.keys(buf.rows[0] || {});
  const revMap = Object.fromEntries(Object.entries(mapping).map(([k, v]) => [v, k]));
  const unmapped = ColMapper.unmapped(headers, mapping);
  const mapped = headers.filter(h => revMap[h]);
  const meta = TYPE_META[activeType];

  viewer.innerHTML = `
<div class="card" style="padding:0;overflow:hidden">

  <!-- ── Viewer header ── -->
  <div style="padding:16px 20px 0;border-bottom:1px solid var(--border)">
    <div style="display:flex;justify-content:space-between;align-items:center;
                flex-wrap:wrap;gap:10px;margin-bottom:12px">
      <div>
        <div style="font-weight:800;font-size:1rem">👁 Uploaded Data Viewer</div>
        <div style="font-size:.77rem;color:var(--text3);margin-top:2px">
          View all columns · Teal = mapped · Gray = extra (still saved) ·
          Click any cell to copy · Use values to fill filter fields
        </div>
      </div>
      <div style="display:flex;gap:7px;align-items:center">
        <button class="btn btn-xs btn-ghost" onclick="document.getElementById('up-viewer').innerHTML=''">✕ Close Viewer</button>
      </div>
    </div>

    <!-- File tabs -->
    <div class="tab-strip" style="margin-bottom:0;border-bottom:none">
      ${tabStrip}
    </div>
  </div>

  <!-- ── Stats bar ── -->
  <div style="padding:10px 20px;background:var(--bg3);border-bottom:1px solid var(--border);
              display:flex;gap:20px;flex-wrap:wrap;font-size:.77rem">
    <span>📁 <strong>${buf.name}</strong></span>
    <span>📋 <strong>${buf.rows.length}</strong> rows</span>
    <span>✅ <strong>${mapped.length}</strong> mapped columns</span>
    <span style="color:var(--amber2)">📎 <strong>${unmapped.length}</strong> extra columns preserved</span>
  </div>

  <!-- ── Search + filter bar ── -->
  <div style="padding:12px 20px;border-bottom:1px solid var(--border);
              display:flex;gap:9px;flex-wrap:wrap;align-items:center">
    <input id="viewer-search" type="text" class="fi-text" style="min-width:220px;flex:1"
      placeholder="🔍 Search across all columns…"
      oninput="filterViewerTable('${activeType}')"/>
    <select id="viewer-col-filter" class="fi" onchange="filterViewerTable('${activeType}')">
      <option value="">Filter by column…</option>
      ${headers.map(h => `<option value="${h}">${h}${revMap[h] ? ' (→' + revMap[h] + ')' : ''}</option>`).join('')}
    </select>
    <input id="viewer-col-val" class="fi-text" style="max-width:160px"
      placeholder="Column value…"
      oninput="filterViewerTable('${activeType}')"/>
    <button class="btn btn-xs btn-ghost"
      onclick="document.getElementById('viewer-search').value='';
               document.getElementById('viewer-col-filter').value='';
               document.getElementById('viewer-col-val').value='';
               filterViewerTable('${activeType}')">
      ✕ Clear
    </button>
    <span id="viewer-count" style="font-size:.76rem;color:var(--text3);margin-left:4px">
      ${buf.rows.length} rows
    </span>
  </div>

  <!-- ── Column legend ── -->
  <div style="padding:10px 20px;border-bottom:1px solid var(--border);
              display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <span style="font-size:.71rem;color:var(--text3);font-weight:700;
                 text-transform:uppercase;letter-spacing:.06em">Mapping:</span>
    ${Object.entries(mapping).map(([canon, orig]) =>
    `<span class="chip chip-teal" style="font-size:.69rem">
        <em style="color:var(--text3)">${orig}</em>
        <span style="margin:0 3px;color:var(--border3)">→</span>
        <strong>${canon}</strong>
      </span>`
  ).join('')}
    ${unmapped.length ? `
      <span style="font-size:.71rem;color:var(--amber2);margin-left:4px">
        Extra: ${unmapped.map(h => `<span class="chip" style="font-size:.67rem">${h}</span>`).join('')}
      </span>` : ''}
  </div>

  <!-- ── Table ── -->
  <div style="overflow:auto;max-height:420px" id="viewer-table-wrap">
    ${_buildViewerTable(activeType, buf.rows, headers, revMap)}
  </div>

  <!-- ── Extra columns detail (expandable) ── -->
  ${unmapped.length ? `
  <div style="padding:12px 20px;border-top:1px solid var(--border);background:var(--bg3)">
    <div style="font-weight:700;font-size:.84rem;margin-bottom:5px">
      📎 Extra Columns (${unmapped.length}) — stored as custom fields on each record
    </div>
    <div style="font-size:.77rem;color:var(--text2);margin-bottom:8px">
      These did not match any standard field. They are saved alongside each record and
      visible in the employee / requirement detail views.
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px">
      ${unmapped.map(h => {
    // Show sample values from first 3 non-empty rows
    const samples = buf.rows.slice(0, 5)
      .map(r => String(r[h] || '').trim()).filter(Boolean).slice(0, 3);
    return `<div style="background:var(--surface);border:1px solid var(--border);
                            border-radius:var(--r-sm);padding:9px 11px">
          <div style="font-weight:700;font-size:.76rem;color:var(--amber2);margin-bottom:4px">${h}</div>
          <div style="font-size:.71rem;color:var(--text3)">
            ${samples.map(s => `<div style="overflow:hidden;text-overflow:ellipsis;
                                         white-space:nowrap;max-width:170px"
                                  title="${s}">${s}</div>`).join('')}
            ${!samples.length ? '<em>empty</em>' : ''}
          </div>
        </div>`;
  }).join('')}
    </div>
  </div>` : ''}

</div>`;
}

// Build the scrollable data table
function _buildViewerTable(type, rows, headers, revMap, filterText = '', filterCol = '', filterVal = '') {
  // Apply filters
  let filtered = rows;
  if (filterText) {
    const q = filterText.toLowerCase();
    filtered = filtered.filter(row =>
      Object.values(row).some(v => String(v || '').toLowerCase().includes(q))
    );
  }
  if (filterCol && filterVal) {
    const q = filterVal.toLowerCase();
    filtered = filtered.filter(row => String(row[filterCol] || '').toLowerCase().includes(q));
  }

  const shown = filtered.slice(0, 200);

  return `
<table style="width:100%;border-collapse:collapse;font-size:.77rem">
  <thead>
    <tr>
      <th style="background:var(--bg3);padding:8px 10px;font-size:.64rem;
                 text-transform:uppercase;letter-spacing:.05em;color:var(--text3);
                 position:sticky;top:0;z-index:2;white-space:nowrap;
                 border-bottom:2px solid var(--border)">#</th>
      ${headers.map(h => {
    const canon = revMap[h];
    const isMapped = !!canon;
    const isSkill = canon && canon.toLowerCase().includes('skill');
    return `<th
          style="background:${isMapped ? 'rgba(0,200,180,.10)' : 'var(--bg3)'};
                 padding:8px 10px;text-align:left;font-size:.64rem;
                 text-transform:uppercase;letter-spacing:.05em;
                 color:${isMapped ? 'var(--teal)' : 'var(--text3)'};
                 white-space:nowrap;position:sticky;top:0;z-index:2;
                 border-bottom:2px solid var(--border);cursor:pointer"
          title="${isMapped ? 'Mapped → ' + canon : 'Extra column (preserved)'}"
          onclick="document.getElementById('viewer-col-filter').value='${h}';filterViewerTable('${type}')">
          ${h}
          ${isMapped ? `<div style="font-size:.58rem;color:var(--text3);font-weight:400;
                                   margin-top:1px">→ ${canon}</div>` : ''}
        </th>`;
  }).join('')}
    </tr>
  </thead>
  <tbody>
    ${shown.map((row, i) => `
    <tr style="border-bottom:1px solid var(--border);transition:background .1s"
      onmouseenter="this.style.background='rgba(0,200,180,.03)'"
      onmouseleave="this.style.background=''">
      <td style="padding:6px 10px;color:var(--text3);font-size:.68rem;
                 position:sticky;left:0;background:var(--surface)">${i + 1}</td>
      ${headers.map(h => {
    const val = row[h];
    const display = val !== null && val !== undefined && String(val).trim() !== ''
      ? String(val).trim() : '';
    const canon = revMap[h];
    const isMapped = !!canon;
    const safeVal = display.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '&quot;');
    const shortVal = display.length > 35 ? display.slice(0, 35) + '…' : display;
    return `<td
          style="padding:6px 10px;max-width:200px;overflow:hidden;
                 text-overflow:ellipsis;white-space:nowrap;
                 background:${isMapped ? 'rgba(0,200,180,.018)' : 'transparent'};
                 cursor:pointer;vertical-align:middle"
          title="${display}"
          onclick="_viewerCellClick('${safeVal}')">
          ${display
        ? `<span style="color:${isMapped ? 'var(--text)' : 'var(--text2)'}">${shortVal}</span>`
        : `<span style="color:var(--text3);font-size:.68rem">—</span>`}
        </td>`;
  }).join('')}
    </tr>`).join('')}
    ${filtered.length > 200 ? `
    <tr>
      <td colspan="${headers.length + 1}"
        style="padding:12px;text-align:center;color:var(--text3);font-size:.78rem;
               border-top:1px solid var(--border)">
        Showing 200 of ${filtered.length} rows · Use the search to narrow results
      </td>
    </tr>` : ''}
    ${filtered.length === 0 ? `
    <tr>
      <td colspan="${headers.length + 1}"
        style="padding:28px;text-align:center;color:var(--text3)">
        No rows match your filter
      </td>
    </tr>` : ''}
  </tbody>
</table>`;
}

// Filter the viewer table live as user types
function filterViewerTable(type) {
  const buf = BUFS[type]; if (!buf) return;
  const mapping = MAPS[type] || {};
  const headers = Object.keys(buf.rows[0] || {});
  const revMap = Object.fromEntries(Object.entries(mapping).map(([k, v]) => [v, k]));
  const search = document.getElementById('viewer-search')?.value || '';
  const filterCol = document.getElementById('viewer-col-filter')?.value || '';
  const filterVal = document.getElementById('viewer-col-val')?.value || '';

  const wrap = document.getElementById('viewer-table-wrap');
  if (wrap) wrap.innerHTML = _buildViewerTable(type, buf.rows, headers, revMap, search, filterCol, filterVal);

  // Update count
  let count = buf.rows.length;
  if (search || (filterCol && filterVal)) {
    let filtered = buf.rows;
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(r => Object.values(r).some(v => String(v || '').toLowerCase().includes(q)));
    }
    if (filterCol && filterVal) {
      const q = filterVal.toLowerCase();
      filtered = filtered.filter(r => String(r[filterCol] || '').toLowerCase().includes(q));
    }
    count = filtered.length;
  }
  const countEl = document.getElementById('viewer-count');
  if (countEl) countEl.textContent = `${count} of ${buf.rows.length} rows`;
}

// Click a cell — copies value AND fills search box
function _viewerCellClick(val) {
  if (!val) return;
  navigator.clipboard?.writeText(val);
  const searchEl = document.getElementById('viewer-search');
  // Only auto-fill if search is currently empty
  if (searchEl && !searchEl.value) {
    searchEl.value = val;
    // Trigger filter on whichever tab is active
    const activeType = ['skills', 'alloc', 'req'].find(t => BUFS[t] && document.getElementById(`vtab-${t}`)?.classList.contains('active')) || 'skills';
    filterViewerTable(activeType);
  }
  toast(`Copied: ${val.slice(0, 40)}`, 'info', 1500);
}

// ═══════════════════════════════════════════════════════════════════════
// MAIN IMPORT ENGINE
// ═══════════════════════════════════════════════════════════════════════
function runImport() {
  if (_importRunning) { toast('Import already running…', 'warn'); return; }
  _importRunning = true;

  const btn = document.getElementById('import-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Importing…'; }

  const log = document.getElementById('up-log');
  const clr = document.getElementById('up-clr')?.checked;
  const myDept = (typeof uDept === 'function') ? uDept() : (CU?.department || '');
  const isAdmin = CU?.role === 'admin';
  const lines = [];
  const errors = [];

  // ── Step 1: Clear existing selectively ──────────────────────────────
  if (clr) {
    if (BUFS.skills) {
      DB.clearEmployees(isAdmin ? null : myDept);
      DB.clearAllocs(isAdmin ? null : myDept);
      lines.push('🗑️ Cleared existing employee and allocation data.');
    }
    if (BUFS.alloc) {
      if (!BUFS.skills) {
        DB.clearAllocs(isAdmin ? null : myDept);
        lines.push('🗑️ Cleared existing allocation data.');
      }
    }
    if (BUFS.req) {
      if (isAdmin) {
        DB._s('requirements', []);
      } else {
        DB._s('requirements', DB.getRequirements(null).filter(r => r.department !== myDept));
      }
      lines.push('🗑️ Cleared existing requirements.');
    }
  }

  // ── Step 2: Build empMap from Skills file ───────────────────────────
  const empMap = {};

  if (BUFS.skills) {
    const { rows } = BUFS.skills;
    const mapping = ColMapper.mapHeaders(Object.keys(rows[0] || {}), ColMapper.SKILL);

    rows.forEach((row, idx) => {
      try {
        const m = ColMapper.transform(row, mapping);
        if (!m.name) return;
        const skills = ColMapper.mergeAllSkillColumns(row, mapping);
        const key = ColMapper.nameKey(m.name);
        empMap[key] = { ...m, skills, secondarySkills: '', _allocs: [], _rowIdx: idx + 2 };
      } catch (err) { errors.push(`Skills row ${idx + 2}: ${err.message}`); }
    });
    lines.push(`📊 Parsed <strong>${Object.keys(empMap).length}</strong> employees from Skills file.`);
  }

  // ── Step 3: Merge allocations ───────────────────────────────────────
  let orphans = 0;

  if (BUFS.alloc) {
    const { rows } = BUFS.alloc;
    const mapping = ColMapper.mapHeaders(Object.keys(rows[0] || {}), ColMapper.ALLOC);

    rows.forEach((row, idx) => {
      try {
        const m = ColMapper.transform(row, mapping);
        const rawId = m.employeeId || m.name || '';
        if (!rawId) return;
        const proj = m.projectName ? m.projectName.trim() : '';
        if (!proj) return;

        const pct = ColMapper.parsePercent(m.percentage);
        const start = ColMapper.parseDate(m.startDate);
        const end = ColMapper.parseDate(m.endDate);
        const isInt = /^(y|yes|true|1|internal|bench|non.?billable)$/i.test(String(m.isInternal || ''))
          || AI.isInternal(proj);

        const entry = {
          projectName: proj,
          percentage: pct,
          startDate: start,
          endDate: end,
          isInternal: isInt,
          ...Object.fromEntries(Object.entries(m).filter(([k]) => k.startsWith('_extra_')))
        };
        const key = ColMapper.nameKey(rawId);

        if (empMap[key]) { empMap[key]._allocs.push(entry); return; }

        // Fuzzy fallback
        const fuzzy = Object.keys(empMap).find(k =>
          k.includes(key) || key.includes(k) || _lev(k, key) <= 2
        );
        if (fuzzy) { empMap[fuzzy]._allocs.push(entry); return; }

        // Stub employee from alloc file
        empMap[key] = { name: rawId, department: myDept, skills: '', _allocs: [entry] };
        orphans++;
      } catch (err) { errors.push(`Alloc row ${idx + 2}: ${err.message}`); }
    });

    lines.push(`🎯 Parsed <strong>${BUFS.alloc.rows.length}</strong> allocation rows.`);
    if (orphans > 0) lines.push(`⚠️ ${orphans} alloc rows had no matching employee — stubs created.`);
  }

  // ── Step 4: Save employees + allocations ────────────────────────────
  let ec = 0, ac = 0;

  for (const data of Object.values(empMap)) {
    if (!data.name) continue;
    try {
      const rawBand = data.designation || data.band || data.level || data.grade || '';
      const emp = DB.addEmployee({
        name: data.name,
        email: data.email || '',
        employeeId: data.employeeId || '',
        department: data.department || myDept,
        designation: rawBand,
        _normalizedBand: BAND.normalize(rawBand) || rawBand,
        experienceYears: data.experienceYears || '',
        location: data.location || '',
        skills: data.skills || '',
        secondarySkills: data.secondarySkills || '',
        isCertified: data.isCertified || '',
        ...Object.fromEntries(Object.entries(data).filter(([k]) => k.startsWith('_extra_'))),
      });
      ec++;
      for (const al of (data._allocs || [])) {
        if (!al.projectName) continue;
        try {
          const proj = DB.findOrCreateProj(al.projectName, emp.department);
          DB.addAllocation({
            employeeId: emp.id, projectId: proj.id, projectName: proj.name,
            isInternal: al.isInternal, percentage: al.percentage,
            startDate: al.startDate, endDate: al.endDate,
            ...Object.fromEntries(Object.entries(al).filter(([k]) => k.startsWith('_extra_')))
          });
          ac++;
        } catch (err) { errors.push(`Alloc for ${data.name}: ${err.message}`); }
      }
    } catch (err) { errors.push(`Saving ${data.name}: ${err.message}`); }
  }

  if (ec > 0) lines.push(`✅ Saved <strong>${ec}</strong> employees · <strong>${ac}</strong> allocations.`);

  // ── Step 5: Requirements ────────────────────────────────────────────
  if (BUFS.req) {
    try {
      const rc = _importReqRows(BUFS.req.rows, myDept);
      lines.push(rc > 0
        ? `✅ Saved <strong>${rc}</strong> requirements.`
        : `⚠️ Requirements file had no valid rows.`);
    } catch (err) { errors.push(`Requirements: ${err.message}`); }
  }

  if (!lines.length && !errors.length) lines.push('⚠️ Nothing imported — upload at least one file.');

  const errHtml = errors.length
    ? `<div class="alert a-warn" style="margin-top:8px;font-size:.79rem">
         ⚠ ${errors.length} warning${errors.length > 1 ? 's' : ''}:<br/>
         ${errors.slice(0, 5).map(e => `• ${e}`).join('<br/>')}
         ${errors.length > 5 ? `<br/>… +${errors.length - 5} more (see console)` : ''}
       </div>` : '';
  if (errors.length) console.warn('[Import warnings]', errors);

  if (log) log.innerHTML = `
    <div class="alert a-ok">${lines.join('<br/>')}</div>
    ${errHtml}
    <div style="display:flex;align-items:center;gap:10px;font-size:.84rem;
                color:var(--text2);margin-top:10px">
      <div class="spin"></div>Redirecting to Dashboard in 2 seconds…
    </div>`;

  // Clear buffers + hide bar
  BUFS.skills = null; BUFS.alloc = null; BUFS.req = null;
  MAPS.skills = null; MAPS.alloc = null; MAPS.req = null;
  const upBar = document.getElementById('up-bar');
  if (upBar) upBar.style.display = 'none';

  setTimeout(() => {
    _importRunning = false;
    navigateTo('dashboard');
    toast(`Import complete — ${ec} employees · ${ac} allocations`, 'ok', 5000);
  }, 2000);
}

// ── Requirements row importer ─────────────────────────────────────────
function _importReqRows(rows, myDept) {
  if (!rows || !rows.length) return 0;
  const mapping = ColMapper.mapHeaders(Object.keys(rows[0] || {}), ColMapper.REQ);
  let count = 0;

  rows.forEach((row, idx) => {
    try {
      const m = ColMapper.transform(row, mapping);
      const hasContent = Object.values(m).some(v => v && String(v).trim());
      if (!hasContent) return;

      const role = m.role || m.skills?.split(',')[0]?.trim() || '';
      if (!role && !m.skills && !m.description) return;

      const rawPri = String(m.priority || '').toLowerCase();
      const priority = rawPri.includes('high') ? 'High' : rawPri.includes('low') ? 'Low' : 'Medium';

      const rawStat = String(m.status || '').toLowerCase();
      const status = rawStat.includes('fulfilled') ? 'Fulfilled'
        : rawStat.includes('progress') ? 'In Progress'
          : rawStat.includes('cancel') ? 'Cancelled' : 'Open';

      _reqSeq++;
      const list = DB._g('requirements');
      list.push({
        id: 'req-' + Date.now() + '-' + _reqSeq,
        createdAt: new Date().toISOString(),
        role: role || 'Open Requirement',
        skills: m.skills || '',
        experienceYears: m.experienceYears || '',
        designation: m.designation || '',
        location: m.location || '',
        headcount: m.headcount || '1',
        priority, status,
        department: m.department || myDept,
        description: m.description || '',
        forFreshers: false,
        ...Object.fromEntries(Object.entries(m).filter(([k]) => k.startsWith('_extra_'))),
      });
      DB._s('requirements', list);
      count++;
    } catch (err) { console.warn(`[Req row ${idx + 2}]`, err.message); }
  });
  return count;
}

// Expose for requirements.js compatibility
function _importRequirements(buf, _ignored, myDept) {
  if (!buf || !buf.rows) return 0;
  return _importReqRows(buf.rows, myDept);
}

// ── Levenshtein distance ──────────────────────────────────────────────
function _lev(a, b) {
  if (a === b) return 0;
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  const dp = Array.from({ length: m + 1 }, (_, i) => Array.from({ length: n + 1 }, (_, j) => i ? j ? 0 : i : j));
  for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
    dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
  return dp[m][n];
}

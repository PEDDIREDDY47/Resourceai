'use strict';
// ═══════════════════════════════════════════════════════════════════════
// PASSWORD.JS — Secure password management
//
// Features:
//   1. Change Password dialog available to EVERY user (not just admin)
//      from the top-right user menu
//   2. Force-change on first login — admin default password triggers
//      a mandatory change dialog that cannot be skipped
//   3. Admin can reset any user's password from Admin Center → Users
//   4. Password strength meter with real-time feedback
//   5. Previous-password check so users cannot reuse their last password
//   6. All DB writes use SEC.hash — plain text never stored
// ═══════════════════════════════════════════════════════════════════════

// ── Force-change detection ────────────────────────────────────────────
// If the admin still has the default password, force a change on login.
// DEFAULT_ADMIN_HASH defined in patches.js

// _needsForcedChange defined in patches.js

// launchApp patch moved to patches.js

// ── Force-change dialog (cannot be dismissed) ─────────────────────────
function dlgForceChangePassword() {
  // Build the dialog manually so we can block the close button
  closeDlg(); // close any existing dialog first

  const ov = document.createElement('div');
  ov.className = 'dlg-overlay';
  ov.id = 'dlg-force-pwd';
  // No click-outside-to-close
  ov.innerHTML = `
<div class="dlg" style="max-width:460px">
  <div style="text-align:center;margin-bottom:18px">
    <div style="font-size:2rem;margin-bottom:8px">🔐</div>
    <div class="dlg-title" style="margin-bottom:4px">Change Your Password</div>
    <div style="font-size:.83rem;color:var(--text3);line-height:1.5">
      ${CU.mustChangePassword
        ? 'An administrator has reset your password. You must set a new one before continuing.'
        : 'You are using the default password. Please set a secure password to continue.'}
    </div>
  </div>

  <div id="fpwd-alert"></div>

  <div class="form-group">
    <label class="form-label">New Password *</label>
    <div class="pass-wrap">
      <input id="fp-new" type="password" class="form-input"
        placeholder="Min 8 characters, include numbers & symbols"
        oninput="_pwdStrength(this.value,'fp-bar','fp-lbl')"/>
      <button class="pass-toggle" type="button"
        onclick="togglePass('fp-new',this)">👁</button>
    </div>
    <div class="pass-strength"><div id="fp-bar" class="ps-fill" style="width:0%;background:var(--red)"></div></div>
    <div id="fp-lbl" style="font-size:.72rem;color:var(--text3);margin-top:3px"></div>
  </div>

  <div class="form-group">
    <label class="form-label">Confirm New Password *</label>
    <div class="pass-wrap">
      <input id="fp-conf" type="password" class="form-input" placeholder="Repeat password"/>
      <button class="pass-toggle" type="button"
        onclick="togglePass('fp-conf',this)">👁</button>
    </div>
  </div>

  <!-- Password rules -->
  <div style="background:var(--bg3);border-radius:var(--r-sm);padding:10px 13px;
              font-size:.76rem;color:var(--text3);margin-bottom:16px;line-height:1.7">
    Password must be: minimum 8 characters · at least one uppercase letter ·
    at least one number · at least one special character (!@#$%^&*)
  </div>

  <button class="btn btn-teal btn-full btn-lg" onclick="saveForcePassword()">
    Set New Password & Continue →
  </button>
</div>`;

  document.getElementById('dlg-root').appendChild(ov);
}

function saveForcePassword() {
  const np  = document.getElementById('fp-new').value;
  const np2 = document.getElementById('fp-conf').value;
  const alertEl = document.getElementById('fpwd-alert');

  const err = _validatePassword(np, np2, CU.passHash);
  if (err) {
    alertEl.innerHTML = `<div class="alert a-err">${err}</div>`;
    return;
  }

  DB.updateUser(CU.id, { passHash: SEC.hash(np), mustChangePassword: false });
  CU = DB.getByEmail(CU.email); // refresh CU
  DB.setSession(CU);

  document.getElementById('dlg-force-pwd')?.remove();
  toast('Password changed successfully ✓', 'ok');
}

// ── Regular change-password dialog (user-initiated) ───────────────────
function dlgChangePassword() {
  openDlg(`
<div class="dlg-title">🔐 Change Password</div>

<div id="cpwd-alert"></div>

<div class="form-group">
  <label class="form-label">Current Password *</label>
  <div class="pass-wrap">
    <input id="cp-cur" type="password" class="form-input" placeholder="Your current password"/>
    <button class="pass-toggle" type="button" onclick="togglePass('cp-cur',this)">👁</button>
  </div>
</div>

<div class="form-group">
  <label class="form-label">New Password *</label>
  <div class="pass-wrap">
    <input id="cp-new" type="password" class="form-input"
      placeholder="Min 8 chars, uppercase, number, symbol"
      oninput="_pwdStrength(this.value,'cp-bar','cp-lbl')"/>
    <button class="pass-toggle" type="button" onclick="togglePass('cp-new',this)">👁</button>
  </div>
  <div class="pass-strength"><div id="cp-bar" class="ps-fill" style="width:0%;background:var(--red)"></div></div>
  <div id="cp-lbl" style="font-size:.72rem;color:var(--text3);margin-top:3px"></div>
</div>

<div class="form-group">
  <label class="form-label">Confirm New Password *</label>
  <div class="pass-wrap">
    <input id="cp-conf" type="password" class="form-input" placeholder="Repeat new password"/>
    <button class="pass-toggle" type="button" onclick="togglePass('cp-conf',this)">👁</button>
  </div>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-teal"  onclick="saveChangePassword()">Update Password</button>
</div>`);
}

function saveChangePassword() {
  const cur = document.getElementById('cp-cur').value;
  const np  = document.getElementById('cp-new').value;
  const np2 = document.getElementById('cp-conf').value;
  const alertEl = document.getElementById('cpwd-alert');

  // Verify current password
  if (!SEC.verify(cur, CU.passHash)) {
    alertEl.innerHTML = `<div class="alert a-err">Current password is incorrect.</div>`;
    return;
  }

  const err = _validatePassword(np, np2, CU.passHash);
  if (err) {
    alertEl.innerHTML = `<div class="alert a-err">${err}</div>`;
    return;
  }

  DB.updateUser(CU.id, { passHash: SEC.hash(np), mustChangePassword: false });
  CU = DB.getByEmail(CU.email);
  DB.setSession(CU);

  closeDlg();
  toast('Password updated successfully ✓', 'ok');

  // Log for audit
  Notify.send(CU.email, '[ResourceAI] Password Changed',
    `Your ResourceAI password was changed on ${new Date().toLocaleString()}.`);
}

// ── Admin: reset any user's password ─────────────────────────────────
function dlgAdminResetPassword(userId) {
  const user = DB.getUsers().find(u => u.id === userId);
  if (!user) return toast('User not found', 'err');

  openDlg(`
<div class="dlg-title">Reset Password: ${user.name}</div>
<div style="font-size:.83rem;color:var(--text2);margin-bottom:14px">
  ${user.email} · ${user.department}
</div>

<div id="arst-alert"></div>

<div class="form-group">
  <label class="form-label">New Temporary Password *</label>
  <div class="pass-wrap">
    <input id="ar-np" type="password" class="form-input"
      placeholder="Min 8 characters"
      oninput="_pwdStrength(this.value,'ar-bar','ar-lbl')"/>
    <button class="pass-toggle" type="button" onclick="togglePass('ar-np',this)">👁</button>
  </div>
  <div class="pass-strength"><div id="ar-bar" class="ps-fill" style="width:0%;background:var(--red)"></div></div>
  <div id="ar-lbl" style="font-size:.72rem;color:var(--text3);margin-top:3px"></div>
  <div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap">
    <button class="btn btn-xs btn-ghost" onclick="_fillRandPwd('ar-np')">🎲 Generate Strong</button>
  </div>
</div>

<div class="form-group" style="display:flex;align-items:center;gap:9px">
  <input type="checkbox" id="ar-force" checked style="width:15px;height:15px;cursor:pointer"/>
  <label for="ar-force" style="font-size:.84rem;cursor:pointer;color:var(--text2)">
    Force user to change password on next login
  </label>
</div>

<div style="display:flex;gap:9px;justify-content:flex-end;margin-top:18px">
  <button class="btn btn-ghost" onclick="closeDlg()">Cancel</button>
  <button class="btn btn-amber"  onclick="saveAdminReset('${userId}')">Reset Password</button>
</div>`);
}

function saveAdminReset(userId) {
  const np       = document.getElementById('ar-np').value;
  const force    = document.getElementById('ar-force').checked;
  const alertEl  = document.getElementById('arst-alert');

  if (!np || np.length < 8) {
    alertEl.innerHTML = `<div class="alert a-err">Password must be at least 8 characters.</div>`;
    return;
  }

  const user = DB.getUsers().find(u => u.id === userId);
  DB.updateUser(userId, { passHash: SEC.hash(np), mustChangePassword: force });

  // Notify the user
  Notify.send(user.email, '[ResourceAI] Your Password Has Been Reset',
    `Hi ${user.name},\n\nYour ResourceAI password was reset by an administrator.\n\nTemporary password: ${np}\n\nPlease log in and change it immediately.\n\n— ResourceAI Team`);

  closeDlg();
  initAdmin();
  toast(`Password reset for ${user.name} ✓`, 'ok');
}

// ── Generate random strong password ──────────────────────────────────
function _fillRandPwd(inputId) {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
  let pwd = '';
  // Ensure at least one of each required type
  pwd += 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random()*21)];
  pwd += 'abcdefghjkmnpqrstuvwxyz'[Math.floor(Math.random()*21)];
  pwd += '23456789'[Math.floor(Math.random()*8)];
  pwd += '!@#$%'[Math.floor(Math.random()*5)];
  for (let i = 0; i < 8; i++) pwd += chars[Math.floor(Math.random()*chars.length)];
  // Shuffle
  pwd = pwd.split('').sort(()=>Math.random()-.5).join('');

  const el = document.getElementById(inputId);
  if (el) { el.value = pwd; el.type = 'text'; _pwdStrength(pwd, inputId.replace('np','bar'), inputId.replace('np','lbl')); }
  toast(`Generated: ${pwd} (copy it now)`, 'info', 8000);
}

// ── Shared password validation ────────────────────────────────────────
function _validatePassword(np, np2, currentHash) {
  if (!np || np.length < 8)          return 'Password must be at least 8 characters.';
  if (!/[A-Z]/.test(np))             return 'Must include at least one uppercase letter.';
  if (!/[0-9]/.test(np))             return 'Must include at least one number.';
  if (!/[^A-Za-z0-9]/.test(np))      return 'Must include at least one special character.';
  if (np !== np2)                     return 'Passwords do not match.';
  if (currentHash && SEC.verify(np, currentHash)) return 'New password must be different from your current password.';
  return null; // OK
}

// ── Shared strength meter ─────────────────────────────────────────────
function _pwdStrength(p, barId, lblId) {
  const bar = document.getElementById(barId);
  const lbl = document.getElementById(lblId);
  if (!bar) return;

  let score = 0;
  if (p.length >= 8)           score++;
  if (p.length >= 12)          score++;
  if (/[A-Z]/.test(p))         score++;
  if (/[0-9]/.test(p))         score++;
  if (/[^A-Za-z0-9]/.test(p)) score++;

  const pcts  = [0, 20, 40, 65, 85, 100];
  const cols  = ['var(--red)','var(--red)','var(--amber)','var(--amber2)','var(--teal)','var(--green)'];
  const labels = ['', 'Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];

  bar.style.width      = pcts[score] + '%';
  bar.style.background = cols[score];
  if (lbl) { lbl.textContent = labels[score]; lbl.style.color = cols[score]; }
}

// toggleUMenu patch moved to patches.js

// initAdmin patch moved to patches.js

// 'use strict';
// // ═══════════════════════════════════════════════════════════════════════
// // COLMAPPER.JS — Production-grade column intelligence engine
// // Three-pass matching + multi-skill merging + date/percent parsing
// // ═══════════════════════════════════════════════════════════════════════
// const ColMapper = {

//   SKILL: {
//     name:['name','employeename','empname','fullname','staff','resource','person','resourcename','staffname','membername','workername','associatename','consultantname','candidatename','username','displayname'],
//     employeeId:['employeeid','empid','id','staffid','eid','empno','employeeno','workerid','associateid','staffno','resourceid','personid','sapid','hrmsid','payrollid'],
//     email:['email','emailid','mail','emailaddress','workemail','officeemail','corporateemail'],
//     department:['department','dept','division','bu','team','unit','businessunit','costcenter','group','function','vertical','practice','stream','serviceline','pod','tower'],
//     designation:['designation','band','level','grade','jobtitle','title','bandlevel','seniority','tier','rank','role','position','currentdesignation','jobgrade','employeegrade','careerband','careerlevel','banddesignation','gradelevel'],
//     experienceYears:['experience','experienceyears','yoe','years','exp','totalexperience','yearofexperience','totalexp','workingyears','relevantexperience','totalyearsofexperience','experienceinyears','professionalexperience','industryexperience','overallexperience'],
//     location:['location','city','baselocation','site','office','worklocation','basecity','currentlocation','workcity','officelocation','geography','region','country','state','worksite'],
//     skills:['skills','skill','techstack','technologies','expertise','primaryskills','keyskills','primaryskill','skill1','skillset','technicalskills','competencies','toolsandtech','technologyskills','primarytechnology','maintechnology','primaryexpertise','skillarea','workdayskills','modules'],
//     secondarySkills:['secondaryskills','skills2','otherskills','addlskills','secondaryskill','skill2','additionalskills','supplementaryskills','otherexpertise','secondarytechnology'],
//     isCertified:['certified','certification','iscertified','certifiedyn','hascertification','certifiedornot','certfied','certificationstatus','certifiedpro','profcertified','certifiedornot','workdaycertified','wdcertified'],
//   },

//   ALLOC: {
//     employeeId:['employeeid','empid','id','name','employeename','empname','resource','resourcename','staffname','workername','staffid','empno','personname','associatename','consultantname'],
//     projectName:['project','projectname','allocatedproject','assignedproject','currentproject','engagement','assignment','work','projecttitle','projectcode','engagementname','account','client','clientname','workorder','deliverable','initiative'],
//     percentage:['allocation','allocationpercentage','percent','percentage','allocated','utilization','allocationpercent','billablepercent','allocationpct','utilizationpercent','effort','effortpercent','fte','ftepercent','capacity','capacitypercent','bandwidth','hoursperweek','hrs'],
//     startDate:['startdate','fromdate','start','from','allocationstart','projectstart','startdt','begindate','commencementdate','joiningdate','onboarddate','effectivedate','allocationfrom'],
//     endDate:['enddate','todate','end','till','until','allocationend','projectend','enddt','completiondate','tentativeenddate','expectedenddate','allocationto','releasedate','targetenddate'],
//     isInternal:['isinternal','internal','type','projecttype','billable','billingtype','engagementtype','chargeable','billability','projectcategory','allocationtype','chargeability'],
//   },

//   REQ: {
//     role:['role','jobtitle','title','position','opening','requirement','requirementtitle','rolename','jobprofile','profile','jobrole','hiringrole','vacancytitle','requisition','jobopening','positiontitle','demandtitle','openposition','hiringneed','resourcerequirement','resourcerequest'],
//     skills:['skills','requiredskills','mandatoryskills','techstack','technologies','skillsrequired','keyskills','primaryskills','mustskills','technicalskills','competencies','musthavedskills','requiredtechnology','primaryskill','skill','skillset','mandatorymodules','modules','workdaymodules'],
//     experienceYears:['experience','minexperience','minyears','requiredexperience','experiencerequired','yearsofexperience','expneeded','minexp','minimumexperience','yoe','years','totalexperience','minexpyears','requiredyears'],
//     designation:['band','level','grade','designation','seniority','requiredband','bandlevel','requiredlevel','requiredgrade','tier','gradelevel','targetband','requireddesignation','expectedband','jobgrade'],
//     location:['location','preferredlocation','city','baselocation','worklocation','site','office','joblocation','positionlocation','preferredcity','workcity','region'],
//     headcount:['headcount','count','openings','positions','vacancies','seats','numberofpositions','noofpositions','nos','qty','quantity','requiredheadcount','totalvacancies','openpositions','demand','numberOfResources','resourcecount','noofresources'],
//     priority:['priority','urgency','criticality','importancelevel','hiringpriority','reqpriority','prioritylevel','severity'],
//     description:['description','details','notes','jd','jobdescription','remarks','additionalinfo','context','comments','requirementdetails','roledescription','jobdetails','scope'],
//     department:['department','dept','division','bu','team','unit','businessunit','hiringdept','hiringdepartment','requestingdept','requestingteam'],
//     status:['status','reqstatus','requirementstatus','state','openingstatus','filledstatus','demandstatus'],
//   },

//   norm(h){ return String(h).toLowerCase().replace(/[^a-z0-9]/g,''); },

//   // Three-pass: exact → substring → token overlap
//   mapHeaders(headers, schema){
//     const result={}, used=new Set();
//     const normH = headers.map(h=>({raw:h, n:this.norm(h)}));

//     // Pass 1: exact
//     for(const[canon,syns] of Object.entries(schema)){
//       if(result[canon]) continue;
//       for(const{raw,n} of normH){
//         if(used.has(raw)) continue;
//         if(syns.includes(n)){result[canon]=raw;used.add(raw);break;}
//       }
//     }
//     // Pass 2: substring
//     for(const[canon,syns] of Object.entries(schema)){
//       if(result[canon]) continue;
//       for(const{raw,n} of normH){
//         if(used.has(raw)) continue;
//         if(syns.some(s=>n.includes(s)||s.includes(n))){result[canon]=raw;used.add(raw);break;}
//       }
//     }
//     // Pass 3: token overlap (shared words >= 3 chars)
//     for(const[canon,syns] of Object.entries(schema)){
//       if(result[canon]) continue;
//       for(const{raw,n} of normH){
//         if(used.has(raw)) continue;
//         const hToks=new Set(n.match(/[a-z]{3,}/g)||[]);
//         const hit=syns.some(s=>(s.match(/[a-z]{3,}/g)||[]).some(t=>hToks.has(t)));
//         if(hit){result[canon]=raw;used.add(raw);break;}
//       }
//     }
//     return result;
//   },

//   unmapped(headers, mapping){
//     const m=new Set(Object.values(mapping));
//     return headers.filter(h=>!m.has(h));
//   },

//   transform(row, mapping){
//     const out={};
//     for(const[canon,orig] of Object.entries(mapping)){
//       const v=row[orig];
//       if(v!==undefined&&v!==null&&String(v).trim()!=='') out[canon]=String(v).trim();
//     }
//     for(const[k,v] of Object.entries(row)){
//       if(!Object.values(mapping).includes(k)&&v!==null&&v!==undefined&&String(v).trim()!=='')
//         out['_extra_'+k]=String(v).trim();
//     }
//     return out;
//   },

//   // KEY: merge ALL skill-like columns (Primary Skill, Skill 2, Skill 3…)
//   mergeAllSkillColumns(row, mapping){
//     const mappedCols=new Set([mapping.skills, mapping.secondarySkills, mapping.isCertified].filter(Boolean));
//     const skillKws=['skill','tech','module','expertise','competenc','tool'];
//     const all=[];
//     const seen=new Set();
//     const add=(v)=>{
//       String(v||'').split(/[,;|\/]/).map(s=>s.trim()).filter(Boolean).forEach(s=>{
//         const key=s.toLowerCase().trim();
//         if(key.length>1&&!seen.has(key)){seen.add(key);all.push(s);}
//       });
//     };
//     // Primary mapped skills first
//     if(mapping.skills && row[mapping.skills]) add(row[mapping.skills]);
//     if(mapping.secondarySkills && row[mapping.secondarySkills]) add(row[mapping.secondarySkills]);
//     // All OTHER columns whose header looks like a skill column
//     for(const[header,value] of Object.entries(row)){
//       if(mappedCols.has(header)) continue;
//       if(!value||!String(value).trim()) continue;
//       const normHeader=this.norm(header);
//       if(skillKws.some(kw=>normHeader.includes(kw))) add(value);
//     }
//     return all.join(', ');
//   },

//   // Parse "50%", "0.5", "50 %", "100" → integer 0-100
//   parsePercent(raw){
//     if(raw===null||raw===undefined||String(raw).trim()==='') return 0;
//     const s=String(raw).replace(/[%\s,]/g,'');
//     const n=parseFloat(s);
//     if(isNaN(n)) return 0;
//     if(n>0&&n<=1) return Math.round(n*100);   // 0.5 → 50
//     return Math.min(100,Math.max(0,Math.round(n)));
//   },

//   // Parse dates: DD/MM/YYYY, MM-DD-YYYY, YYYY-MM-DD, Excel serial
//   parseDate(raw){
//     if(!raw) return '';
//     const s=String(raw).trim();
//     if(!s||s==='0'||/^(na|n\/a|none|-)$/i.test(s)) return '';
//     if(/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
//     // DD/MM/YYYY or DD-MM-YYYY
//     const dmy=s.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
//     if(dmy) return `${dmy[3]}-${dmy[2].padStart(2,'0')}-${dmy[1].padStart(2,'0')}`;
//     // MM/DD/YY
//     const mdy=s.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})$/);
//     if(mdy){const y=mdy[3].length===2?'20'+mdy[3]:mdy[3];return`${y}-${mdy[1].padStart(2,'0')}-${mdy[2].padStart(2,'0')}`;}
//     // Excel serial
//     const num=parseFloat(s);
//     if(!isNaN(num)&&num>40000&&num<60000){
//       const d=new Date(Math.round((num-25569)*86400*1000));
//       return d.toISOString().slice(0,10);
//     }
//     try{const d=new Date(s);if(!isNaN(d.getTime()))return d.toISOString().slice(0,10);}catch{}
//     return '';
//   },

//   // Fuzzy name key for cross-file matching: "John  Doe" → "johndoe"
//   nameKey(raw){
//     return String(raw||'').toLowerCase().replace(/[^a-z0-9]/g,'').trim();
//   },
// };

'use strict';
// ═══════════════════════════════════════════════════════════════════════
// COLMAPPER.JS — Production-grade column intelligence engine
// Three-pass matching + multi-skill merging + date/percent parsing
// ═══════════════════════════════════════════════════════════════════════
const ColMapper = {

  SKILL: {
    name:['name','employeename','empname','fullname','staff','resource','person','resourcename','staffname','membername','workername','associatename','consultantname','candidatename','username','displayname'],
    employeeId:['employeeid','empid','id','staffid','eid','empno','employeeno','workerid','associateid','staffno','resourceid','personid','sapid','hrmsid','payrollid'],
    email:['email','emailid','mail','emailaddress','workemail','officeemail','corporateemail'],
    department:['department','dept','division','bu','team','unit','businessunit','costcenter','group','function','vertical','practice','stream','serviceline','pod','tower'],
    designation:['designation','band','level','grade','jobtitle','title','bandlevel','seniority','tier','rank','role','position','currentdesignation','jobgrade','employeegrade','careerband','careerlevel','banddesignation','gradelevel'],
    experienceYears:['experience','experienceyears','yoe','years','exp','totalexperience','yearofexperience','totalexp','workingyears','relevantexperience','totalyearsofexperience','experienceinyears','professionalexperience','industryexperience','overallexperience'],
    location:['location','city','baselocation','site','office','worklocation','basecity','currentlocation','workcity','officelocation','geography','region','country','state','worksite'],
    skills:['skills','skill','techstack','technologies','expertise','primaryskills','keyskills','primaryskill','skill1','skillset','technicalskills','competencies','toolsandtech','technologyskills','primarytechnology','maintechnology','primaryexpertise','skillarea','workdayskills','modules'],
    secondarySkills:['secondaryskills','skills2','otherskills','addlskills','secondaryskill','skill2','additionalskills','supplementaryskills','otherexpertise','secondarytechnology'],
    isCertified:['certified','certification','iscertified','certifiedyn','hascertification','certifiedornot','certfied','certificationstatus','certifiedpro','profcertified','certifiedornot','workdaycertified','wdcertified'],
  },

  ALLOC: {
    employeeId:['employeeid','empid','id','name','employeename','empname','resource','resourcename','staffname','workername','staffid','empno','personname','associatename','consultantname'],
    projectName:['project','projectname','allocatedproject','assignedproject','currentproject','engagement','assignment','work','projecttitle','projectcode','engagementname','account','client','clientname','workorder','deliverable','initiative'],
    percentage:['allocation','allocationpercentage','percent','percentage','allocated','utilization','allocationpercent','billablepercent','allocationpct','utilizationpercent','effort','effortpercent','fte','ftepercent','capacity','capacitypercent','bandwidth','hoursperweek','hrs'],
    startDate:['startdate','fromdate','start','from','allocationstart','projectstart','startdt','begindate','commencementdate','joiningdate','onboarddate','effectivedate','allocationfrom'],
    endDate:['enddate','todate','end','till','until','allocationend','projectend','enddt','completiondate','tentativeenddate','expectedenddate','allocationto','releasedate','targetenddate'],
    isInternal:['isinternal','internal','type','projecttype','billable','billingtype','engagementtype','chargeable','billability','projectcategory','allocationtype','chargeability'],
  },

  REQ: {
    role:['role','jobtitle','title','position','opening','requirement','requirementtitle','rolename','jobprofile','profile','jobrole','hiringrole','vacancytitle','requisition','jobopening','positiontitle','demandtitle','openposition','hiringneed','resourcerequirement','resourcerequest'],
    skills:['skills','requiredskills','mandatoryskills','techstack','technologies','skillsrequired','keyskills','primaryskills','mustskills','technicalskills','competencies','musthavedskills','requiredtechnology','primaryskill','skill','skillset','mandatorymodules','modules','workdaymodules'],
    experienceYears:['experience','minexperience','minyears','requiredexperience','experiencerequired','yearsofexperience','expneeded','minexp','minimumexperience','yoe','years','totalexperience','minexpyears','requiredyears'],
    designation:['band','level','grade','designation','seniority','requiredband','bandlevel','requiredlevel','requiredgrade','tier','gradelevel','targetband','requireddesignation','expectedband','jobgrade'],
    location:['location','preferredlocation','city','baselocation','worklocation','site','office','joblocation','positionlocation','preferredcity','workcity','region'],
    headcount:['headcount','count','openings','positions','vacancies','seats','numberofpositions','noofpositions','nos','qty','quantity','requiredheadcount','totalvacancies','openpositions','demand','numberOfResources','resourcecount','noofresources'],
    priority:['priority','urgency','criticality','importancelevel','hiringpriority','reqpriority','prioritylevel','severity'],
    description:['description','details','notes','jd','jobdescription','remarks','additionalinfo','context','comments','requirementdetails','roledescription','jobdetails','scope'],
    department:['department','dept','division','bu','team','unit','businessunit','hiringdept','hiringdepartment','requestingdept','requestingteam'],
    status:['status','reqstatus','requirementstatus','state','openingstatus','filledstatus','demandstatus'],
  },

  norm(h){ return String(h).toLowerCase().replace(/[^a-z0-9]/g,''); },

  // Three-pass: exact → substring → token overlap
  mapHeaders(headers, schema){
    const result={}, used=new Set();
    const normH = headers.map(h=>({raw:h, n:this.norm(h)}));

    // Pass 1: exact
    for(const[canon,syns] of Object.entries(schema)){
      if(result[canon]) continue;
      for(const{raw,n} of normH){
        if(used.has(raw)) continue;
        if(syns.includes(n)){result[canon]=raw;used.add(raw);break;}
      }
    }
    // Pass 2: substring
    for(const[canon,syns] of Object.entries(schema)){
      if(result[canon]) continue;
      for(const{raw,n} of normH){
        if(used.has(raw)) continue;
        if(syns.some(s=>n.includes(s)||s.includes(n))){result[canon]=raw;used.add(raw);break;}
      }
    }
    // Pass 3: token overlap (shared words >= 3 chars)
    for(const[canon,syns] of Object.entries(schema)){
      if(result[canon]) continue;
      for(const{raw,n} of normH){
        if(used.has(raw)) continue;
        const hToks=new Set(n.match(/[a-z]{3,}/g)||[]);
        const hit=syns.some(s=>(s.match(/[a-z]{3,}/g)||[]).some(t=>hToks.has(t)));
        if(hit){result[canon]=raw;used.add(raw);break;}
      }
    }
    return result;
  },

  unmapped(headers, mapping){
    const m=new Set(Object.values(mapping));
    return headers.filter(h=>!m.has(h));
  },

  transform(row, mapping){
    const out={};
    for(const[canon,orig] of Object.entries(mapping)){
      const v=row[orig];
      if(v!==undefined&&v!==null&&String(v).trim()!=='') out[canon]=String(v).trim();
    }
    for(const[k,v] of Object.entries(row)){
      if(!Object.values(mapping).includes(k)&&v!==null&&v!==undefined&&String(v).trim()!=='')
        out['_extra_'+k]=String(v).trim();
    }
    return out;
  },

  // KEY: merge ALL skill-like columns (Primary Skill, Skill 2, Skill 3…)
  mergeAllSkillColumns(row, mapping){
    const mappedCols=new Set([mapping.skills, mapping.secondarySkills, mapping.isCertified].filter(Boolean));
    const skillKws=['skill','tech','module','expertise','competenc','tool'];
    const all=[];
    const seen=new Set();
    const add=(v)=>{
      String(v||'').split(/[,;|\/]/).map(s=>s.trim()).filter(Boolean).forEach(s=>{
        const key=s.toLowerCase().trim();
        if(key.length>1&&!seen.has(key)){seen.add(key);all.push(s);}
      });
    };
    // Primary mapped skills first
    if(mapping.skills && row[mapping.skills]) add(row[mapping.skills]);
    if(mapping.secondarySkills && row[mapping.secondarySkills]) add(row[mapping.secondarySkills]);
    // All OTHER columns whose header looks like a skill column
    for(const[header,value] of Object.entries(row)){
      if(mappedCols.has(header)) continue;
      if(!value||!String(value).trim()) continue;
      const normHeader=this.norm(header);
      if(skillKws.some(kw=>normHeader.includes(kw))) add(value);
    }
    return all.join(', ');
  },

  // Parse "50%", "0.5", "50 %", "100" → integer 0-100
  parsePercent(raw){
    if(raw===null||raw===undefined||String(raw).trim()==='') return 0;
    const s=String(raw).replace(/[%\s,]/g,'');
    const n=parseFloat(s);
    if(isNaN(n)) return 0;
    if(n>0&&n<=1) return Math.round(n*100);   // 0.5 → 50
    return Math.min(100,Math.max(0,Math.round(n)));
  },

  // Parse dates: DD/MM/YYYY, MM-DD-YYYY, YYYY-MM-DD, Excel serial
  parseDate(raw){
    if(!raw) return '';
    const s=String(raw).trim();
    if(!s||s==='0'||/^(na|n\/a|none|-)$/i.test(s)) return '';
    if(/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    // DD/MM/YYYY or DD-MM-YYYY
    const dmy=s.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
    if(dmy) return `${dmy[3]}-${dmy[2].padStart(2,'0')}-${dmy[1].padStart(2,'0')}`;
    // MM/DD/YY
    const mdy=s.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})$/);
    if(mdy){const y=mdy[3].length===2?'20'+mdy[3]:mdy[3];return`${y}-${mdy[1].padStart(2,'0')}-${mdy[2].padStart(2,'0')}`;}
    // Excel serial
    const num=parseFloat(s);
    if(!isNaN(num)&&num>40000&&num<60000){
      const d=new Date(Math.round((num-25569)*86400*1000));
      return d.toISOString().slice(0,10);
    }
    try{const d=new Date(s);if(!isNaN(d.getTime()))return d.toISOString().slice(0,10);}catch{}
    return '';
  },

  // Fuzzy name key for cross-file matching: "John  Doe" → "johndoe"
  nameKey(raw){
    return String(raw||'').toLowerCase().replace(/[^a-z0-9]/g,'').trim();
  },
};
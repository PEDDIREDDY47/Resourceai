'use strict';
// ═══════════════════════════════════════════════════════
// CONFIG — Firebase placeholder & Notification engine
// Replace the Firebase section with real credentials to
// enable true email delivery. Until then, all emails are
// logged to the Admin → Email Log tab.
// Depends on: DB
// ═══════════════════════════════════════════════════════

// ── Firebase stub (replace with real config to enable cloud features) ──
const FirebaseConfig = {
  // apiKey: "YOUR_API_KEY",
  // authDomain: "your-app.firebaseapp.com",
  // projectId: "your-project-id",
  // storageBucket: "your-app.appspot.com",
  // messagingSenderId: "000000000000",
  // appId: "1:000000000000:web:abcdef1234567890"
};

// ── Notification / Email engine ──────────────────────────────────────
const Notify = {
  ADMIN: 'admin@resourceai.com',

  /**
   * "Send" an email — logs to DB and prints to console.
   * Swap body of this method with a real SMTP / Firebase call to enable delivery.
   */
  send(to, subject, body){
    DB.logEmail({to, subject, body});
    console.info('[EMAIL →]', to, '|', subject);
  },

  onRegister(reg){
    this.send(
      this.ADMIN,
      `[ResourceAI] New Registration — ${reg.name}`,
      `New registration request:\n\nName: ${reg.name}\nEmail: ${reg.email}\nDept: ${reg.department}\nReason: ${reg.reason||'—'}\n\nApprove in Admin Center → Pending tab.`
    );
  },

  onApprove(u){
    this.send(
      u.email,
      '[ResourceAI] Account Approved ✅',
      `Hi ${u.name},\n\nYour ResourceAI account has been approved!\n\nEmail: ${u.email}\nDepartment: ${u.department}\n\nYou can now sign in at the platform URL.\n\n— ResourceAI Team`
    );
  },

  onReject(r){
    this.send(
      r.email,
      '[ResourceAI] Registration Update',
      `Hi ${r.name},\n\nUnfortunately your registration request was not approved at this time. Please contact your administrator for more information.\n\n— ResourceAI Team`
    );
  },

  onRecovery(email, token){
    this.send(
      email,
      '[ResourceAI] Password Recovery Code 🔑',
      `Your password recovery code:\n\n  ${token}\n\nThis code is valid for 30 minutes.\nIf you did not request this, please ignore this email.\n\n— ResourceAI Team`
    );
  },
};

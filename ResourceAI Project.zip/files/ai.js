'use strict';
// ═══════════════════════════════════════════════════════
// BAND ENGINE — A1 through D3 hierarchical band system
// ═══════════════════════════════════════════════════════
const BAND = {
  // Full ordered list: Index 0 = A1 (most junior/lowest cost), Index 11 = D3 (most senior/highest cost)
  ORDER: ['A1','A2','A3','B1','B2','B3','C1','C2','C3','D1','D2','D3'],
  GROUPS: {A:['A1','A2','A3'], B:['B1','B2','B3'], C:['C1','C2','C3'], D:['D1','D2','D3']},

  normalize(raw){
    if(!raw)return null;
    const s = String(raw).toUpperCase().trim().replace(/\s+/g,'');
    if(this.ORDER.includes(s)) return s;
    const aliases = {
      'L1':'A1','L2':'A2','L3':'A3','L4':'B1','L5':'B2','L6':'B3',
      'L7':'C1','L8':'C2','L9':'C3',
      'JUNIOR':'A1','FRESHER':'A1','INTERN':'A1','TRAINEE':'A1','ASSOCIATE':'A2',
      'MID':'B1','DEVELOPER':'B1','ENGINEER':'B1','SE':'B1','SSE':'B2',
      'SENIOR':'B3','LEAD':'C1','TECHLEAD':'C1','STAFFENGINEER':'C2',
      'PRINCIPAL':'C3','ARCHITECT':'D1','SOLUTIONARCHITECT':'D1',
      'MANAGER':'D2','DIRECTOR':'D3','HEAD':'D3','VP':'D3',
      'GRADE1':'A1','GRADE2':'A2','GRADE3':'A3','GRADE4':'B1','GRADE5':'B2','GRADE6':'B3',
      'BAND1':'A1','BAND2':'A2','BAND3':'A3','BAND4':'B1','BAND5':'B2','BAND6':'B3',
      'G1':'A1','G2':'A2','G3':'A3','G4':'B1','G5':'B2','G6':'B3',
    };
    return aliases[s] || null;
  },

  indexOf(band){return this.ORDER.indexOf(band)},

  /** Return valid employee bands for a requirement band, in descending priority order */
  getValidBands(reqBand, forFreshers=false){
    if(forFreshers) return ['A1','A2'];
    const idx = this.indexOf(reqBand);
    if(idx < 0) return this.ORDER.slice();
    const valid = [];
    for(let i=idx; i>=0; i--) valid.push(this.ORDER[i]);
    return valid;
  },

  getBandClass(band){
    if(!band) return '';
    const b = String(band).toUpperCase().trim();
    if(b.startsWith('A')) return 'bp-a';
    if(b.startsWith('B')) return 'bp-b';
    if(b.startsWith('C')) return 'bp-c';
    if(b.startsWith('D')) return 'bp-d';
    return '';
  },

  renderBand(band){
    if(!band) return '—';
    return `<span class="band-pill ${this.getBandClass(band)}">${band}</span>`;
  }
};

// ═══════════════════════════════════════════════════════
// AI RESOURCE MATCHING ENGINE
// Tiered availability + band hierarchy + skill matching
// Depends on: BAND, DB
// ═══════════════════════════════════════════════════════
const AI = {
  INTERNAL_KEYWORDS: ['internal','bench','training','shadow','learning','self','overhead','admin','buffer','r&d','research','innovation','hackathon','kpe','kpi','billable:no'],

  isInternal(projectName){
    if(!projectName) return false;
    const p = String(projectName).toLowerCase();
    return this.INTERNAL_KEYWORDS.some(k => p.includes(k));
  },

  endingWithinDays(alloc, days){
    if(!alloc.endDate) return false;
    const end = new Date(alloc.endDate);
    const now = new Date();
    const diff = (end - now) / (1000*60*60*24);
    return diff >= 0 && diff <= days;
  },

  SKILL_LEVELS: {expert:100, advanced:80, beginner:50, aspiring:0},

  parseSkillWithLevel(raw){
    const s = raw.trim();
    const levelMatch = s.match(/^(.+?)\s*[\(\[\-\|:]\s*(expert|advanced|beginner|aspiring|learning|wants to learn)\s*[\)\]]?\s*$/i)
      || s.match(/^(expert|advanced|beginner|aspiring|learning|wants to learn)\s*[\(\[\-\|:]\s*(.+)$/i);
    if(levelMatch){
      const [,a,b] = levelMatch;
      const level = (a.toLowerCase().match(/^(expert|advanced|beginner|aspiring|learning|wants to learn)$/)) ? a : b;
      const skill = (a.toLowerCase().match(/^(expert|advanced|beginner|aspiring|learning|wants to learn)$/)) ? b : a;
      const levelKey = level.toLowerCase().replace('learning','aspiring').replace('wants to learn','aspiring');
      return {skill:skill.trim(), level:levelKey, weight:this.SKILL_LEVELS[levelKey]??50, isAspiring:levelKey==='aspiring'};
    }
    return {skill:s, level:'known', weight:60, isAspiring:false};
  },

  getSkillObjects(emp){
    const seen = new Set(); const all = [];
    const addSkills = (src, boost=0) => {
      String(src||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean).forEach(raw=>{
        const obj = this.parseSkillWithLevel(raw);
        if(obj.skill && !seen.has(obj.skill.toLowerCase())){
          seen.add(obj.skill.toLowerCase());
          all.push({...obj, weight:Math.min(100,obj.weight+boost)});
        }
      });
    };
    addSkills(emp.skills||emp.primarySkill, 20);
    addSkills(emp.secondarySkills||emp.skills2);
    addSkills(emp.techStack||emp.technologies);
    Object.entries(emp).forEach(([k,v])=>{
      if(k.startsWith('_extra_') && (k.toLowerCase().includes('skill')||k.toLowerCase().includes('tech'))){
        addSkills(v);
      }
    });
    return all;
  },

  getSkillList(emp){
    const primary = String(emp.skills||emp.primarySkill||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
    const secondary = String(emp.secondarySkills||emp.skills2||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
    const tech = String(emp.techStack||emp.technologies||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
    const extras = [];
    Object.entries(emp).forEach(([k,v])=>{
      if(k.startsWith('_extra_') && (k.toLowerCase().includes('skill')||k.toLowerCase().includes('tech'))){
        String(v).split(/[,;|]/).forEach(s=>extras.push(s.trim()));
      }
    });
    const seen = new Set(); const all = [];
    [...primary,...secondary,...tech,...extras].forEach(raw=>{
      const {skill,isAspiring} = this.parseSkillWithLevel(raw);
      if(skill && !isAspiring && !seen.has(skill.toLowerCase())){seen.add(skill.toLowerCase());all.push(skill);}
    });
    return all;
  },

  getAspiringSkills(emp){
    return this.getSkillObjects(emp).filter(s=>s.isAspiring).map(s=>s.skill);
  },

  getEffectiveExp(emp){
    const deptExpKeys = ['deptexperience','departmentexperience','workdayexperience','relevantexperience','roleexperience','functionalexperience','domainexperience'];
    for(const[k,v] of Object.entries(emp)){
      const nk = k.toLowerCase().replace(/[^a-z]/g,'');
      if(deptExpKeys.some(dk=>nk.includes(dk)||dk.includes(nk)) && v){
        const n = parseFloat(v); if(!isNaN(n)) return n;
      }
    }
    for(const[k,v] of Object.entries(emp)){
      if(k.startsWith('_extra_')){
        const nk = k.toLowerCase().replace(/[^a-z]/g,'');
        if(nk.includes('dept')||nk.includes('domain')||nk.includes('relevant')||nk.includes('workday')||nk.includes('functional')){
          const n = parseFloat(v); if(!isNaN(n)) return n;
        }
      }
    }
    return parseFloat(emp.experienceYears||emp.experience||'0')||0;
  },

  // Skill concept synonyms for intelligent matching
  CONCEPTS: {
    'react':['react','reactjs','react.js','frontend','front-end','jsx','redux','nextjs','next.js'],
    'angular':['angular','angularjs','angular.js','frontend','front-end','typescript'],
    'vue':['vue','vuejs','vue.js','frontend','front-end','nuxt'],
    'frontend':['frontend','front-end','front end','ui developer','react','angular','vue','javascript','html','css'],
    'node':['node','nodejs','node.js','express','nestjs','backend','back-end','restapi'],
    'java':['java','spring','spring boot','j2ee','jakarta','hibernate','backend'],
    'python':['python','django','flask','fastapi','backend','data science','ml','pandas'],
    'dotnet':['.net','dotnet','c#','asp.net','csharp','mvc','backend'],
    'fullstack':['fullstack','full stack','mern','mean','frontend','backend'],
    'aws':['aws','amazon','ec2','s3','lambda','cloud','devops'],
    'azure':['azure','microsoft azure','cloud','devops'],
    'devops':['devops','cicd','docker','kubernetes','k8s','jenkins','terraform','ansible','cloud'],
    'sql':['sql','mysql','postgresql','postgres','mssql','oracle','rdbms','database'],
    'nosql':['nosql','mongodb','redis','cassandra','dynamodb','database'],
    'ml':['ml','machine learning','deep learning','tensorflow','pytorch','keras','ai','data science'],
    'mobile':['mobile','ios','android','flutter','react native','swift','kotlin'],
    'qa':['qa','quality assurance','testing','selenium','cypress','automation','test engineer'],
    'pm':['pm','project manager','scrum master','agile','pmo','project management'],
    'security':['security','cybersecurity','infosec','devsecops','penetration testing'],
    'ui':['ui','ux','design','figma','sketch','adobe xd','user interface'],
    'architect':['architect','solution architect','system design','tech lead','technical lead'],
    'workday_core':['workday','hcm','core hcm','workday core','human capital management'],
    'workday_benefits':['benefits','health and welfare','open enrollment','benefits administration'],
    'workday_compensation':['compensation','advanced comp','merit','bonus','stock','comp plans'],
    'workday_payroll':['payroll','us payroll','global payroll','payroll processing','payslip'],
    'workday_absence':['absence','leave','time off','absence management','loa'],
    'workday_time':['time tracking','timesheet','clock in','attendance','wtt'],
    'workday_talent':['talent','performance','succession','goal management','calibration'],
    'workday_recruiting':['recruiting','ats','talent acquisition','onboarding','hiring'],
    'workday_learning':['learning','lms','training','course management'],
    'workday_financials':['financials','fins','core fins','general ledger','procurement','accounts payable'],
    'workday_integration':['integration','eib','studio','core connector','ccw','peci','ccb','xly','xslt','soap','rest api','wdl'],
    'workday_reporting':['reporting','custom reports','advanced reports','matrix reports','composite reports','prism','calculated fields','calc fields'],
    'workday_security':['security','security groups','bp security','domain security','issg','isg'],
  },

  skillMatches(empSkillList, reqSkill){
    const req = reqSkill.toLowerCase().trim();
    let reqTerms = new Set([req]);
    for(const[concept,expansions] of Object.entries(this.CONCEPTS)){
      if(expansions.some(e=>e.includes(req)||req.includes(e)) || concept.includes(req) || req.includes(concept)){
        reqTerms.add(concept);
        expansions.forEach(e=>reqTerms.add(e));
      }
    }
    for(let i=0; i<empSkillList.length; i++){
      const empSkill = empSkillList[i].toLowerCase();
      for(const term of reqTerms){
        if(empSkill.includes(term) || term.includes(empSkill)){
          return {matched:true, priority:i};
        }
      }
    }
    return {matched:false, priority:999};
  },

  // ─── MAIN TIERED MATCHING ──────────────────────────────
  // Returns: { free, partial, ending, internal, noMatch }
  findMatches(req, dept=null){
    const employees = DB.getEmployees(dept);
    if(!employees.length) return {free:[], partial:[], ending:[], internal:[], noMatch:[]};

    const reqBand = BAND.normalize(req.designation||req.band||req.level||'');
    const reqSkills = String(req.skills||'').split(/[,;|]/).map(s=>s.trim()).filter(Boolean);
    const forFreshers = !!req.forFreshers || String(req.role||'').toLowerCase().includes('fresher') || String(req.role||'').toLowerCase().includes('new joiner') || String(req.role||'').toLowerCase().includes('newjoiner');
    const validBands = BAND.getValidBands(reqBand, forFreshers);
    const reqExp = parseFloat(req.experienceYears||req.minExperience||'0') || 0;
    const reqLoc = String(req.location||'').toLowerCase().trim();

    const free=[], partial=[], ending=[], internal=[], noMatch=[];

    for(const emp of employees){
      const empBand = BAND.normalize(emp.designation||emp.band||emp.level||emp.grade||'');
      const empUtil = DB.empUtil(emp.id);
      const empAvail = 100 - empUtil;
      const empAllocs = DB.empAllocs(emp.id);
      const empSkills = this.getSkillList(emp);
      const empExp = this.getEffectiveExp(emp);
      const empLoc = String(emp.location||'').toLowerCase();

      // Hard band filter
      let bandOk=true, bandPriority=0;
      if(reqBand && validBands.length){
        if(!empBand){bandOk=true; bandPriority=validBands.length;}
        else if(!validBands.includes(empBand)){bandOk=false;}
        else{bandPriority=validBands.indexOf(empBand);}
      }
      if(!bandOk) continue;

      // Skill matching
      let bestSkillMatch = {matched:false, priority:999, reqSkillIdx:999};
      for(let si=0; si<reqSkills.length; si++){
        const m = this.skillMatches(empSkills, reqSkills[si]);
        if(m.matched && si < bestSkillMatch.reqSkillIdx){
          bestSkillMatch = {...m, reqSkillIdx:si};
        }
      }
      if(reqSkills.length && !bestSkillMatch.matched) continue;

      const expOk = reqExp===0 || empExp >= reqExp-1;
      const locOk = !reqLoc || empLoc.includes(reqLoc) || reqLoc.includes(empLoc);
      const bandScore = reqBand ? (100-bandPriority*10) : 80;
      const skillScore = bestSkillMatch.matched ? (100-bestSkillMatch.priority*5-bestSkillMatch.reqSkillIdx*10) : 0;
      const expScore = empExp>=reqExp ? 100 : empExp>=(reqExp-1) ? 75 : 50;
      const locScore = locOk ? 100 : 40;

      const emp_result = {
        ...emp,
        _band:empBand, _util:empUtil, _avail:empAvail,
        _bandPriority:bandPriority, _skillPriority:bestSkillMatch.priority,
        _reqSkillIdx:bestSkillMatch.reqSkillIdx,
        _score:Math.round(bandScore*0.3+skillScore*0.4+expScore*0.2+locScore*0.1),
        _allocs:empAllocs,
      };

      // Triage into availability tiers
      if(empAvail >= 100){
        free.push({...emp_result, _tier:'free', _tierLabel:'100% Available'});
      } else if(empUtil <= 50){
        partial.push({...emp_result, _tier:'partial', _tierLabel:`${empAvail}% Available`});
      } else {
        const endingIn30 = empAllocs.some(a=>this.endingWithinDays(a,30));
        const endingIn60 = empAllocs.some(a=>this.endingWithinDays(a,60));
        const endingAlloc = empAllocs.find(a=>this.endingWithinDays(a,60));
        if(endingIn30 || endingIn60){
          ending.push({...emp_result, _tier:'ending',
            _tierLabel:`Allocation ending in ${endingIn30?'30':'60'} days`,
            _endDate:endingAlloc?.endDate, _endProject:endingAlloc?.projectName});
        } else {
          const allOnInternal = empAllocs.length>0 && empAllocs.every(a=>this.isInternal(a.projectName));
          if(allOnInternal){
            const proj = empAllocs.map(a=>a.projectName).join(', ');
            internal.push({...emp_result, _tier:'internal',
              _tierLabel:`On internal project: ${proj}`, _internalProj:proj});
          } else {
            noMatch.push({...emp_result, _tier:'busy', _tierLabel:`${empUtil}% Allocated`});
          }
        }
      }
    }

    const sortFn = (a,b) => b._score-a._score || a._bandPriority-b._bandPriority;
    return {
      free: free.sort(sortFn),
      partial: partial.sort(sortFn),
      ending: ending.sort(sortFn),
      internal: internal.sort(sortFn),
      noMatch: noMatch.sort(sortFn),
    };
  },

  // ─── FREE-TEXT SEMANTIC SEARCH ─────────────────────────
  search(query, dept=null){
    if(!query.trim()) return [];
    const q = query.toLowerCase();

    // Extract band
    let reqBand = null;
    for(const b of BAND.ORDER){ if(q.includes(b.toLowerCase())) reqBand = b; }
    if(!reqBand){
      const aliases = ['junior','fresher','senior','lead','manager','principal'];
      for(const a of aliases){ if(q.includes(a)){reqBand=BAND.normalize(a);break;} }
    }

    // Extract experience, location, skills
    const yM = q.match(/(\d+)\+?\s*(?:years?|yrs?|yr)/i);
    const reqExp = yM ? parseInt(yM[1]) : 0;
    const locM = q.match(/(?:in|at|from|based in)\s+([a-z][a-z ]{1,18}?)(?:\s|,|$)/i);
    const reqLoc = locM ? locM[1].trim() : '';
    const stopWords = new Set(['and','the','with','for','who','can','have','need','want','find','search','in','at','from','based','located','year','years','experience','senior','junior','lead','manager','developer','engineer']);
    const skillTerms = q.split(/\s+/).filter(w=>w.length>2&&!stopWords.has(w)&&!/^\d/.test(w));

    const employees = DB.getEmployees(dept);
    const validBands = reqBand ? BAND.getValidBands(reqBand) : [...BAND.ORDER];
    const results = [];

    for(const emp of employees){
      const empBand = BAND.normalize(emp.designation||emp.band||emp.level||'');
      if(reqBand && empBand && !validBands.includes(empBand)) continue;
      const empSkills = this.getSkillList(emp);
      const empSkillStr = empSkills.join(' ').toLowerCase();
      const empUtil = DB.empUtil(emp.id);
      const empAvail = 100 - empUtil;
      const empExp = this.getEffectiveExp(emp);
      const empLoc = String(emp.location||'').toLowerCase();

      let skillHits = 0;
      for(const t of skillTerms){
        if(empSkillStr.includes(t) || [...Object.values(this.CONCEPTS)].flat().some(ex=>ex.includes(t)&&empSkillStr.includes(ex))) skillHits++;
      }
      const skillScore = skillTerms.length ? Math.round(skillHits/skillTerms.length*100) : 70;
      if(skillScore===0 && skillTerms.length>0) continue;

      const expScore = reqExp ? (empExp>=reqExp?100:empExp>=(reqExp-1)?75:40) : 80;
      const bandScore = empBand&&reqBand ? Math.max(0,100-BAND.indexOf(reqBand)-BAND.indexOf(empBand)*5) : 70;
      const availScore = empAvail>=100?100:empAvail>=50?80:empAvail>=30?55:30;
      const locScore = reqLoc ? (empLoc.includes(reqLoc)||reqLoc.includes(empLoc)?100:35) : 80;
      const score = Math.round(skillScore*0.40+expScore*0.25+bandScore*0.15+availScore*0.12+locScore*0.08);
      if(score < 15) continue;

      const empAllocs = DB.empAllocs(emp.id);
      results.push({...emp, _score:score, _util:empUtil, _avail:empAvail,
        _band:empBand,
        _endingSoon:empAllocs.some(a=>this.endingWithinDays(a,60)),
        _allInternal:empAllocs.length>0&&empAllocs.every(a=>this.isInternal(a.projectName)),
        _breakdown:{skill:skillScore,exp:expScore,band:bandScore,avail:availScore,loc:locScore}});
    }
    return results.sort((a,b)=>b._score-a._score).slice(0,10);
  },
};

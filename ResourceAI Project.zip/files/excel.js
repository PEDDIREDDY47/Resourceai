'use strict';
// ═══════════════════════════════════════════════════════
// EXCEL PARSER — SheetJS XLSX + native CSV reader
// Parses .xlsx, .xls, and .csv files into row arrays
// Depends on: window.XLSX (CDN loaded in index.html)
// ═══════════════════════════════════════════════════════
const XL = {
  /**
   * Parse a File object into an array of row objects.
   * Supports: .xlsx, .xls, .csv
   * @param {File} file
   * @returns {Promise<Object[]>}
   */
  async parse(file){
    return new Promise((res, rej) => {
      const r = new FileReader();
      const ext = file.name.split('.').pop().toLowerCase();
      r.onload = e => {
        try {
          if(ext === 'csv'){
            res(this.parseCSV(e.target.result));
          } else if(['xlsx','xls'].includes(ext)){
            if(!window.XLSX) return rej(new Error('XLSX library not available. Ensure CDN script is loaded.'));
            const wb = XLSX.read(e.target.result, {type:'array', cellDates:true});
            const ws = wb.Sheets[wb.SheetNames[0]];
            res(XLSX.utils.sheet_to_json(ws, {defval:'', raw:false}));
          } else {
            rej(new Error('Unsupported file type. Use .xlsx, .xls, or .csv'));
          }
        } catch(err){ rej(err); }
      };
      r.onerror = () => rej(new Error('File read failed'));
      if(ext === 'csv') r.readAsText(file);
      else r.readAsArrayBuffer(file);
    });
  },

  /** Parse CSV text into row objects */
  parseCSV(text){
    const lines = text.trim().split(/\r?\n/);
    if(lines.length < 2) return [];
    const headers = this.splitLine(lines[0]);
    return lines.slice(1).filter(l => l.trim()).map(line => {
      const vals = this.splitLine(line);
      const obj = {};
      headers.forEach((h,i) => {
        obj[h.replace(/^"|"$/g,'').trim()] = (vals[i]||'').replace(/^"|"$/g,'').trim();
      });
      return obj;
    });
  },

  /** Split a CSV line respecting quoted fields */
  splitLine(line){
    const res = [];
    let cur = '';
    let q = false;
    for(const ch of line){
      if(ch === '"'){ q = !q; }
      else if(ch === ',' && !q){ res.push(cur); cur = ''; }
      else cur += ch;
    }
    res.push(cur);
    return res;
  },
};

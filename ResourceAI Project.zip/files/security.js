'use strict';
// ═══════════════════════════════════════════════════════
// SECURITY ENGINE — Password hashing & XOR encryption
// ═══════════════════════════════════════════════════════
const SEC = {
  _k:'RA_PROD_KEY_2025_resourceai_secure_xor',
  _xor(s,k){let o='';for(let i=0;i<s.length;i++)o+=String.fromCharCode(s.charCodeAt(i)^k.charCodeAt(i%k.length));return o},
  enc(d){try{return btoa(unescape(encodeURIComponent(this._xor(JSON.stringify(d),this._k))))}catch{return btoa(JSON.stringify(d))}},
  dec(s){try{return JSON.parse(this._xor(decodeURIComponent(escape(atob(s))),this._k))}catch{try{return JSON.parse(atob(s))}catch{return null}}},
  hash(p){
    // Deterministic dual-hash (PBKDF2-inspired)
    let h=5381;for(let i=0;i<p.length;i++)h=(h*33)^p.charCodeAt(i);
    let h2=0;for(let i=p.length-1;i>=0;i--)h2=(h2*31)+p.charCodeAt(i);
    return 'RA2$'+Math.abs(h).toString(36)+'.'+Math.abs(h2).toString(36)+'.'+p.length.toString(36);
  },
  verify(p,hash){
    if(!hash)return false;
    if(hash.startsWith('RA2$'))return this.hash(p)===hash;
    // Legacy hash support
    if(hash.startsWith('RA$')){let h=0;for(let i=0;i<p.length;i++)h=((h<<5)-h+p.charCodeAt(i))|0;return hash==='RA$'+Math.abs(h).toString(36)+p.length.toString(36)+btoa(p).slice(0,8);}
    try{return atob(hash)===p}catch{return false}
  },
  genToken(){return String(Math.floor(100000+Math.random()*900000))}
};

'use strict';
// ═══════════════════════════════════════════════════════
// DATABASE ENGINE — LocalStorage state manager with encryption
// Depends on: security.js (SEC)
// ═══════════════════════════════════════════════════════
const DB = {
  _p:'ra3_',
  _r(k){try{const raw=localStorage.getItem(this._p+k);return raw?SEC.dec(raw):null}catch{return null}},
  _w(k,v){localStorage.setItem(this._p+k,SEC.enc(v))},
  _g(k,d=[]){return this._r(k)??d},
  _s(k,v){this._w(k,v)},

  init(){
    if(this._r('init'))return;
    this._s('users',[{id:'admin-001',name:'System Administrator',email:'admin@resourceai.com',
      passHash:SEC.hash('Admin@2025'),role:'admin',department:'Administration',approved:true,createdAt:new Date().toISOString()}]);
    this._s('departments',['Engineering','Operations','Design','Marketing','Finance','HR','Sales','Product','QA','DevOps']);
    this._s('employees',[]);this._s('allocations',[]);this._s('requirements',[]);
    this._s('projects',[]);this._s('pending',[]);this._s('email_log',[]);this._s('reset_tokens',[]);
    this._s('init',true);
  },

  // ── USERS ──────────────────────────────────────────────
  getUsers(){return this._g('users')},
  getByEmail(e){return this.getUsers().find(u=>u.email.toLowerCase()===e.toLowerCase())},
  addUser(u){const l=this.getUsers();u.id='u-'+Date.now();u.createdAt=new Date().toISOString();l.push(u);this._s('users',l);return u},
  updateUser(id,d){this._s('users',this.getUsers().map(u=>u.id===id?{...u,...d}:u))},
  deleteUser(id){this._s('users',this.getUsers().filter(u=>u.id!==id))},

  // ── PENDING REGISTRATIONS ──────────────────────────────
  getPending(){return this._g('pending')},
  addPending(r){const l=this.getPending();r.id='reg-'+Date.now();r.at=new Date().toISOString();l.push(r);this._s('pending',l);return r},
  approvePending(id){const l=this.getPending();const r=l.find(x=>x.id===id);if(!r)return null;const u=this.addUser({...r,approved:true});this._s('pending',l.filter(x=>x.id!==id));return u},
  rejectPending(id){this._s('pending',this.getPending().filter(r=>r.id!==id))},

  // ── RESET TOKENS ───────────────────────────────────────
  getTokens(){return this._g('reset_tokens')},
  setToken(email,token){const l=this.getTokens().filter(t=>t.email!==email);l.push({email,token,expires:Date.now()+30*60*1000});this._s('reset_tokens',l)},
  verifyToken(email,token){const t=this.getTokens().find(x=>x.email===email&&x.token===token);return t&&t.expires>Date.now()},
  clearToken(email){this._s('reset_tokens',this.getTokens().filter(t=>t.email!==email))},

  // ── DEPARTMENTS ────────────────────────────────────────
  getDepts(){return this._g('departments')},
  addDept(n){const l=this.getDepts();if(!l.includes(n)){l.push(n);this._s('departments',l)}},
  removeDept(n){this._s('departments',this.getDepts().filter(d=>d!==n))},

  // ── EMPLOYEES ──────────────────────────────────────────
  getEmployees(dept=null){const a=this._g('employees');return dept?a.filter(e=>e.department===dept):a},
  addEmployee(e){const l=this._g('employees');e.id=e.id||('emp-'+Date.now()+Math.random().toString(36).slice(2,5));e.createdAt=e.createdAt||new Date().toISOString();l.push(e);this._s('employees',l);return e},
  updateEmployee(id,d){this._s('employees',this._g('employees').map(e=>e.id===id?{...e,...d}:e))},
  deleteEmployee(id){this._s('employees',this._g('employees').filter(e=>e.id!==id))},
  clearEmployees(dept){if(dept)this._s('employees',this._g('employees').filter(e=>e.department!==dept));else this._s('employees',[])},

  // ── ALLOCATIONS ────────────────────────────────────────
  getAllocations(dept=null){
    const a=this._g('allocations');
    if(!dept)return a;
    const eids=new Set(this.getEmployees(dept).map(e=>e.id));
    return a.filter(x=>eids.has(x.employeeId));
  },
  addAllocation(a){const l=this._g('allocations');a.id='al-'+Date.now();a.createdAt=new Date().toISOString();l.push(a);this._s('allocations',l);return a},
  updateAllocation(id,d){this._s('allocations',this._g('allocations').map(a=>a.id===id?{...a,...d}:a))},
  removeAllocation(id){this._s('allocations',this._g('allocations').filter(a=>a.id!==id))},
  empAllocs(empId){return this._g('allocations').filter(a=>a.employeeId===empId)},
  empUtil(empId){return this.empAllocs(empId).reduce((s,a)=>s+(parseFloat(a.percentage)||0),0)},
  clearAllocs(dept){
    if(dept){const eids=new Set(this.getEmployees(dept).map(e=>e.id));this._s('allocations',this._g('allocations').filter(a=>!eids.has(a.employeeId)))}
    else this._s('allocations',[]);
  },

  // ── PROJECTS ───────────────────────────────────────────
  getProjects(dept=null){const a=this._g('projects');return dept?a.filter(p=>p.department===dept):a},
  addProject(p){const l=this._g('projects');p.id='prj-'+Date.now();p.createdAt=new Date().toISOString();l.push(p);this._s('projects',l);return p},
  updateProject(id,d){this._s('projects',this._g('projects').map(p=>p.id===id?{...p,...d}:p))},
  deleteProject(id){this._s('projects',this._g('projects').filter(p=>p.id!==id))},
  findOrCreateProj(name,dept){
    let p=this._g('projects').find(x=>x.name.toLowerCase().trim()===name.toLowerCase().trim());
    if(!p)p=this.addProject({name:name.trim(),department:dept,isInternal:false});
    return p;
  },

  // ── REQUIREMENTS ───────────────────────────────────────
  getRequirements(dept=null){const a=this._g('requirements');return dept?a.filter(r=>r.department===dept):a},
  addRequirement(r){const l=this._g('requirements');r.id='req-'+Date.now();r.createdAt=new Date().toISOString();r.status=r.status||'Open';l.push(r);this._s('requirements',l);return r},
  updateRequirement(id,d){this._s('requirements',this._g('requirements').map(r=>r.id===id?{...r,...d}:r))},
  deleteRequirement(id){this._s('requirements',this._g('requirements').filter(r=>r.id!==id))},

  // ── EMAIL LOG ──────────────────────────────────────────
  logEmail(e){const l=this._g('email_log');e.at=new Date().toISOString();l.unshift(e);this._s('email_log',l.slice(0,100))},
  getEmailLog(){return this._g('email_log')},

  // ── SESSION (8-hour expiry) ────────────────────────────
  session(){const s=this._r('session');if(!s)return null;if(s.expires&&Date.now()>s.expires){this.clearSession();return null;}return s},
  setSession(u){this._w('session',{...u,expires:Date.now()+8*60*60*1000})},
  clearSession(){localStorage.removeItem(this._p+'session')},
};

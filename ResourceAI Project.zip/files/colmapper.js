'use strict';
// ═══════════════════════════════════════════════════════
// COLUMN MAPPER — AI-powered Excel header normalization
// Maps any column name variation to canonical field names
// ═══════════════════════════════════════════════════════
const ColMapper = {
  // Schema definitions: canonical field → accepted column name variants
  SKILL:{
    name:['employeename','empname','fullname','name','staff','resource','person'],
    employeeId:['employeeid','empid','id','staffid','eid','empno'],
    email:['email','emailid','mail'],
    department:['department','dept','division','bu','team','unit'],
    designation:['designation','band','level','grade','jobtitle','title','bandlevel','seniority','tier','rank'],
    experienceYears:['experience','experienceyears','yoe','years','exp','totalexperience'],
    location:['location','city','baselocation','site','office'],
    skills:['skills','skill','techstack','technologies','expertise','primaryskills','keyskills'],
    secondarySkills:['secondaryskills','skills2','otherskills','addlskills'],
  },
  ALLOC:{
    employeeId:['employeeid','empid','id','name','employeename','empname','resource'],
    projectName:['project','projectname','allocatedproject','assignedproject','currentproject','engagement','assignment','work'],
    percentage:['allocation','allocationpercentage','percent','percentage','allocated','utilization'],
    startDate:['startdate','fromdate','start','from'],
    endDate:['enddate','todate','end','till','until'],
    isInternal:['isinternal','internal','type','projecttype','billable'],
  },
  REQ:{
    role:['role','jobtitle','title','position','designation','opening','requirement'],
    skills:['skills','requiredskills','mandatoryskills','techstack','technologies'],
    experienceYears:['experience','minexperience','minyears','requiredexperience'],
    designation:['band','level','grade','designation','seniority','requiredband'],
    location:['location','preferredlocation','city'],
    headcount:['headcount','count','openings','positions','vacancies'],
    priority:['priority','urgency','criticality'],
    description:['description','details','notes','jd'],
  },

  /** Normalize a raw header string to lowercase alphanumeric */
  norm(h){return h.toString().toLowerCase().replace(/[^a-z0-9]/g,'')},

  /** Map raw file headers to canonical schema keys (two-pass: exact then fuzzy) */
  mapHeaders(headers, schema){
    const result={};const used=new Set();
    // Pass 1: exact match
    for(const[canon,syns]of Object.entries(schema)){
      for(const h of headers){const n=this.norm(h);if(used.has(h))continue;if(syns.includes(n)){result[canon]=h;used.add(h);break;}}
    }
    // Pass 2: fuzzy match (substring)
    for(const[canon,syns]of Object.entries(schema)){
      if(result[canon])continue;
      for(const h of headers){if(used.has(h))continue;const n=this.norm(h);if(syns.some(s=>n.includes(s)||s.includes(n))){result[canon]=h;used.add(h);break;}}
    }
    return result;
  },

  /** Return headers that did not get mapped (will be stored as _extra_ fields) */
  unmapped(headers, mapping){const m=new Set(Object.values(mapping));return headers.filter(h=>!m.has(h))},

  /** Transform a raw row using the header mapping into canonical + extra fields */
  transform(row, mapping){
    const out={};
    for(const[canon,orig]of Object.entries(mapping)){
      if(row[orig]!==undefined&&row[orig]!==null&&String(row[orig]).trim()!=='')out[canon]=String(row[orig]).trim();
    }
    for(const[k,v]of Object.entries(row)){
      if(!Object.values(mapping).includes(k)&&v!==null&&v!==undefined&&String(v).trim()!=='')out['_extra_'+k]=String(v).trim();
    }
    return out;
  },
};
